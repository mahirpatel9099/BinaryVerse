
  # 3D Educational Conversion App

  This is a code bundle for 3D Educational Conversion App. The original project is available at https://www.figma.com/design/2vuTw0TzBesrVtZ3dNBvXa/3D-Educational-Conversion-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
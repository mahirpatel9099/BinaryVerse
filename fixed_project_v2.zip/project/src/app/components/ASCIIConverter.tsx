import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, Copy, RotateCcw, ArrowRightLeft, FileText, Binary, Check } from "lucide-react";
import { Button } from "./ui/button";
import { Label } from "./ui/label";
import { ThemeToggle } from "./ThemeToggle";
import { useTheme } from "../contexts/ThemeContext";

type ConversionMode = "text-to-binary" | "binary-to-text";

export function ASCIIConverter() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [mode, setMode] = useState<ConversionMode>("text-to-binary");
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    handleConvert();
  }, [input, mode]);

  const textToBinary = (text: string): string => {
    if (!text) return "";

    return text
      .split("")
      .map((char) => {
        const binary = char.charCodeAt(0).toString(2);
        return binary.padStart(8, "0");
      })
      .join(" ");
  };

  const binaryToText = (binary: string): { result: string; error: string } => {
    if (!binary.trim()) return { result: "", error: "" };

    const binaryGroups = binary.trim().split(/\s+/);

    // Validate each group
    for (const group of binaryGroups) {
      if (!/^[01]+$/.test(group)) {
        return {
          result: "",
          error: `Invalid binary: "${group}" contains non-binary characters`
        };
      }
      if (group.length !== 8) {
        return {
          result: "",
          error: `Invalid binary: "${group}" must be exactly 8 bits (found ${group.length} bits)`
        };
      }
    }

    try {
      const text = binaryGroups
        .map((group) => {
          const charCode = parseInt(group, 2);
          return String.fromCharCode(charCode);
        })
        .join("");

      return { result: text, error: "" };
    } catch (e) {
      return { result: "", error: "Conversion failed" };
    }
  };

  const handleConvert = () => {
    setError("");

    if (mode === "text-to-binary") {
      const result = textToBinary(input);
      setOutput(result);
    } else {
      const { result, error } = binaryToText(input);
      setOutput(result);
      setError(error);
    }
  };

  const handleSwap = () => {
    const newMode = mode === "text-to-binary" ? "binary-to-text" : "text-to-binary";
    setMode(newMode);
    setInput(output);
    setOutput("");
    setError("");
  };

  const handleCopy = () => {
    if (output) {
      navigator.clipboard.writeText(output);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleClear = () => {
    setInput("");
    setOutput("");
    setError("");
  };

  const handleExample = (text: string) => {
    setMode("text-to-binary");
    setInput(text);
  };

  const handleBinaryExample = (binary: string) => {
    setMode("binary-to-text");
    setInput(binary);
  };

  const getCharCount = () => input.length;
  const getByteCount = () => {
    if (mode === "text-to-binary") {
      return input.length;
    } else {
      return input.trim().split(/\s+/).filter(g => g.length === 8).length;
    }
  };

  return (
    <div className={`min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Link to="/">
            <Button variant="ghost" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>

          <ThemeToggle />
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            ASCII Converter
          </h1>
          <p className="text-xl text-slate-300">Convert Text to Binary and Binary to Text</p>
        </motion.div>

        {/* Mode Selector */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex justify-center mb-8"
        >
          <div className="inline-flex bg-slate-900 border border-slate-700 rounded-xl p-1">
            <Button
              onClick={() => {
                setMode("text-to-binary");
                setInput("");
                setOutput("");
                setError("");
              }}
              variant={mode === "text-to-binary" ? "default" : "ghost"}
              className={mode === "text-to-binary"
                ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white"
                : "text-slate-400 hover:text-white"
              }
            >
              <FileText className="w-4 h-4 mr-2" />
              Text to Binary
            </Button>
            <Button
              onClick={() => {
                setMode("binary-to-text");
                setInput("");
                setOutput("");
                setError("");
              }}
              variant={mode === "binary-to-text" ? "default" : "ghost"}
              className={mode === "binary-to-text"
                ? "bg-gradient-to-r from-purple-500 to-pink-600 text-white"
                : "text-slate-400 hover:text-white"
              }
            >
              <Binary className="w-4 h-4 mr-2" />
              Binary to Text
            </Button>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Input Panel */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-cyan-500/10 to-blue-600/10 backdrop-blur-md border-2 border-cyan-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Label className="text-xl font-bold text-white">
                {mode === "text-to-binary" ? "📝 Input Text" : "🔢 Input Binary"}
              </Label>
              <div className="flex gap-2">
                <Button
                  onClick={handleSwap}
                  variant="outline"
                  size="sm"
                  className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                </Button>
                <Button
                  onClick={handleClear}
                  variant="outline"
                  size="sm"
                  className="border-slate-600 text-slate-300 hover:bg-slate-800"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={
                mode === "text-to-binary"
                  ? "Enter text to convert..."
                  : "Enter binary (8-bit groups separated by spaces)..."
              }
              className="w-full h-64 bg-slate-800/50 border border-slate-600 rounded-xl p-4 text-white font-mono text-lg resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500"
            />

            <div className="flex items-center justify-between mt-4 text-sm text-slate-400">
              <div>
                {mode === "text-to-binary" ? "Characters" : "Binary Groups"}: {getCharCount()}
              </div>
              <div>Bytes: {getByteCount()}</div>
            </div>
          </motion.div>

          {/* Output Panel */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-purple-500/10 to-pink-600/10 backdrop-blur-md border-2 border-purple-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Label className="text-xl font-bold text-white">
                {mode === "text-to-binary" ? "🔢 Output Binary" : "📝 Output Text"}
              </Label>
              <Button
                onClick={handleCopy}
                variant="outline"
                size="sm"
                disabled={!output}
                className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10 disabled:opacity-50"
              >
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? "Copied!" : "Copy"}
              </Button>
            </div>

            {error ? (
              <div className="w-full h-64 bg-red-500/10 border-2 border-red-500/30 rounded-xl p-4 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">⚠️</div>
                  <div className="text-red-400 font-semibold text-lg">{error}</div>
                </div>
              </div>
            ) : (
              <div className="w-full h-64 bg-slate-800/50 border border-slate-600 rounded-xl p-4 overflow-y-auto">
                <div className="text-white font-mono text-lg break-all whitespace-pre-wrap">
                  {output || (
                    <span className="text-slate-500 italic">
                      {mode === "text-to-binary"
                        ? "Binary output will appear here..."
                        : "Text output will appear here..."}
                    </span>
                  )}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between mt-4 text-sm text-slate-400">
              <div>
                {mode === "text-to-binary" ? "Binary Groups" : "Characters"}: {output.length > 0 ? (mode === "text-to-binary" ? output.split(" ").length : output.length) : 0}
              </div>
              <div>Bytes: {output.length > 0 ? (mode === "text-to-binary" ? output.split(" ").length : output.length) : 0}</div>
            </div>
          </motion.div>
        </div>

        {/* Examples Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-gradient-to-br from-indigo-500/10 to-blue-600/10 backdrop-blur-md border-2 border-indigo-500/30 rounded-2xl p-6 mb-8"
        >
          <h3 className="text-2xl font-bold text-white mb-4">📚 Examples</h3>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <h4 className="text-lg font-semibold text-cyan-400 mb-3">Text to Binary</h4>
              <div className="space-y-2">
                {[
                  { text: "A", binary: "01000001" },
                  { text: "Hello", binary: "01001000 01100101 01101100 01101100 01101111" },
                  { text: "123", binary: "00110001 00110010 00110011" },
                ].map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handleExample(example.text)}
                    className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-left hover:border-cyan-500/50 transition-colors"
                  >
                    <div className="text-white font-mono mb-1">{example.text}</div>
                    <div className="text-xs text-slate-400 font-mono">→ {example.binary}</div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-purple-400 mb-3">Binary to Text</h4>
              <div className="space-y-2">
                {[
                  { binary: "01000001", text: "A" },
                  { binary: "01001000 01101001", text: "Hi" },
                  { binary: "00110001 00110010 00110011", text: "123" },
                ].map((example, index) => (
                  <button
                    key={index}
                    onClick={() => handleBinaryExample(example.binary)}
                    className="w-full bg-slate-800/50 border border-slate-700 rounded-lg p-3 text-left hover:border-purple-500/50 transition-colors"
                  >
                    <div className="text-white font-mono text-sm mb-1">{example.binary}</div>
                    <div className="text-xs text-slate-400">→ {example.text}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Notes Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-yellow-500/10 to-orange-600/10 backdrop-blur-md border-2 border-yellow-500/30 rounded-2xl p-6"
        >
          <h3 className="text-2xl font-bold text-white mb-4">📌 Notes</h3>
          <div className="grid md:grid-cols-2 gap-6 text-slate-300">
            <div>
              <h4 className="font-semibold text-yellow-400 mb-2">What is ASCII?</h4>
              <p className="text-sm">
                ASCII (American Standard Code for Information Interchange) is a character encoding standard that represents text in computers. Each character is assigned a number from 0-127.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-orange-400 mb-2">Binary Format</h4>
              <ul className="text-sm space-y-1 list-disc list-inside">
                <li>One character = 8 bits (1 byte)</li>
                <li>Binary groups are separated by spaces</li>
                <li>Each bit is either 0 or 1</li>
                <li>Supports standard ASCII characters (0-127)</li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Heart, Trophy, Zap, Clock, Target } from "lucide-react";
import { Button } from "./ui/button";
import confetti from "canvas-confetti";

interface FallingNumber {
  id: number;
  binary: string;
  decimal: number;
  y: number;
  x: number;
}

interface PowerUp {
  id: number;
  type: "freeze" | "double" | "life";
  y: number;
  x: number;
}

export function BinaryRushGame() {
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameOver">("menu");
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [level, setLevel] = useState(1);
  const [combo, setCombo] = useState(0);
  const [fallingNumbers, setFallingNumbers] = useState<FallingNumber[]>([]);
  const [powerUps, setPowerUps] = useState<PowerUp[]>([]);
  const [timeLeft, setTimeLeft] = useState(60);
  const [frozen, setFrozen] = useState(false);
  const [doublePoints, setDoublePoints] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<FallingNumber | null>(null);
  const [options, setOptions] = useState<number[]>([]);

  const generateBinary = useCallback(() => {
    const maxNum = 15 + (level * 10);
    const decimal = Math.floor(Math.random() * maxNum) + 1;
    const binary = decimal.toString(2);
    return { binary, decimal };
  }, [level]);

  const generateOptions = useCallback((correct: number) => {
    const opts = [correct];
    while (opts.length < 4) {
      const wrong = Math.floor(Math.random() * (15 + level * 10)) + 1;
      if (!opts.includes(wrong)) {
        opts.push(wrong);
      }
    }
    return opts.sort(() => Math.random() - 0.5);
  }, [level]);

  const startGame = () => {
    setGameState("playing");
    setScore(0);
    setLives(3);
    setLevel(1);
    setCombo(0);
    setTimeLeft(60);
    setFallingNumbers([]);
    setPowerUps([]);
    spawnNumber();
  };

  const spawnNumber = useCallback(() => {
    const { binary, decimal } = generateBinary();
    const newNumber: FallingNumber = {
      id: Date.now(),
      binary,
      decimal,
      y: 0,
      x: Math.random() * 60 + 20,
    };
    setCurrentQuestion(newNumber);
    setOptions(generateOptions(decimal));
  }, [generateBinary, generateOptions]);

  const spawnPowerUp = useCallback(() => {
    if (Math.random() > 0.7) {
      const types: ("freeze" | "double" | "life")[] = ["freeze", "double", "life"];
      const newPowerUp: PowerUp = {
        id: Date.now(),
        type: types[Math.floor(Math.random() * types.length)],
        y: 0,
        x: Math.random() * 70 + 15,
      };
      setPowerUps(prev => [...prev, newPowerUp]);
    }
  }, []);

  const handleAnswer = (selectedDecimal: number) => {
    if (!currentQuestion) return;

    if (selectedDecimal === currentQuestion.decimal) {
      // Correct answer
      const points = (10 + combo * 5) * (doublePoints ? 2 : 1);
      setScore(prev => prev + points);
      setCombo(prev => prev + 1);

      if (combo > 0 && combo % 5 === 0) {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      }

      // Level up every 100 points
      const newScore = score + points;
      const newLevel = Math.floor(newScore / 100) + 1;
      if (newLevel > level) {
        setLevel(newLevel);
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      }

      spawnNumber();

      if (Math.random() > 0.8) {
        spawnPowerUp();
      }
    } else {
      // Wrong answer
      setLives(prev => prev - 1);
      setCombo(0);

      if (lives - 1 <= 0) {
        setGameState("gameOver");
        // Save high score
        const highScore = parseInt(localStorage.getItem("binaryRushHighScore") || "0");
        if (score > highScore) {
          localStorage.setItem("binaryRushHighScore", score.toString());
        }
      } else {
        spawnNumber();
      }
    }
  };

  const activatePowerUp = (type: "freeze" | "double" | "life") => {
    switch (type) {
      case "freeze":
        setFrozen(true);
        setTimeout(() => setFrozen(false), 5000);
        break;
      case "double":
        setDoublePoints(true);
        setTimeout(() => setDoublePoints(false), 10000);
        break;
      case "life":
        setLives(prev => Math.min(prev + 1, 5));
        break;
    }
  };

  // Timer
  useEffect(() => {
    if (gameState !== "playing") return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setGameState("gameOver");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState]);

  // PowerUp movement
  useEffect(() => {
    if (gameState !== "playing" || frozen) return;

    const interval = setInterval(() => {
      setPowerUps(prev => {
        const updated = prev.map(pu => ({
          ...pu,
          y: pu.y + 2
        })).filter(pu => pu.y < 100);
        return updated;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [gameState, frozen]);

  const highScore = parseInt(localStorage.getItem("binaryRushHighScore") || "0");

  return (
    <div className="relative min-h-screen px-4 py-8 overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/20 via-transparent to-transparent" />
      </div>

      <div className="max-w-5xl mx-auto relative z-10">
        <div className="flex items-center justify-between mb-6">
          <Link to="/">
            <Button variant="ghost" className="text-primary hover:bg-primary/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>
        </div>

        {/* Menu State */}
        {gameState === "menu" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Trophy className="w-24 h-24 text-primary mx-auto mb-6" />
            </motion.div>

            <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-primary via-purple-500 to-pink-500 bg-clip-text text-transparent">
              Binary Rush
            </h1>
            <p className="text-xl text-muted-foreground mb-8">
              Convert binary numbers before time runs out!
            </p>

            <div className="bg-card border-2 border-primary/20 rounded-2xl p-8 mb-8 max-w-2xl mx-auto backdrop-blur-sm">
              <h2 className="text-2xl font-bold mb-4">How to Play:</h2>
              <div className="space-y-3 text-left text-muted-foreground">
                <p>• Binary numbers appear on screen</p>
                <p>• Select the correct decimal value</p>
                <p>• Build combos for bonus points</p>
                <p>• Collect power-ups for advantages</p>
                <p>• Don't let lives reach zero!</p>
              </div>
            </div>

            {highScore > 0 && (
              <div className="mb-8">
                <div className="text-muted-foreground">High Score</div>
                <div className="text-4xl font-bold text-primary">{highScore}</div>
              </div>
            )}

            <Button
              onClick={startGame}
              className="px-12 py-6 text-xl bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700 shadow-lg shadow-primary/50"
            >
              Start Game
            </Button>
          </motion.div>
        )}

        {/* Playing State */}
        {gameState === "playing" && (
          <div className="space-y-6">
            {/* Game Stats */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-card border-2 border-red-500/30 rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Heart className="w-5 h-5 text-red-500" />
                  <span className="text-sm text-muted-foreground">Lives</span>
                </div>
                <div className="text-3xl font-bold">{lives}</div>
              </div>

              <div className="bg-card border-2 border-primary/30 rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Trophy className="w-5 h-5 text-primary" />
                  <span className="text-sm text-muted-foreground">Score</span>
                </div>
                <div className="text-3xl font-bold text-primary">{score}</div>
              </div>

              <div className="bg-card border-2 border-purple-500/30 rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Target className="w-5 h-5 text-purple-500" />
                  <span className="text-sm text-muted-foreground">Level</span>
                </div>
                <div className="text-3xl font-bold text-purple-500">{level}</div>
              </div>

              <div className="bg-card border-2 border-yellow-500/30 rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  <span className="text-sm text-muted-foreground">Combo</span>
                </div>
                <div className="text-3xl font-bold text-yellow-500">x{combo}</div>
              </div>

              <div className="bg-card border-2 border-green-500/30 rounded-xl p-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-green-500" />
                  <span className="text-sm text-muted-foreground">Time</span>
                </div>
                <div className={`text-3xl font-bold ${timeLeft < 10 ? 'text-red-500' : 'text-green-500'}`}>
                  {timeLeft}s
                </div>
              </div>
            </div>

            {/* Active Power-Ups */}
            {(frozen || doublePoints) && (
              <div className="flex gap-2 justify-center">
                {frozen && (
                  <div className="bg-blue-500/20 border-2 border-blue-500 rounded-lg px-4 py-2 text-blue-500 font-semibold">
                    ❄️ Time Frozen
                  </div>
                )}
                {doublePoints && (
                  <div className="bg-yellow-500/20 border-2 border-yellow-500 rounded-lg px-4 py-2 text-yellow-500 font-semibold">
                    ⚡ Double Points
                  </div>
                )}
              </div>
            )}

            {/* Game Area */}
            <div className="bg-card border-2 border-primary/20 rounded-2xl p-8 min-h-96 relative overflow-hidden backdrop-blur-sm">
              {/* Falling PowerUps */}
              <AnimatePresence>
                {powerUps.map(pu => (
                  <motion.div
                    key={pu.id}
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0 }}
                    style={{
                      position: 'absolute',
                      left: `${pu.x}%`,
                      top: `${pu.y}%`,
                    }}
                    className="cursor-pointer"
                    onClick={() => {
                      activatePowerUp(pu.type);
                      setPowerUps(prev => prev.filter(p => p.id !== pu.id));
                    }}
                  >
                    <div className="text-4xl">
                      {pu.type === "freeze" && "❄️"}
                      {pu.type === "double" && "⚡"}
                      {pu.type === "life" && "❤️"}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Current Question */}
              {currentQuestion && (
                <div className="text-center mb-8">
                  <motion.div
                    initial={{ y: -50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="inline-block bg-gradient-to-r from-primary/20 to-purple-500/20 border-2 border-primary rounded-2xl px-12 py-8 mb-6"
                  >
                    <div className="text-6xl md:text-8xl font-bold font-mono text-primary">
                      {currentQuestion.binary}
                    </div>
                    <div className="text-muted-foreground mt-2">Convert to Decimal</div>
                  </motion.div>

                  {/* Answer Options */}
                  <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
                    {options.map((option, index) => (
                      <motion.button
                        key={option}
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1 }}
                        onClick={() => handleAnswer(option)}
                        className="bg-gradient-to-r from-muted to-muted/80 hover:from-primary/20 hover:to-purple-500/20 border-2 border-border hover:border-primary rounded-xl p-6 text-3xl font-bold font-mono transition-all hover:scale-105 active:scale-95"
                      >
                        {option}
                      </motion.button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Game Over State */}
        {gameState === "gameOver" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-7xl font-black mb-4 text-destructive">
              Game Over!
            </h1>

            <div className="bg-card border-2 border-primary/20 rounded-2xl p-8 mb-8 max-w-2xl mx-auto backdrop-blur-sm">
              <div className="mb-6">
                <div className="text-muted-foreground mb-2">Final Score</div>
                <div className="text-6xl font-bold text-primary">{score}</div>
              </div>

              <div className="grid grid-cols-2 gap-4 text-left">
                <div>
                  <div className="text-sm text-muted-foreground">Level Reached</div>
                  <div className="text-2xl font-bold text-purple-500">{level}</div>
                </div>
                <div>
                  <div className="text-sm text-muted-foreground">Best Combo</div>
                  <div className="text-2xl font-bold text-yellow-500">x{combo}</div>
                </div>
                <div className="col-span-2">
                  <div className="text-sm text-muted-foreground">High Score</div>
                  <div className="text-2xl font-bold text-green-500">{highScore}</div>
                </div>
              </div>
            </div>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={startGame}
                className="px-8 py-6 text-xl bg-gradient-to-r from-primary to-purple-600 hover:from-primary/90 hover:to-purple-700"
              >
                Play Again
              </Button>
              <Link to="/">
                <Button variant="outline" className="px-8 py-6 text-xl border-2">
                  Main Menu
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { Binary, Gamepad2, TrendingUp, BookOpen, GraduationCap, Target, History, FileText } from "lucide-react";
import { useTheme } from "../contexts/ThemeContext";
import { ThemeToggle } from "./ThemeToggle";

export function BinaryVerseLanding() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";
  const [binaryRain, setBinaryRain] = useState<Array<{ id: number; x: number; delay: number }>>([]);

  useEffect(() => {
    // Generate binary rain columns
    const columns = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      x: (i * 5) + Math.random() * 2,
      delay: Math.random() * 5,
    }));
    setBinaryRain(columns);
  }, []);

  return (
    <div className={`min-h-screen relative overflow-hidden transition-colors duration-500 ${
      isDark
        ? 'bg-slate-950'
        : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      {/* Binary Rain Effect */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden opacity-20">
        {binaryRain.map((col) => (
          <motion.div
            key={col.id}
            className={`absolute text-xs font-mono ${isDark ? 'text-green-400' : 'text-blue-600'}`}
            style={{ left: `${col.x}%` }}
            initial={{ y: -100 }}
            animate={{ y: '100vh' }}
            transition={{
              duration: 8,
              repeat: Infinity,
              delay: col.delay,
              ease: "linear",
            }}
          >
            {Array.from({ length: 20 }, () => Math.random() > 0.5 ? '1' : '0').join('\n')}
          </motion.div>
        ))}
      </div>

      {/* Circuit Pattern */}
      <div className="absolute inset-0 opacity-5">
        <svg width="100%" height="100%">
          <pattern id="circuit" x="0" y="0" width="100" height="100" patternUnits="userSpaceOnUse">
            <circle cx="50" cy="50" r="2" fill={isDark ? "#60a5fa" : "#3b82f6"} />
            <line x1="50" y1="0" x2="50" y2="50" stroke={isDark ? "#60a5fa" : "#3b82f6"} strokeWidth="1" />
            <line x1="0" y1="50" x2="50" y2="50" stroke={isDark ? "#60a5fa" : "#3b82f6"} strokeWidth="1" />
          </pattern>
          <rect width="100%" height="100%" fill="url(#circuit)" />
        </svg>
      </div>

      {/* Theme Toggle */}
      <div className="absolute top-8 right-8 z-50">
        <ThemeToggle />
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-12">
        {/* Floating Binary Cubes */}
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(6)].map((_, i) => (
            <motion.div
              key={i}
              className={`absolute text-6xl font-bold font-mono ${
                isDark ? 'text-cyan-500/20' : 'text-blue-500/20'
              }`}
              style={{
                left: `${Math.random() * 80 + 10}%`,
                top: `${Math.random() * 80 + 10}%`,
              }}
              animate={{
                y: [0, -30, 0],
                rotateY: [0, 360],
                opacity: [0.1, 0.3, 0.1],
              }}
              transition={{
                duration: 6 + i,
                repeat: Infinity,
                delay: i * 0.5,
              }}
            >
              {Math.random() > 0.5 ? '1' : '0'}
            </motion.div>
          ))}
        </div>

        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="text-center mb-12 max-w-5xl"
        >
          <motion.div
            animate={{
              scale: [1, 1.02, 1],
              filter: isDark
                ? ['drop-shadow(0 0 20px rgba(34, 211, 238, 0.5))', 'drop-shadow(0 0 40px rgba(34, 211, 238, 0.8))', 'drop-shadow(0 0 20px rgba(34, 211, 238, 0.5))']
                : ['drop-shadow(0 0 10px rgba(59, 130, 246, 0.3))', 'drop-shadow(0 0 20px rgba(59, 130, 246, 0.5))', 'drop-shadow(0 0 10px rgba(59, 130, 246, 0.3))']
            }}
            transition={{ duration: 3, repeat: Infinity }}
          >
            <h1 className={`text-7xl md:text-9xl font-black mb-6 ${
              isDark
                ? 'bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent'
                : 'bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent'
            }`}>
              BinaryVerse
            </h1>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className={`text-2xl md:text-3xl mb-4 font-semibold ${
              isDark ? 'text-cyan-300' : 'text-blue-700'
            }`}
          >
            Binary ↔ Decimal Learning Platform
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className={`text-lg md:text-xl mb-8 ${
              isDark ? 'text-slate-300' : 'text-slate-700'
            }`}
          >
            Master binary conversion through interactive learning and gaming.
          </motion.p>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className={`inline-block px-6 py-3 rounded-lg backdrop-blur-md ${
              isDark
                ? 'bg-slate-800/30 border border-cyan-500/30 text-slate-300'
                : 'bg-white/50 border border-blue-500/30 text-slate-700'
            }`}
          >
            <p className="text-sm font-medium">This platform is designed for:</p>
            <p className="text-sm">Computer Organization • Engineering Students • Binary Beginners</p>
          </motion.div>
        </motion.div>

        {/* CTA Cards */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 1.1 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-7xl w-full px-4"
        >
          <Link to="/converter">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-cyan-500/10 to-blue-600/10 border-2 border-cyan-500/30 hover:border-cyan-400 shadow-lg shadow-cyan-500/20'
                  : 'bg-white/70 border-2 border-blue-300 hover:border-blue-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-cyan-400' : 'text-blue-600'}`}>
                <Binary className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Start Conversion
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Convert between binary and decimal with step-by-step explanations
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-cyan-500/5 to-transparent' : 'bg-gradient-to-br from-blue-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/ascii">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-teal-500/10 to-cyan-600/10 border-2 border-teal-500/30 hover:border-teal-400 shadow-lg shadow-teal-500/20'
                  : 'bg-white/70 border-2 border-teal-300 hover:border-teal-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-teal-400' : 'text-teal-600'}`}>
                <FileText className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                ASCII Converter
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Convert text to binary and binary to text with live conversion
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-teal-500/5 to-transparent' : 'bg-gradient-to-br from-teal-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/game">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-purple-500/10 to-pink-600/10 border-2 border-purple-500/30 hover:border-purple-400 shadow-lg shadow-purple-500/20'
                  : 'bg-white/70 border-2 border-purple-300 hover:border-purple-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-purple-400' : 'text-purple-600'}`}>
                <Gamepad2 className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Play Binary Game
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Test your skills in Binary Rush - an exciting arcade-style game
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-purple-500/5 to-transparent' : 'bg-gradient-to-br from-purple-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/progress">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-green-500/10 to-emerald-600/10 border-2 border-green-500/30 hover:border-green-400 shadow-lg shadow-green-500/20'
                  : 'bg-white/70 border-2 border-green-300 hover:border-green-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-green-400' : 'text-green-600'}`}>
                <TrendingUp className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Track Progress
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Monitor your learning journey with detailed analytics and achievements
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-green-500/5 to-transparent' : 'bg-gradient-to-br from-green-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/learn">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-orange-500/10 to-yellow-600/10 border-2 border-orange-500/30 hover:border-orange-400 shadow-lg shadow-orange-500/20'
                  : 'bg-white/70 border-2 border-orange-300 hover:border-orange-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-orange-400' : 'text-orange-600'}`}>
                <BookOpen className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Learn Theory
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Comprehensive tutorials on binary, decimal, and number systems
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-orange-500/5 to-transparent' : 'bg-gradient-to-br from-orange-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/quiz">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-blue-500/10 to-indigo-600/10 border-2 border-blue-500/30 hover:border-blue-400 shadow-lg shadow-blue-500/20'
                  : 'bg-white/70 border-2 border-blue-300 hover:border-blue-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-blue-400' : 'text-blue-600'}`}>
                <GraduationCap className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Take Quiz
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Test yourself with timed quizzes across three difficulty levels
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-blue-500/5 to-transparent' : 'bg-gradient-to-br from-blue-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/practice">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-pink-500/10 to-rose-600/10 border-2 border-pink-500/30 hover:border-pink-400 shadow-lg shadow-pink-500/20'
                  : 'bg-white/70 border-2 border-pink-300 hover:border-pink-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-pink-400' : 'text-pink-600'}`}>
                <Target className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                Practice
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Practice conversions with detailed step-by-step explanations
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-pink-500/5 to-transparent' : 'bg-gradient-to-br from-pink-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>

          <Link to="/history">
            <motion.div
              whileHover={{ scale: 1.05, y: -10 }}
              className={`group relative rounded-2xl p-8 backdrop-blur-md cursor-pointer transition-all ${
                isDark
                  ? 'bg-gradient-to-br from-yellow-500/10 to-amber-600/10 border-2 border-yellow-500/30 hover:border-yellow-400 shadow-lg shadow-yellow-500/20'
                  : 'bg-white/70 border-2 border-yellow-300 hover:border-yellow-500 shadow-lg'
              }`}
            >
              <div className={`mb-4 ${isDark ? 'text-yellow-400' : 'text-yellow-600'}`}>
                <History className="w-12 h-12" />
              </div>
              <h3 className={`text-2xl font-bold mb-2 ${isDark ? 'text-white' : 'text-slate-900'}`}>
                View History
              </h3>
              <p className={`${isDark ? 'text-slate-300' : 'text-slate-600'}`}>
                Review all your conversions, quiz results, and practice sessions
              </p>
              <div className={`absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none ${
                isDark ? 'bg-gradient-to-br from-yellow-500/5 to-transparent' : 'bg-gradient-to-br from-yellow-500/5 to-transparent'
              }`} />
            </motion.div>
          </Link>
        </motion.div>

        {/* Footer Info */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className={`mt-16 text-center ${isDark ? 'text-slate-400' : 'text-slate-600'}`}
        >
          <p className="text-sm">Futuristic • Educational • Interactive</p>
        </motion.div>
      </div>
    </div>
  );
}

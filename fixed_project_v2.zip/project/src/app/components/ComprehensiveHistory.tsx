import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, History, Trash2, Filter, Binary, GraduationCap, Target } from "lucide-react";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { useTheme } from "../contexts/ThemeContext";

interface ConversionHistoryItem {
  id: string;
  input: string;
  inputBase: string;
  results: {
    binary: string;
    decimal: string;
    hexadecimal: string;
    octal: string;
  };
  timestamp: number;
}

interface QuizHistoryItem {
  id: string;
  difficulty: string;
  score: number;
  total: number;
  timestamp: number;
  timeSpent: number;
}

interface PracticeHistoryItem {
  id: string;
  type: string;
  question: string;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  timestamp: number;
}

export function ComprehensiveHistory() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [conversionHistory, setConversionHistory] = useState<ConversionHistoryItem[]>([]);
  const [quizHistory, setQuizHistory] = useState<QuizHistoryItem[]>([]);
  const [practiceHistory, setPracticeHistory] = useState<PracticeHistoryItem[]>([]);

  useEffect(() => {
    loadAllHistory();
  }, []);

  const loadAllHistory = () => {
    // Load conversion history
    const savedConversions = localStorage.getItem("conversionHistory");
    if (savedConversions) {
      setConversionHistory(JSON.parse(savedConversions));
    }

    // Load quiz history
    const savedQuizzes = localStorage.getItem("quizHistory");
    if (savedQuizzes) {
      setQuizHistory(JSON.parse(savedQuizzes));
    }

    // Load practice history
    const savedPractice = localStorage.getItem("practiceHistory");
    if (savedPractice) {
      setPracticeHistory(JSON.parse(savedPractice));
    }
  };

  const clearConversionHistory = () => {
    setConversionHistory([]);
    localStorage.removeItem("conversionHistory");
  };

  const clearQuizHistory = () => {
    setQuizHistory([]);
    localStorage.removeItem("quizHistory");
  };

  const clearPracticeHistory = () => {
    setPracticeHistory([]);
    localStorage.removeItem("practiceHistory");
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const formatTimeSpent = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className={`min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button
              variant="ghost"
              className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            Complete History
          </h1>
          <p className="text-xl text-slate-400">All your conversions, quizzes, and practice sessions</p>
        </motion.div>

        <Tabs defaultValue="conversions" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-900 border border-slate-800">
            <TabsTrigger value="conversions" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-400">
              <Binary className="w-4 h-4 mr-2" />
              Conversions
            </TabsTrigger>
            <TabsTrigger value="quizzes" className="data-[state=active]:bg-blue-500/20 data-[state=active]:text-blue-400">
              <GraduationCap className="w-4 h-4 mr-2" />
              Quizzes
            </TabsTrigger>
            <TabsTrigger value="practice" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-400">
              <Target className="w-4 h-4 mr-2" />
              Practice
            </TabsTrigger>
          </TabsList>

          {/* Conversion History */}
          <TabsContent value="conversions" className="mt-6">
            <div className="bg-gradient-to-br from-cyan-500/5 to-blue-600/5 border border-cyan-500/20 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <History className="w-6 h-6 text-cyan-400" />
                  Conversion History ({conversionHistory.length})
                </h2>
                {conversionHistory.length > 0 && (
                  <Button
                    onClick={clearConversionHistory}
                    variant="ghost"
                    size="sm"
                    className="text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                )}
              </div>

              {conversionHistory.length === 0 ? (
                <p className="text-slate-400 text-center py-12">No conversion history yet. Start converting!</p>
              ) : (
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {conversionHistory.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-cyan-500/50 transition-colors"
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="text-white font-mono text-lg">
                            {item.input} <span className="text-cyan-400">({item.inputBase})</span>
                          </div>
                          <div className="text-xs text-slate-500 mt-1">
                            {formatDate(item.timestamp)}
                          </div>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                        <div className="bg-cyan-500/10 border border-cyan-500/30 rounded px-3 py-2">
                          <div className="text-cyan-400 text-xs">Binary</div>
                          <div className="text-white font-mono">{item.results.binary}</div>
                        </div>
                        <div className="bg-blue-500/10 border border-blue-500/30 rounded px-3 py-2">
                          <div className="text-blue-400 text-xs">Decimal</div>
                          <div className="text-white font-mono">{item.results.decimal}</div>
                        </div>
                        <div className="bg-purple-500/10 border border-purple-500/30 rounded px-3 py-2">
                          <div className="text-purple-400 text-xs">Hex</div>
                          <div className="text-white font-mono">{item.results.hexadecimal}</div>
                        </div>
                        <div className="bg-green-500/10 border border-green-500/30 rounded px-3 py-2">
                          <div className="text-green-400 text-xs">Octal</div>
                          <div className="text-white font-mono">{item.results.octal}</div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Quiz History */}
          <TabsContent value="quizzes" className="mt-6">
            <div className="bg-gradient-to-br from-blue-500/5 to-indigo-600/5 border border-blue-500/20 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <History className="w-6 h-6 text-blue-400" />
                  Quiz History ({quizHistory.length})
                </h2>
                {quizHistory.length > 0 && (
                  <Button
                    onClick={clearQuizHistory}
                    variant="ghost"
                    size="sm"
                    className="text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                )}
              </div>

              {quizHistory.length === 0 ? (
                <p className="text-slate-400 text-center py-12">No quiz history yet. Take a quiz!</p>
              ) : (
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {quizHistory.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-blue-500/50 transition-colors"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                              item.difficulty === "low"
                                ? "bg-green-500/20 text-green-400 border border-green-500/30"
                                : item.difficulty === "medium"
                                ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                                : "bg-red-500/20 text-red-400 border border-red-500/30"
                            }`}>
                              {item.difficulty.toUpperCase()}
                            </span>
                            <span className="text-2xl font-bold text-white">
                              {item.score}/{item.total}
                            </span>
                            <span className={`text-lg font-semibold ${
                              (item.score / item.total) >= 0.7 ? "text-green-400" : "text-orange-400"
                            }`}>
                              ({Math.round((item.score / item.total) * 100)}%)
                            </span>
                          </div>
                          <div className="text-xs text-slate-500">
                            {formatDate(item.timestamp)} • {formatTimeSpent(item.timeSpent)}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>

          {/* Practice History */}
          <TabsContent value="practice" className="mt-6">
            <div className="bg-gradient-to-br from-purple-500/5 to-pink-600/5 border border-purple-500/20 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <History className="w-6 h-6 text-purple-400" />
                  Practice History ({practiceHistory.length})
                </h2>
                {practiceHistory.length > 0 && (
                  <Button
                    onClick={clearPracticeHistory}
                    variant="ghost"
                    size="sm"
                    className="text-red-400 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear All
                  </Button>
                )}
              </div>

              {practiceHistory.length === 0 ? (
                <p className="text-slate-400 text-center py-12">No practice history yet. Start practicing!</p>
              ) : (
                <div className="space-y-4 max-h-[600px] overflow-y-auto">
                  {practiceHistory.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`bg-slate-900 border rounded-xl p-4 transition-colors ${
                        item.isCorrect
                          ? "border-green-500/30 hover:border-green-500/50"
                          : "border-red-500/30 hover:border-red-500/50"
                      }`}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <div className="flex-1">
                          <div className="text-sm text-slate-400 mb-1">{item.type}</div>
                          <div className="text-white font-mono text-lg mb-2">
                            Question: {item.question}
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                            <div>
                              <div className="text-xs text-slate-500">Your Answer:</div>
                              <div className={`font-mono ${item.isCorrect ? "text-green-400" : "text-red-400"}`}>
                                {item.userAnswer}
                              </div>
                            </div>
                            {!item.isCorrect && (
                              <div>
                                <div className="text-xs text-slate-500">Correct Answer:</div>
                                <div className="font-mono text-green-400">
                                  {item.correctAnswer}
                                </div>
                              </div>
                            )}
                          </div>
                          <div className="text-xs text-slate-500 mt-2">
                            {formatDate(item.timestamp)}
                          </div>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-sm font-semibold ${
                          item.isCorrect
                            ? "bg-green-500/20 text-green-400"
                            : "bg-red-500/20 text-red-400"
                        }`}>
                          {item.isCorrect ? "✓ Correct" : "✗ Incorrect"}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Trophy, Timer, CheckCircle2, XCircle, RotateCcw, Target } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import confetti from "canvas-confetti";
import { useTheme } from "../contexts/ThemeContext";

interface Question {
  input: string;
  correctAnswer: string;
  type: string;
  fromBase: string;
  toBase: string;
}

type Difficulty = "low" | "medium" | "high" | null;

export function ComprehensiveQuiz() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [difficulty, setDifficulty] = useState<Difficulty>(null);
  const [score, setScore] = useState(0);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [timeLeft, setTimeLeft] = useState(90);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);
  const [totalQuestions] = useState(15);
  const [startTime, setStartTime] = useState(0);
  const [correctCount, setCorrectCount] = useState(0);

  const allConversions = {
    low: [
      { from: "binary", to: "decimal", label: "Binary → Decimal" },
      { from: "decimal", to: "binary", label: "Decimal → Binary" },
    ],
    medium: [
      { from: "binary", to: "decimal", label: "Binary → Decimal" },
      { from: "decimal", to: "binary", label: "Decimal → Binary" },
      { from: "decimal", to: "hex", label: "Decimal → Hexadecimal" },
      { from: "hex", to: "decimal", label: "Hexadecimal → Decimal" },
      { from: "binary", to: "hex", label: "Binary → Hexadecimal" },
      { from: "hex", to: "binary", label: "Hexadecimal → Binary" },
    ],
    high: [
      { from: "binary", to: "decimal", label: "Binary → Decimal" },
      { from: "decimal", to: "binary", label: "Decimal → Binary" },
      { from: "binary", to: "hex", label: "Binary → Hexadecimal" },
      { from: "hex", to: "binary", label: "Hexadecimal → Binary" },
      { from: "decimal", to: "hex", label: "Decimal → Hexadecimal" },
      { from: "hex", to: "decimal", label: "Hexadecimal → Decimal" },
      { from: "decimal", to: "octal", label: "Decimal → Octal" },
      { from: "octal", to: "decimal", label: "Octal → Decimal" },
      { from: "binary", to: "octal", label: "Binary → Octal" },
      { from: "octal", to: "binary", label: "Octal → Binary" },
      { from: "hex", to: "octal", label: "Hexadecimal → Octal" },
      { from: "octal", to: "hex", label: "Octal → Hexadecimal" },
    ],
  };

  const generateQuestion = (diff: Difficulty): Question => {
    if (!diff) return { input: "", correctAnswer: "", type: "", fromBase: "", toBase: "" };

    let maxNum = 50;
    if (diff === "medium") maxNum = 200;
    if (diff === "high") maxNum = 1000;

    const conversions = allConversions[diff];
    const conversion = conversions[Math.floor(Math.random() * conversions.length)];
    const randomNum = Math.floor(Math.random() * maxNum) + 10;

    let input: string;
    let answer: string;

    // Generate input based on 'from' base
    if (conversion.from === "binary") input = randomNum.toString(2);
    else if (conversion.from === "decimal") input = randomNum.toString(10);
    else if (conversion.from === "hex") input = randomNum.toString(16).toUpperCase();
    else if (conversion.from === "octal") input = randomNum.toString(8);
    else input = randomNum.toString();

    // Generate answer based on 'to' base
    if (conversion.to === "binary") answer = randomNum.toString(2);
    else if (conversion.to === "decimal") answer = randomNum.toString(10);
    else if (conversion.to === "hex") answer = randomNum.toString(16).toUpperCase();
    else if (conversion.to === "octal") answer = randomNum.toString(8);
    else answer = randomNum.toString();

    return {
      input,
      correctAnswer: answer,
      type: conversion.label,
      fromBase: conversion.from,
      toBase: conversion.to,
    };
  };

  const startQuiz = (selectedDifficulty: Difficulty) => {
    setDifficulty(selectedDifficulty);
    setScore(0);
    setCorrectCount(0);
    setQuestionNumber(1);
    setQuizComplete(false);
    setCurrentQuestion(generateQuestion(selectedDifficulty));
    setIsTimerActive(true);
    setTimeLeft(90);
    setFeedback(null);
    setUserAnswer("");
    setStartTime(Date.now());
  };

  const nextQuestion = () => {
    if (questionNumber >= totalQuestions) {
      setQuizComplete(true);
      setIsTimerActive(false);

      // Save quiz performance
      const quizzesTaken = parseInt(localStorage.getItem("quizzesTaken") || "0");
      localStorage.setItem("quizzesTaken", (quizzesTaken + 1).toString());

      // Save quiz history
      const timeSpent = Math.floor((Date.now() - startTime) / 1000);
      const quizHistoryItem = {
        id: Date.now().toString(),
        difficulty: difficulty || "low",
        score: correctCount,
        total: totalQuestions,
        timestamp: Date.now(),
        timeSpent,
      };

      const savedHistory = localStorage.getItem("quizHistory");
      const history = savedHistory ? JSON.parse(savedHistory) : [];
      history.unshift(quizHistoryItem);
      localStorage.setItem("quizHistory", JSON.stringify(history.slice(0, 100)));

      if (score >= totalQuestions * 0.7) {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      }
      return;
    }

    setQuestionNumber(questionNumber + 1);
    setCurrentQuestion(generateQuestion(difficulty));
    setUserAnswer("");
    setFeedback(null);
    setTimeLeft(90);
  };

  const checkAnswer = () => {
    if (!currentQuestion) return;

    const isCorrect = userAnswer.trim().toUpperCase() === currentQuestion.correctAnswer.toUpperCase();
    setFeedback(isCorrect ? "correct" : "incorrect");

    // Track in localStorage
    const quizTotal = parseInt(localStorage.getItem("quizTotal") || "0");
    localStorage.setItem("quizTotal", (quizTotal + 1).toString());

    if (isCorrect) {
      setScore(score + 1);
      setCorrectCount(correctCount + 1);
      const quizCorrect = parseInt(localStorage.getItem("quizCorrect") || "0");
      localStorage.setItem("quizCorrect", (quizCorrect + 1).toString());
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.7 } });
    }

    setIsTimerActive(false);

    setTimeout(() => {
      nextQuestion();
      setIsTimerActive(true);
    }, 2000);
  };

  useEffect(() => {
    if (!isTimerActive) return;

    if (timeLeft === 0) {
      setFeedback("incorrect");
      setIsTimerActive(false);
      setTimeout(() => {
        nextQuestion();
        setIsTimerActive(true);
      }, 2000);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isTimerActive]);

  const resetQuiz = () => {
    setDifficulty(null);
    setCurrentQuestion(null);
    setUserAnswer("");
    setFeedback(null);
    setQuizComplete(false);
    setScore(0);
    setQuestionNumber(1);
  };

  return (
    <div className={`min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-4xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl md:text-7xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent mb-2">
            Comprehensive Quiz
          </h1>
          <p className="text-xl text-slate-300">Test your conversion skills across all bases</p>
        </motion.div>

        {!difficulty && !quizComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-md border-2 border-cyan-500/30 rounded-2xl p-12 text-center"
          >
            <Target className="w-24 h-24 text-cyan-400 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-white mb-4">Select Difficulty Level</h2>
            <p className="text-slate-300 mb-8 max-w-md mx-auto">
              Answer {totalQuestions} questions (90 seconds each) across all number bases
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              <button
                onClick={() => startQuiz("low")}
                className="bg-gradient-to-br from-green-500/20 to-emerald-600/20 border-2 border-green-500/50 hover:border-green-400 rounded-xl p-6 transition-all hover:scale-105"
              >
                <div className="text-3xl font-bold text-green-400 mb-3">Low</div>
                <div className="text-sm text-slate-300 space-y-1">
                  <div>• Binary ↔ Decimal</div>
                  <div>• Numbers: 10-50</div>
                  <div>• 2 conversion types</div>
                </div>
              </button>

              <button
                onClick={() => startQuiz("medium")}
                className="bg-gradient-to-br from-yellow-500/20 to-orange-600/20 border-2 border-yellow-500/50 hover:border-yellow-400 rounded-xl p-6 transition-all hover:scale-105"
              >
                <div className="text-3xl font-bold text-yellow-400 mb-3">Medium</div>
                <div className="text-sm text-slate-300 space-y-1">
                  <div>• Binary ↔ Decimal ↔ Hex</div>
                  <div>• Numbers: 10-200</div>
                  <div>• 6 conversion types</div>
                </div>
              </button>

              <button
                onClick={() => startQuiz("high")}
                className="bg-gradient-to-br from-red-500/20 to-pink-600/20 border-2 border-red-500/50 hover:border-red-400 rounded-xl p-6 transition-all hover:scale-105"
              >
                <div className="text-3xl font-bold text-red-400 mb-3">High</div>
                <div className="text-sm text-slate-300 space-y-1">
                  <div>• All Bases + Octal</div>
                  <div>• Numbers: 10-1000</div>
                  <div>• 12 conversion types</div>
                </div>
              </button>
            </div>
          </motion.div>
        )}

        {currentQuestion && !quizComplete && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-center gap-4">
              <div className="bg-gradient-to-br from-cyan-500/10 to-blue-600/10 border-2 border-cyan-500/30 rounded-xl px-6 py-3">
                <div className="text-cyan-400 text-sm font-semibold">Question</div>
                <div className="text-white text-2xl font-bold">{questionNumber}/{totalQuestions}</div>
              </div>

              <div className="bg-gradient-to-br from-purple-500/10 to-pink-600/10 border-2 border-purple-500/30 rounded-xl px-6 py-3">
                <div className="text-purple-400 text-sm font-semibold">Score</div>
                <div className="text-white text-2xl font-bold">{score}</div>
              </div>

              <motion.div
                animate={{ scale: timeLeft < 15 ? [1, 1.1, 1] : 1 }}
                transition={{ repeat: timeLeft < 15 ? Infinity : 0, duration: 0.5 }}
                className={`bg-gradient-to-br ${
                  timeLeft < 15 ? "from-red-500/10 to-pink-600/10 border-red-500/30" : "from-green-500/10 to-emerald-600/10 border-green-500/30"
                } border-2 rounded-xl px-6 py-3`}
              >
                <div className={`${timeLeft < 15 ? "text-red-400" : "text-green-400"} text-sm font-semibold flex items-center gap-2`}>
                  <Timer className="w-4 h-4" />
                  Time
                </div>
                <div className={`${timeLeft < 15 ? "text-red-400" : "text-white"} text-2xl font-bold`}>
                  {timeLeft}s
                </div>
              </motion.div>
            </div>

            <motion.div
              key={questionNumber}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-md border-2 border-cyan-500/30 rounded-2xl p-8"
            >
              <div className="text-center mb-8">
                <div className="inline-block bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/50 rounded-lg px-4 py-2 mb-4">
                  <div className="text-cyan-400 font-semibold">{currentQuestion.type}</div>
                </div>
                <div className="text-6xl font-bold text-white font-mono mb-2">
                  {currentQuestion.input}
                </div>
                <p className="text-slate-400">Convert to {currentQuestion.toBase.charAt(0).toUpperCase() + currentQuestion.toBase.slice(1)}</p>
              </div>

              <div className="max-w-md mx-auto">
                <Input
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && !feedback && checkAnswer()}
                  placeholder="Enter your answer..."
                  disabled={!!feedback}
                  className="bg-slate-800/50 border-slate-600 text-white text-2xl h-16 font-mono text-center focus:border-cyan-500 mb-4"
                />

                <AnimatePresence>
                  {feedback && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`${
                        feedback === "correct"
                          ? "bg-green-500/20 border-green-500/50 text-green-400"
                          : "bg-red-500/20 border-red-500/50 text-red-400"
                      } border-2 rounded-lg p-4 mb-4 flex items-center justify-center gap-2`}
                    >
                      {feedback === "correct" ? (
                        <>
                          <CheckCircle2 className="w-5 h-5" />
                          <span className="font-semibold">Correct!</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-5 h-5" />
                          <span className="font-semibold">
                            Incorrect. Answer: {currentQuestion.correctAnswer}
                          </span>
                        </>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>

                {!feedback && (
                  <Button
                    onClick={checkAnswer}
                    disabled={!userAnswer.trim()}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-6 text-lg rounded-xl"
                  >
                    Submit Answer
                  </Button>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {quizComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-md border-2 border-cyan-500/30 rounded-2xl p-12 text-center"
          >
            <Trophy className="w-24 h-24 text-cyan-400 mx-auto mb-6" />
            <h2 className="text-4xl font-bold text-white mb-4">Quiz Complete!</h2>

            <div className="text-7xl font-bold bg-gradient-to-r from-cyan-400 to-purple-600 bg-clip-text text-transparent mb-4">
              {score}/{totalQuestions}
            </div>

            <p className="text-xl text-slate-300 mb-2">
              Difficulty: <span className="font-bold capitalize text-white">{difficulty}</span>
            </p>

            <p className="text-xl text-slate-400 mb-8">
              {score >= totalQuestions * 0.9
                ? "🏆 Outstanding! You're a master!"
                : score >= totalQuestions * 0.7
                ? "🎉 Great job! Keep practicing!"
                : score >= totalQuestions * 0.5
                ? "👍 Good effort! Review theory."
                : "📚 Keep learning! Practice more."}
            </p>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={resetQuiz}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-6 text-lg rounded-xl"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Try Again
              </Button>

              <Link to="/practice">
                <Button
                  variant="outline"
                  className="border-2 border-purple-500/50 text-purple-400 hover:bg-purple-500/10 px-8 py-6 text-lg rounded-xl"
                >
                  Practice More
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

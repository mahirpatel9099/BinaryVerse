import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Volume2, VolumeX, Copy, RotateCw, Zap, CheckCircle2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

export function ConversionDashboard() {
  const [binaryInput, setBinaryInput] = useState("");
  const [decimalInput, setDecimalInput] = useState("");
  const [result, setResult] = useState<{ value: string; type: string } | null>(null);
  const [steps, setSteps] = useState<string[]>([]);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [copied, setCopied] = useState(false);

  const playSound = () => {
    if (!soundEnabled) return;

    // Create a simple beep sound using Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = 800;
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  };

  const binaryToDecimal = (binary: string) => {
    const stepsArray: string[] = [];
    let decimal = 0;

    stepsArray.push(`Step 1: Write the binary number: ${binary}`);
    stepsArray.push(`Step 2: Assign position values (powers of 2):`);

    const calculations: string[] = [];
    for (let i = 0; i < binary.length; i++) {
      const position = binary.length - 1 - i;
      const bit = binary[i];
      const value = parseInt(bit) * Math.pow(2, position);
      decimal += value;
      calculations.push(`   ${bit} × 2^${position} = ${value}`);
    }

    stepsArray.push(...calculations);
    stepsArray.push(`Step 3: Add all values:`);
    stepsArray.push(`   ${calculations.map(c => c.split('= ')[1]).join(' + ')} = ${decimal}`);
    stepsArray.push(`✓ Final Answer: ${binary}₂ = ${decimal}₁₀`);

    return { value: decimal.toString(), steps: stepsArray };
  };

  const decimalToBinary = (decimal: string) => {
    const stepsArray: string[] = [];
    let num = parseInt(decimal);
    const remainders: string[] = [];

    stepsArray.push(`Step 1: Start with decimal: ${decimal}`);
    stepsArray.push(`Step 2: Divide by 2 repeatedly:`);

    while (num > 0) {
      const quotient = Math.floor(num / 2);
      const remainder = num % 2;
      stepsArray.push(`   ${num} ÷ 2 = ${quotient} remainder ${remainder}`);
      remainders.unshift(remainder.toString());
      num = quotient;
    }

    stepsArray.push(`Step 3: Read remainders from BOTTOM to TOP:`);
    stepsArray.push(`   ${remainders.join('')}`);
    stepsArray.push(`✓ Final Answer: ${decimal}₁₀ = ${remainders.join('')}₂`);

    return { value: remainders.join(''), steps: stepsArray };
  };

  const handleBinaryConvert = () => {
    if (!binaryInput.match(/^[01]+$/)) {
      alert("Please enter a valid binary number (only 0s and 1s)");
      return;
    }

    const { value, steps } = binaryToDecimal(binaryInput);
    setResult({ value, type: "decimal" });
    setSteps(steps);
    setDecimalInput(value);
    playSound();

    // Track conversion in localStorage
    const count = parseInt(localStorage.getItem("totalConversions") || "0");
    localStorage.setItem("totalConversions", (count + 1).toString());
  };

  const handleDecimalConvert = () => {
    if (!decimalInput.match(/^\d+$/)) {
      alert("Please enter a valid decimal number");
      return;
    }

    const { value, steps } = decimalToBinary(decimalInput);
    setResult({ value, type: "binary" });
    setSteps(steps);
    setBinaryInput(value);
    playSound();

    // Track conversion in localStorage
    const count = parseInt(localStorage.getItem("totalConversions") || "0");
    localStorage.setItem("totalConversions", (count + 1).toString());
  };

  const handleCopy = () => {
    if (result) {
      navigator.clipboard.writeText(result.value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleReset = () => {
    setBinaryInput("");
    setDecimalInput("");
    setResult(null);
    setSteps([]);
  };

  return (
    <div className="relative min-h-screen px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Link to="/">
            <Button variant="ghost" className="text-primary hover:bg-primary/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>

          <Button
            onClick={() => setSoundEnabled(!soundEnabled)}
            variant="outline"
            size="icon"
            className="border-2"
          >
            {soundEnabled ? (
              <Volume2 className="w-5 h-5 text-primary" />
            ) : (
              <VolumeX className="w-5 h-5 text-muted-foreground" />
            )}
          </Button>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-2 bg-gradient-to-r from-primary via-blue-500 to-purple-600 bg-clip-text text-transparent">
            Conversion Dashboard
          </h1>
          <p className="text-muted-foreground text-lg">Binary ↔ Decimal Converter</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Binary Input */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card border-2 border-primary/20 rounded-2xl p-6 shadow-lg backdrop-blur-sm"
          >
            <Label className="text-lg font-bold text-primary mb-4 block">
              Binary Input
            </Label>
            <Input
              value={binaryInput}
              onChange={(e) => setBinaryInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleBinaryConvert()}
              placeholder="Enter binary (e.g., 1010)"
              className="h-16 text-2xl font-mono text-center mb-4 bg-input-background border-2 border-primary/30 focus:border-primary"
            />
            <Button
              onClick={handleBinaryConvert}
              className="w-full h-12 bg-gradient-to-r from-primary to-blue-600 hover:from-primary/90 hover:to-blue-700 text-primary-foreground shadow-lg shadow-primary/30"
            >
              <Zap className="w-5 h-5 mr-2" />
              Convert to Decimal
            </Button>
          </motion.div>

          {/* Decimal Input */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="bg-card border-2 border-green-500/20 rounded-2xl p-6 shadow-lg backdrop-blur-sm"
          >
            <Label className="text-lg font-bold text-green-500 mb-4 block">
              Decimal Input
            </Label>
            <Input
              value={decimalInput}
              onChange={(e) => setDecimalInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleDecimalConvert()}
              placeholder="Enter decimal (e.g., 10)"
              className="h-16 text-2xl font-mono text-center mb-4 bg-input-background border-2 border-green-500/30 focus:border-green-500"
            />
            <Button
              onClick={handleDecimalConvert}
              className="w-full h-12 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white shadow-lg shadow-green-500/30"
            >
              <Zap className="w-5 h-5 mr-2" />
              Convert to Binary
            </Button>
          </motion.div>
        </div>

        {/* Result Panel */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mb-8"
            >
              <div className="bg-card border-2 border-purple-500/30 rounded-2xl p-8 shadow-2xl backdrop-blur-sm">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold text-purple-500">Result</h2>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleCopy}
                      variant="outline"
                      size="sm"
                      className="border-2"
                    >
                      {copied ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 mr-2 text-green-500" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-2" />
                          Copy
                        </>
                      )}
                    </Button>
                    <Button
                      onClick={handleReset}
                      variant="outline"
                      size="sm"
                      className="border-2"
                    >
                      <RotateCw className="w-4 h-4 mr-2" />
                      Reset
                    </Button>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 border-2 border-purple-500/40 rounded-xl p-6 mb-6">
                  <div className="text-center">
                    <div className="text-5xl md:text-7xl font-bold font-mono text-purple-500 break-all">
                      {result.value}
                    </div>
                    <div className="text-muted-foreground mt-2">
                      {result.type === "binary" ? "Binary" : "Decimal"}
                    </div>
                  </div>
                </div>

                {/* Step-by-Step Explanation */}
                <div className="bg-muted/50 rounded-xl p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-primary" />
                    Step-by-Step Explanation
                  </h3>
                  <div className="space-y-2 font-mono text-sm">
                    {steps.map((step, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className={`${
                          step.startsWith('✓')
                            ? 'text-green-500 font-bold text-base'
                            : 'text-foreground'
                        } leading-relaxed`}
                      >
                        {step}
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Quick Examples */}
        {!result && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-card/50 border border-border rounded-xl p-6"
          >
            <h3 className="text-lg font-bold mb-4">Quick Examples:</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center text-sm">
              <button
                onClick={() => { setBinaryInput("1010"); handleBinaryConvert(); }}
                className="bg-muted hover:bg-muted/80 rounded-lg p-3 transition-colors"
              >
                <div className="font-mono font-bold text-primary">1010₂</div>
                <div className="text-muted-foreground text-xs">= 10₁₀</div>
              </button>
              <button
                onClick={() => { setBinaryInput("1111"); handleBinaryConvert(); }}
                className="bg-muted hover:bg-muted/80 rounded-lg p-3 transition-colors"
              >
                <div className="font-mono font-bold text-primary">1111₂</div>
                <div className="text-muted-foreground text-xs">= 15₁₀</div>
              </button>
              <button
                onClick={() => { setDecimalInput("25"); handleDecimalConvert(); }}
                className="bg-muted hover:bg-muted/80 rounded-lg p-3 transition-colors"
              >
                <div className="font-mono font-bold text-green-500">25₁₀</div>
                <div className="text-muted-foreground text-xs">= 11001₂</div>
              </button>
              <button
                onClick={() => { setDecimalInput("42"); handleDecimalConvert(); }}
                className="bg-muted hover:bg-muted/80 rounded-lg p-3 transition-colors"
              >
                <div className="font-mono font-bold text-green-500">42₁₀</div>
                <div className="text-muted-foreground text-xs">= 101010₂</div>
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

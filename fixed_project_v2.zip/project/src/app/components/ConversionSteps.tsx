import { motion } from "motion/react";
import { CheckCircle2, ChevronRight } from "lucide-react";

interface ConversionStepsProps {
  input: string;
  output: string;
  conversionType: string;
}

export function ConversionSteps({ input, output, conversionType }: ConversionStepsProps) {
  const renderBinaryToDecimalSteps = () => {
    const binary = input.trim();
    const steps: { position: number; bit: string; value: number; calc: string }[] = [];
    let total = 0;

    for (let i = 0; i < binary.length; i++) {
      const position = binary.length - 1 - i;
      const bit = binary[i];
      const powerOfTwo = Math.pow(2, position);
      const value = parseInt(bit) * powerOfTwo;
      total += value;

      steps.push({
        position,
        bit,
        value,
        calc: `${bit} × 2^${position} = ${value}`
      });
    }

    return (
      <div className="space-y-6">
        <div>
          <h4 className="text-cyan-300 font-semibold mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            Step 1: Identify Bit Positions
          </h4>
          <div className="bg-slate-900/50 rounded-lg p-4 overflow-x-auto">
            <div className="flex gap-4 font-mono text-sm justify-center flex-wrap">
              {steps.map((step, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="text-center"
                >
                  <div className="text-2xl text-cyan-400 font-bold mb-1">{step.bit}</div>
                  <ChevronRight className="w-4 h-4 text-blue-400 mx-auto mb-1" />
                  <div className="text-blue-200/70">{step.calc}</div>
                  <div className="text-green-400 font-bold mt-1">{step.value}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-cyan-300 font-semibold mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            Step 2: Add All Values
          </h4>
          <div className="bg-slate-900/50 rounded-lg p-4">
            <div className="text-center font-mono">
              <div className="text-blue-200/70 mb-2">
                {steps.map(s => s.value).join(" + ")} = <span className="text-green-400 font-bold text-2xl">{total}</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/40 rounded-lg p-4">
          <div className="text-center">
            <div className="text-green-300 mb-1">Final Answer</div>
            <div className="text-3xl font-bold text-green-400">{output}</div>
          </div>
        </div>
      </div>
    );
  };

  const renderDecimalToBinarySteps = () => {
    const decimal = parseInt(input.trim(), 10);
    const steps: { dividend: number; quotient: number; remainder: number }[] = [];
    let num = decimal;

    while (num > 0) {
      const quotient = Math.floor(num / 2);
      const remainder = num % 2;
      steps.push({ dividend: num, quotient, remainder });
      num = quotient;
    }

    return (
      <div className="space-y-6">
        <div>
          <h4 className="text-cyan-300 font-semibold mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            Step 1: Repeated Division by 2
          </h4>
          <div className="bg-slate-900/50 rounded-lg p-4 overflow-x-auto">
            <div className="space-y-2 font-mono text-sm">
              {steps.map((step, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="flex items-center gap-3 bg-slate-800/50 rounded p-2"
                >
                  <div className="text-cyan-400 w-16 text-right">{step.dividend}</div>
                  <div className="text-blue-300">÷ 2 =</div>
                  <div className="text-purple-400 w-16">{step.quotient}</div>
                  <div className="text-blue-300">remainder</div>
                  <div className="text-green-400 font-bold text-lg">{step.remainder}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <h4 className="text-cyan-300 font-semibold mb-3 flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" />
            Step 2: Read Remainders from Bottom to Top
          </h4>
          <div className="bg-slate-900/50 rounded-lg p-4">
            <div className="flex items-center justify-center gap-2 flex-wrap font-mono">
              {steps.reverse().map((step, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.1 }}
                  className="text-3xl text-green-400 font-bold"
                >
                  {step.remainder}
                </motion.div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/40 rounded-lg p-4">
          <div className="text-center">
            <div className="text-green-300 mb-1">Final Answer</div>
            <div className="text-3xl font-bold text-green-400">{output}</div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-8 overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl" />

      <div className="relative">
        <h3 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
          <span className="text-purple-400">⚡</span>
          Step-by-Step Explanation
        </h3>

        {conversionType === "Binary → Decimal" && renderBinaryToDecimalSteps()}
        {conversionType === "Decimal → Binary" && renderDecimalToBinarySteps()}
        {(conversionType === "Hexadecimal → Binary" || conversionType === "Octal → Binary") && (
          <div className="text-blue-200/70">
            <p className="mb-2">
              First converted {conversionType.split(" → ")[0]} to Decimal, then Decimal to Binary.
            </p>
            <p className="text-sm text-blue-300/50">
              Advanced step-by-step for {conversionType.split(" → ")[0]} conversions coming soon!
            </p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

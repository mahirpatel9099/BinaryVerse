import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, ArrowRight, History, Trash2 } from "lucide-react";
import { ConversionSteps } from "./ConversionSteps";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface ConversionHistory {
  id: string;
  input: string;
  output: string;
  type: string;
  timestamp: Date;
}

export function ConverterPage() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [conversionType, setConversionType] = useState("");
  const [showSteps, setShowSteps] = useState(false);
  const [history, setHistory] = useState<ConversionHistory[]>([]);
  const [showHistory, setShowHistory] = useState(false);

  const detectInputType = (value: string): string => {
    if (!value) return "unknown";
    if (/^0x[0-9A-Fa-f]+$/.test(value)) return "hexadecimal";
    if (/^0o[0-7]+$/.test(value)) return "octal";
    if (/^[01]+$/.test(value)) return "binary";
    if (/^[0-9]+$/.test(value)) return "decimal";
    return "invalid";
  };

  const binaryToDecimal = (binary: string): number => {
    return parseInt(binary, 2);
  };

  const decimalToBinary = (decimal: number): string => {
    return decimal.toString(2);
  };

  const handleConvert = () => {
    const trimmedInput = input.trim();
    if (!trimmedInput) return;

    const inputType = detectInputType(trimmedInput);
    let result = "";
    let type = "";

    if (inputType === "binary") {
      result = binaryToDecimal(trimmedInput).toString();
      type = "Binary → Decimal";
    } else if (inputType === "decimal") {
      const num = parseInt(trimmedInput, 10);
      result = decimalToBinary(num);
      type = "Decimal → Binary";
    } else if (inputType === "hexadecimal") {
      const hex = trimmedInput.substring(2);
      const decimal = parseInt(hex, 16);
      result = decimalToBinary(decimal);
      type = "Hexadecimal → Binary";
    } else if (inputType === "octal") {
      const oct = trimmedInput.substring(2);
      const decimal = parseInt(oct, 8);
      result = decimalToBinary(decimal);
      type = "Octal → Binary";
    } else {
      result = "Invalid input";
      type = "Error";
    }

    setOutput(result);
    setConversionType(type);
    setShowSteps(type !== "Error");

    if (type !== "Error") {
      setHistory(prev => [
        {
          id: Date.now().toString(),
          input: trimmedInput,
          output: result,
          type,
          timestamp: new Date()
        },
        ...prev.slice(0, 9)
      ]);
    }
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <div className="relative z-10 min-h-screen px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-2">
            Conversion Engine
          </h1>
          <p className="text-blue-200/70">Enter any number and watch the magic happen</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-2 space-y-6 w-full"
          >
            <div className="relative bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-8 overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl" />

              <div className="relative space-y-6">
                <div>
                  <Label htmlFor="input" className="text-cyan-300 mb-2 block">
                    Input Number
                  </Label>
                  <Input
                    id="input"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleConvert()}
                    placeholder="Enter: 1010, 25, 0x1A, 0o17..."
                    className="bg-slate-950/50 border-cyan-500/30 text-white text-2xl h-16 font-mono focus:border-cyan-400 focus:ring-cyan-400/50"
                  />
                  <p className="text-xs text-blue-300/50 mt-2">
                    Detected: <span className="text-cyan-400 font-semibold">{detectInputType(input)}</span>
                  </p>
                </div>

                <div className="flex items-center justify-center">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Button
                      onClick={handleConvert}
                      className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg shadow-cyan-500/50"
                    >
                      Convert
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </motion.div>
                </div>

                <AnimatePresence>
                  {output && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                    >
                      <Label className="text-green-300 mb-2 block">
                        Output
                      </Label>
                      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl p-6">
                        <div className="text-4xl font-bold font-mono text-green-400 break-all">
                          {output}
                        </div>
                        <p className="text-sm text-green-300/70 mt-2">{conversionType}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {showSteps && (
              <ConversionSteps
                input={input}
                output={output}
                conversionType={conversionType}
              />
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-6 w-full"
          >
            <div className="relative bg-gradient-to-br from-purple-800/30 to-purple-900/30 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-6 overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl" />

              <div className="flex items-center justify-between mb-4 relative">
                <div className="flex items-center gap-2">
                  <History className="w-5 h-5 text-purple-400" />
                  <h3 className="text-lg font-bold text-white">History</h3>
                </div>
                {history.length > 0 && (
                  <Button
                    onClick={clearHistory}
                    variant="ghost"
                    size="sm"
                    className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto relative">
                {history.length === 0 ? (
                  <p className="text-purple-200/50 text-sm text-center py-8">
                    No conversions yet
                  </p>
                ) : (
                  history.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="bg-slate-900/50 border border-purple-500/20 rounded-lg p-3 hover:border-purple-500/40 transition-colors cursor-pointer"
                      onClick={() => {
                        setInput(item.input);
                        setOutput(item.output);
                        setConversionType(item.type);
                        setShowSteps(true);
                      }}
                    >
                      <div className="text-xs text-purple-300/60 mb-1">{item.type}</div>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-cyan-400 font-mono">{item.input}</span>
                        <ArrowRight className="w-3 h-3 text-purple-400" />
                        <span className="text-green-400 font-mono">{item.output}</span>
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </div>

            <div className="relative bg-gradient-to-br from-blue-800/30 to-blue-900/30 backdrop-blur-xl border border-blue-500/30 rounded-2xl p-6">
              <h3 className="text-lg font-bold text-white mb-4">Quick Guide</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <div className="text-cyan-400 font-semibold">Binary</div>
                  <div className="text-blue-200/70 font-mono">1010, 11001</div>
                </div>
                <div>
                  <div className="text-green-400 font-semibold">Decimal</div>
                  <div className="text-blue-200/70 font-mono">25, 42</div>
                </div>
                <div>
                  <div className="text-purple-400 font-semibold">Hexadecimal</div>
                  <div className="text-blue-200/70 font-mono">0x1A, 0xFF</div>
                </div>
                <div>
                  <div className="text-yellow-400 font-semibold">Octal</div>
                  <div className="text-blue-200/70 font-mono">0o17, 0o77</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

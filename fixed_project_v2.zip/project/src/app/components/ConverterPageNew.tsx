import { useState } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, ArrowRight, History, Trash2, Binary } from "lucide-react";
import { ConversionSteps } from "./ConversionSteps";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface ConversionResults {
  binary: string;
  decimal: string;
  hexadecimal: string;
  octal: string;
}

interface ConversionHistory {
  id: string;
  input: string;
  inputType: string;
  results: ConversionResults;
  timestamp: Date;
}

export function ConverterPageNew() {
  const [input, setInput] = useState("");
  const [results, setResults] = useState<ConversionResults | null>(null);
  const [inputType, setInputType] = useState("");
  const [history, setHistory] = useState<ConversionHistory[]>([]);

  const detectInputType = (value: string): string => {
    if (!value) return "unknown";
    if (/^0x[0-9A-Fa-f]+$/.test(value)) return "hexadecimal";
    if (/^0o[0-7]+$/.test(value)) return "octal";
    if (/^[01]+$/.test(value)) return "binary";
    if (/^[0-9]+$/.test(value)) return "decimal";
    return "invalid";
  };

  const convertToAllBases = (value: string, type: string): ConversionResults | null => {
    try {
      let decimalValue: number;

      switch (type) {
        case "binary":
          decimalValue = parseInt(value, 2);
          break;
        case "decimal":
          decimalValue = parseInt(value, 10);
          break;
        case "hexadecimal":
          decimalValue = parseInt(value.substring(2), 16);
          break;
        case "octal":
          decimalValue = parseInt(value.substring(2), 8);
          break;
        default:
          return null;
      }

      if (isNaN(decimalValue)) return null;

      return {
        binary: decimalValue.toString(2),
        decimal: decimalValue.toString(10),
        hexadecimal: decimalValue.toString(16).toUpperCase(),
        octal: decimalValue.toString(8)
      };
    } catch (error) {
      return null;
    }
  };

  const handleConvert = () => {
    const trimmedInput = input.trim();
    if (!trimmedInput) return;

    const type = detectInputType(trimmedInput);
    if (type === "invalid" || type === "unknown") {
      alert("Invalid input! Please enter a valid number.");
      return;
    }

    const conversionResults = convertToAllBases(trimmedInput, type);
    if (!conversionResults) {
      alert("Conversion failed! Please check your input.");
      return;
    }

    setResults(conversionResults);
    setInputType(type);

    setHistory(prev => [
      {
        id: Date.now().toString(),
        input: trimmedInput,
        inputType: type,
        results: conversionResults,
        timestamp: new Date()
      },
      ...prev.slice(0, 9)
    ]);
  };

  const clearHistory = () => {
    setHistory([]);
  };

  const loadFromHistory = (item: ConversionHistory) => {
    setInput(item.input);
    setResults(item.results);
    setInputType(item.inputType);
  };

  return (
    <div className="relative min-h-screen px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-blue-700 hover:text-blue-900 hover:bg-blue-50">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="flex items-center justify-center gap-3 mb-4">
            <Binary className="w-10 h-10 text-blue-600" />
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900">
              Universal Number Converter
            </h1>
          </div>
          <p className="text-gray-600 text-lg">Enter any number and convert to all bases instantly</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="lg:col-span-3 space-y-6"
          >
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-8">
              <div className="space-y-6">
                <div>
                  <Label htmlFor="input" className="text-gray-700 mb-2 block text-lg font-semibold">
                    Input Number
                  </Label>
                  <Input
                    id="input"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && handleConvert()}
                    placeholder="Enter: 1010, 25, 0x1A, 0o17..."
                    className="bg-gray-50 border-gray-300 text-gray-900 text-xl h-14 font-mono focus:border-blue-500 focus:ring-blue-500"
                  />
                  {input && (
                    <p className="text-sm text-gray-500 mt-2">
                      Detected Type: <span className="text-blue-600 font-semibold capitalize">{detectInputType(input)}</span>
                    </p>
                  )}
                </div>

                <div className="flex justify-center">
                  <Button
                    onClick={handleConvert}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-xl shadow-md"
                  >
                    Convert to All Bases
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Button>
                </div>

                <AnimatePresence>
                  {results && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -20 }}
                      className="grid grid-cols-1 md:grid-cols-2 gap-4"
                    >
                      <div className="bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-300 rounded-xl p-6">
                        <div className="text-sm font-semibold text-blue-700 mb-2">BINARY</div>
                        <div className="text-3xl font-bold font-mono text-blue-900 break-all">
                          {results.binary}₂
                        </div>
                      </div>

                      <div className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-300 rounded-xl p-6">
                        <div className="text-sm font-semibold text-green-700 mb-2">DECIMAL</div>
                        <div className="text-3xl font-bold font-mono text-green-900 break-all">
                          {results.decimal}₁₀
                        </div>
                      </div>

                      <div className="bg-gradient-to-br from-purple-50 to-purple-100 border-2 border-purple-300 rounded-xl p-6">
                        <div className="text-sm font-semibold text-purple-700 mb-2">HEXADECIMAL</div>
                        <div className="text-3xl font-bold font-mono text-purple-900 break-all">
                          {results.hexadecimal}₁₆
                        </div>
                      </div>

                      <div className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-300 rounded-xl p-6">
                        <div className="text-sm font-semibold text-orange-700 mb-2">OCTAL</div>
                        <div className="text-3xl font-bold font-mono text-orange-900 break-all">
                          {results.octal}₈
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {results && inputType && (
              <ConversionSteps
                input={input}
                output={results.decimal}
                conversionType={`${inputType.charAt(0).toUpperCase() + inputType.slice(1)} → All Bases`}
              />
            )}
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="w-full"
          >
            <div className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 sticky top-8">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <History className="w-5 h-5 text-purple-600" />
                  <h3 className="text-lg font-bold text-gray-900">History</h3>
                </div>
                {history.length > 0 && (
                  <Button
                    onClick={clearHistory}
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto">
                {history.length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-8">
                    No conversions yet
                  </p>
                ) : (
                  history.map((item) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      className="bg-gray-50 border border-gray-200 rounded-lg p-3 hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer"
                      onClick={() => loadFromHistory(item)}
                    >
                      <div className="text-xs text-gray-500 mb-1 capitalize">{item.inputType}</div>
                      <div className="text-sm font-mono text-gray-900 font-semibold">
                        {item.input}
                      </div>
                      <div className="text-xs text-gray-600 mt-1">
                        → {item.results.decimal} (Dec)
                      </div>
                    </motion.div>
                  ))
                )}
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-2xl border border-blue-200 p-6 mt-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Guide</h3>
              <div className="space-y-3 text-sm">
                <div>
                  <div className="text-blue-700 font-semibold">Binary</div>
                  <div className="text-gray-600 font-mono">1010, 11001</div>
                </div>
                <div>
                  <div className="text-green-700 font-semibold">Decimal</div>
                  <div className="text-gray-600 font-mono">25, 42</div>
                </div>
                <div>
                  <div className="text-purple-700 font-semibold">Hexadecimal</div>
                  <div className="text-gray-600 font-mono">0x1A, 0xFF</div>
                </div>
                <div>
                  <div className="text-orange-700 font-semibold">Octal</div>
                  <div className="text-gray-600 font-mono">0o17, 0o77</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}

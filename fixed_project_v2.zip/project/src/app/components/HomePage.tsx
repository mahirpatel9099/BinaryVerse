import { Link } from "react-router";
import { motion } from "motion/react";
import { Binary, BookOpen, Trophy, Cpu, Zap, Brain, Target } from "lucide-react";

export function HomePage() {
  return (
    <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center mb-12"
      >
        <div className="flex items-center justify-center gap-4 mb-6">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <Cpu className="w-16 h-16 text-cyan-400" strokeWidth={1.5} />
          </motion.div>
          <h1 className="text-6xl md:text-8xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            BinaryVerse
          </h1>
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-xl md:text-2xl text-cyan-300 font-light tracking-wide"
        >
          Learn number conversion like you're operating a futuristic computer system
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-4 text-sm text-blue-300/70 tracking-widest"
        >
          COMPUTER ORGANIZATION & ARCHITECTURE • DIGITAL ELECTRONICS
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.6 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl w-full mb-12 px-4"
      >
        <Link to="/converter">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-gradient-to-br from-cyan-500/10 to-blue-600/10 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-8 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/0 to-blue-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <Binary className="w-12 h-12 text-cyan-400 mb-4 relative z-10" />
            <h3 className="text-2xl font-bold text-white mb-2 relative z-10">Converter</h3>
            <p className="text-blue-200/70 relative z-10">
              Convert with step-by-step explanations
            </p>
            <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-3xl group-hover:bg-cyan-500/20 transition-all" />
          </motion.div>
        </Link>

        <Link to="/learn">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-gradient-to-br from-purple-500/10 to-pink-600/10 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-8 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/0 to-pink-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <BookOpen className="w-12 h-12 text-purple-400 mb-4 relative z-10" />
            <h3 className="text-2xl font-bold text-white mb-2 relative z-10">Learn Theory</h3>
            <p className="text-purple-200/70 relative z-10">
              Master all number systems easily
            </p>
            <div className="absolute top-0 right-0 w-32 h-32 bg-purple-500/10 rounded-full blur-3xl group-hover:bg-purple-500/20 transition-all" />
          </motion.div>
        </Link>

        <Link to="/practice">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-gradient-to-br from-orange-500/10 to-red-600/10 backdrop-blur-xl border border-orange-500/30 rounded-2xl p-8 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/0 to-red-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <Target className="w-12 h-12 text-orange-400 mb-4 relative z-10" />
            <h3 className="text-2xl font-bold text-white mb-2 relative z-10">Practice</h3>
            <p className="text-orange-200/70 relative z-10">
              Unlimited practice problems
            </p>
            <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/10 rounded-full blur-3xl group-hover:bg-orange-500/20 transition-all" />
          </motion.div>
        </Link>

        <Link to="/quiz">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-gradient-to-br from-green-500/10 to-emerald-600/10 backdrop-blur-xl border border-green-500/30 rounded-2xl p-8 cursor-pointer overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/0 to-emerald-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            <Trophy className="w-12 h-12 text-green-400 mb-4 relative z-10" />
            <h3 className="text-2xl font-bold text-white mb-2 relative z-10">Timed Quiz</h3>
            <p className="text-green-200/70 relative z-10">
              Test yourself with timer
            </p>
            <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/10 rounded-full blur-3xl group-hover:bg-green-500/20 transition-all" />
          </motion.div>
        </Link>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl w-full text-center px-4"
      >
        <div className="flex flex-col items-center">
          <Zap className="w-8 h-8 text-yellow-400 mb-2" />
          <h4 className="text-white font-semibold mb-1">Smart Detection</h4>
          <p className="text-sm text-blue-200/60">Auto-detect input type</p>
        </div>
        <div className="flex flex-col items-center">
          <Brain className="w-8 h-8 text-pink-400 mb-2" />
          <h4 className="text-white font-semibold mb-1">Step-by-Step</h4>
          <p className="text-sm text-blue-200/60">Detailed explanations</p>
        </div>
        <div className="flex flex-col items-center">
          <Cpu className="w-8 h-8 text-cyan-400 mb-2" />
          <h4 className="text-white font-semibold mb-1">COA-Themed</h4>
          <p className="text-sm text-blue-200/60">Futuristic processor UI</p>
        </div>
      </motion.div>
    </div>
  );
}

import { Link } from "react-router";
import { motion } from "motion/react";
import { Binary, BookOpen, Trophy, Target, Cpu } from "lucide-react";

export function HomePageNew() {
  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-center mb-12 max-w-4xl"
      >
        <div className="flex items-center justify-center gap-4 mb-6">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <Cpu className="w-16 h-16 text-blue-600" strokeWidth={1.5} />
          </motion.div>
          <h1 className="text-5xl md:text-7xl font-black bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 bg-clip-text text-transparent">
            BinaryVerse
          </h1>
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="text-xl md:text-2xl text-gray-700 font-medium tracking-wide mb-4"
        >
          Professional Number System Converter
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-4 text-sm text-gray-500 tracking-wide"
        >
          COMPUTER ORGANIZATION & ARCHITECTURE • DIGITAL ELECTRONICS • ENGINEERING
        </motion.div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.6 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl w-full mb-12 px-4"
      >
        <Link to="/converter">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-white border-2 border-blue-200 hover:border-blue-400 rounded-2xl p-8 cursor-pointer shadow-lg hover:shadow-xl transition-all"
          >
            <Binary className="w-12 h-12 text-blue-600 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Converter</h3>
            <p className="text-gray-600">
              Convert to all bases instantly
            </p>
          </motion.div>
        </Link>

        <Link to="/learn">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-white border-2 border-purple-200 hover:border-purple-400 rounded-2xl p-8 cursor-pointer shadow-lg hover:shadow-xl transition-all"
          >
            <BookOpen className="w-12 h-12 text-purple-600 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Learn Theory</h3>
            <p className="text-gray-600">
              Complete study materials
            </p>
          </motion.div>
        </Link>

        <Link to="/practice">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-white border-2 border-orange-200 hover:border-orange-400 rounded-2xl p-8 cursor-pointer shadow-lg hover:shadow-xl transition-all"
          >
            <Target className="w-12 h-12 text-orange-600 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Practice</h3>
            <p className="text-gray-600">
              Unlimited problems
            </p>
          </motion.div>
        </Link>

        <Link to="/quiz">
          <motion.div
            whileHover={{ scale: 1.05, y: -5 }}
            className="group relative bg-white border-2 border-green-200 hover:border-green-400 rounded-2xl p-8 cursor-pointer shadow-lg hover:shadow-xl transition-all"
          >
            <Trophy className="w-12 h-12 text-green-600 mb-4" />
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Timed Quiz</h3>
            <p className="text-gray-600">
              Test with difficulty levels
            </p>
          </motion.div>
        </Link>
      </motion.div>

    </div>
  );
}

export function HomePageTest() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <h1 className="text-4xl font-bold">BinaryVerse - Test</h1>
    </div>
  );
}

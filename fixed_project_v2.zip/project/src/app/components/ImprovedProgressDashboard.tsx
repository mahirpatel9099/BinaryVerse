import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Trophy,
  Target,
  Zap,
  TrendingUp,
  Calendar,
  Activity,
} from "lucide-react";
import { Button } from "./ui/button";
import { useTheme } from "../contexts/ThemeContext";

interface ProgressStats {
  totalConversions: number;
  gameHighScore: number;
  gamesPlayed: number;
  quizzesTaken: number;
  quizCorrect: number;
  quizTotal: number;
  practiceCompleted: number;
  practiceCorrect: number;
  practiceTotal: number;
  dailyStreak: number;
  level: number;
}

export function ImprovedProgressDashboard() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [stats, setStats] = useState<ProgressStats>({
    totalConversions: 0,
    gameHighScore: 0,
    gamesPlayed: 0,
    quizzesTaken: 0,
    quizCorrect: 0,
    quizTotal: 0,
    practiceCompleted: 0,
    practiceCorrect: 0,
    practiceTotal: 0,
    dailyStreak: 0,
    level: 1,
  });

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = () => {
    const conversions = parseInt(localStorage.getItem("totalConversions") || "0");
    const gameScore = parseInt(localStorage.getItem("gameHighScore") || "0");
    const gamesPlayed = parseInt(localStorage.getItem("gamesPlayed") || "0");
    const quizzesTaken = parseInt(localStorage.getItem("quizzesTaken") || "0");
    const quizCorrect = parseInt(localStorage.getItem("quizCorrect") || "0");
    const quizTotal = parseInt(localStorage.getItem("quizTotal") || "0");
    const practiceCompleted = parseInt(localStorage.getItem("practiceCompleted") || "0");
    const practiceCorrect = parseInt(localStorage.getItem("practiceCorrect") || "0");
    const practiceTotal = parseInt(localStorage.getItem("practiceTotal") || "0");
    const dailyStreak = parseInt(localStorage.getItem("dailyStreak") || "0");

    const level = Math.floor(conversions / 10) + 1;

    setStats({
      totalConversions: conversions,
      gameHighScore: gameScore,
      gamesPlayed,
      quizzesTaken,
      quizCorrect,
      quizTotal,
      practiceCompleted,
      practiceCorrect,
      practiceTotal,
      dailyStreak,
      level,
    });
  };

  const calculateAccuracy = (correct: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((correct / total) * 100);
  };

  const quizAccuracy = calculateAccuracy(stats.quizCorrect, stats.quizTotal);
  const practiceAccuracy = calculateAccuracy(stats.practiceCorrect, stats.practiceTotal);

  return (
    <div className={`min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button
              variant="ghost"
              className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            Your Progress
          </h1>
          <p className="text-xl text-slate-400">Track your learning journey</p>
        </motion.div>

        {/* Level Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-gradient-to-br from-cyan-500/5 to-blue-600/5 border border-cyan-500/20 rounded-2xl p-8 mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-4xl font-bold text-white mb-2">Level {stats.level}</h2>
              <p className="text-slate-400">
                {stats.totalConversions % 10}/10 conversions to next level
              </p>
            </div>
            <Zap className="w-16 h-16 text-cyan-400" />
          </div>
          <div className="w-full bg-slate-800 rounded-full h-4 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(stats.totalConversions % 10) * 10}%` }}
              transition={{ duration: 1, delay: 0.3 }}
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
            />
          </div>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-cyan-500/5 to-blue-600/5 border border-cyan-500/20 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-8 h-8 text-cyan-400" />
              <div className="text-right">
                <div className="text-4xl font-bold text-white">{stats.totalConversions}</div>
                <div className="text-sm text-slate-400">Total Conversions</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="bg-gradient-to-br from-purple-500/5 to-pink-600/5 border border-purple-500/20 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Trophy className="w-8 h-8 text-purple-400" />
              <div className="text-right">
                <div className="text-4xl font-bold text-white">{stats.gameHighScore}</div>
                <div className="text-sm text-slate-400">Game High Score</div>
              </div>
            </div>
            <div className="text-xs text-slate-500">
              {stats.gamesPlayed} games played
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="bg-gradient-to-br from-orange-500/5 to-yellow-600/5 border border-orange-500/20 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Calendar className="w-8 h-8 text-orange-400" />
              <div className="text-right">
                <div className="text-4xl font-bold text-white">{stats.dailyStreak}</div>
                <div className="text-sm text-slate-400">Day Streak</div>
              </div>
            </div>
            <div className="text-xs text-slate-500">
              Keep learning daily! 🔥
            </div>
          </motion.div>
        </div>

        {/* Detailed Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Quiz Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-gradient-to-br from-blue-500/5 to-indigo-600/5 border border-blue-500/20 rounded-2xl p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <Target className="w-8 h-8 text-blue-400" />
              <h3 className="text-2xl font-bold text-white">Quiz Performance</h3>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Quizzes Taken</span>
                <span className="text-2xl font-bold text-white">{stats.quizzesTaken}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Questions Answered</span>
                <span className="text-2xl font-bold text-white">{stats.quizTotal}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Correct Answers</span>
                <span className="text-2xl font-bold text-green-400">{stats.quizCorrect}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Accuracy</span>
                <span className="text-2xl font-bold text-cyan-400">{quizAccuracy}%</span>
              </div>

              {stats.quizTotal > 0 && (
                <div className="mt-4">
                  <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-blue-400 to-cyan-500 rounded-full"
                      style={{ width: `${quizAccuracy}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </motion.div>

          {/* Practice Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-gradient-to-br from-green-500/5 to-emerald-600/5 border border-green-500/20 rounded-2xl p-6"
          >
            <div className="flex items-center gap-3 mb-6">
              <TrendingUp className="w-8 h-8 text-green-400" />
              <h3 className="text-2xl font-bold text-white">Practice Performance</h3>
            </div>

            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Practice Sessions</span>
                <span className="text-2xl font-bold text-white">{stats.practiceCompleted}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Questions Answered</span>
                <span className="text-2xl font-bold text-white">{stats.practiceTotal}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Correct Answers</span>
                <span className="text-2xl font-bold text-green-400">{stats.practiceCorrect}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-slate-400">Accuracy</span>
                <span className="text-2xl font-bold text-cyan-400">{practiceAccuracy}%</span>
              </div>

              {stats.practiceTotal > 0 && (
                <div className="mt-4">
                  <div className="w-full bg-slate-800 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-green-400 to-emerald-500 rounded-full"
                      style={{ width: `${practiceAccuracy}%` }}
                    />
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-12 text-center"
        >
          <Link to="/converter">
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg shadow-cyan-500/50">
              Continue Learning
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}

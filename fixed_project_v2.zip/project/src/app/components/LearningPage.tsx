import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, Binary, Hash, Hexagon, Circle, Download, FileText, Search, Copy, Check, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Input } from "./ui/input";
import { ThemeToggle } from "./ThemeToggle";
import { useTheme } from "../contexts/ThemeContext";
import jsPDF from "jspdf";

export function LearningPage() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRow, setSelectedRow] = useState<number | null>(null);
  const [textToAscii, setTextToAscii] = useState("");
  const [asciiToText, setAsciiToText] = useState("");
  const [copiedValue, setCopiedValue] = useState("");
  const [error, setError] = useState("");

  // Generate complete ASCII table (0-127)
  const generateASCIITable = () => {
    const specialChars: {[key: number]: string} = {
      0: "NUL (Null)",
      1: "SOH (Start of Heading)",
      2: "STX (Start of Text)",
      3: "ETX (End of Text)",
      4: "EOT (End of Transmission)",
      5: "ENQ (Enquiry)",
      6: "ACK (Acknowledge)",
      7: "BEL (Bell)",
      8: "BS (Backspace)",
      9: "HT (Tab)",
      10: "LF (Line Feed)",
      11: "VT (Vertical Tab)",
      12: "FF (Form Feed)",
      13: "CR (Carriage Return)",
      14: "SO (Shift Out)",
      15: "SI (Shift In)",
      16: "DLE (Data Link Escape)",
      17: "DC1 (Device Control 1)",
      18: "DC2 (Device Control 2)",
      19: "DC3 (Device Control 3)",
      20: "DC4 (Device Control 4)",
      21: "NAK (Negative Acknowledge)",
      22: "SYN (Synchronous Idle)",
      23: "ETB (End of Trans. Block)",
      24: "CAN (Cancel)",
      25: "EM (End of Medium)",
      26: "SUB (Substitute)",
      27: "ESC (Escape)",
      28: "FS (File Separator)",
      29: "GS (Group Separator)",
      30: "RS (Record Separator)",
      31: "US (Unit Separator)",
      32: "Space",
      127: "DEL (Delete)"
    };

    const table = [];
    for (let i = 0; i <= 127; i++) {
      const binary = i.toString(2).padStart(8, '0');
      const hex = i.toString(16).toUpperCase().padStart(2, '0');
      const char = specialChars[i] || (i >= 33 && i <= 126 ? String.fromCharCode(i) : "�");

      table.push({
        decimal: i,
        binary,
        hex,
        character: char
      });
    }
    return table;
  };

  const asciiTable = generateASCIITable();

  // Filter table based on search
  const filteredTable = asciiTable.filter(row => {
    const search = searchTerm.toLowerCase();
    return (
      row.decimal.toString().includes(search) ||
      row.binary.includes(search) ||
      row.hex.toLowerCase().includes(search) ||
      row.character.toLowerCase().includes(search)
    );
  });

  // Pure conversion functions — no setState calls, safe to call during render
  const convertTextToAscii = (text: string) => {
    if (!text) return [];
    return text.split("").map(char => {
      const code = char.charCodeAt(0);
      return {
        char,
        decimal: code,
        binary: code.toString(2).padStart(8, '0'),
        hex: code.toString(16).toUpperCase().padStart(2, '0')
      };
    });
  };

  const convertAsciiToText = (input: string) => {
    if (!input.trim()) return "";
    const codes = input.trim().split(/\s+/);
    let result = "";
    for (const code of codes) {
      const num = parseInt(code, 10);
      if (isNaN(num)) return "";
      result += String.fromCharCode(num);
    }
    return result;
  };

  const textToAsciiResult = convertTextToAscii(textToAscii);
  const asciiToTextResult = convertAsciiToText(asciiToText);

  const handleCopy = (value: string, label: string) => {
    navigator.clipboard.writeText(value);
    setCopiedValue(label);
    setTimeout(() => setCopiedValue(""), 2000);
  };

  const exportTheory = () => {
    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const marginLeft = 20;
    let yPosition = 20;

    // Title
    pdf.setFontSize(18);
    pdf.setFont("helvetica", "bold");
    pdf.text("BINARYVERSE - LEARNING THEORY", marginLeft, yPosition);
    yPosition += 15;

    // Content (keeping the existing theory content)
    const theoryContent = `
BINARYVERSE CONVERTER - LEARNING THEORY
========================================

1. BINARY NUMBER SYSTEM (Base-2)
---------------------------------

What is Binary?
Binary uses only 2 digits: 0 and 1
It's how computers understand and process data!

Why Computers Use Binary:
• Electronic circuits have 2 states: ON (1) and OFF (0)
• Simple and reliable
• Easy for digital systems to process

How Binary Works (Positional Notation):
Each position represents a power of 2

Example: 1011₂
Position:  3  2  1  0
Digit:     1  0  1  1
Value:    2³ 2² 2¹ 2⁰
          8  4  2  1

Calculation: 1×8 + 0×4 + 1×2 + 1×1 = 8 + 0 + 2 + 1 = 11₁₀

Important Terms:
• Bit: Single binary digit (0 or 1)
• Byte: 8 bits (example: 11010101)
• Word: 16, 32, or 64 bits
• MSB: Most Significant Bit (leftmost)
• LSB: Least Significant Bit (rightmost)


2. DECIMAL NUMBER SYSTEM (Base-10)
-----------------------------------

What is Decimal?
Uses 10 digits: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9
This is what we use in daily life!

How Decimal Works:
Each position represents a power of 10

Example: 2547₁₀
Position: 3   2   1   0
Digit:    2   5   4   7
Value:   10³ 10² 10¹ 10⁰
        1000 100  10   1

Calculation: 2×1000 + 5×100 + 4×10 + 7×1 = 2000 + 500 + 40 + 7 = 2547


3. HEXADECIMAL NUMBER SYSTEM (Base-16)
---------------------------------------

What is Hexadecimal?
Uses 16 digits: 0-9 and A-F
A=10, B=11, C=12, D=13, E=14, F=15
Prefix: 0x (example: 0x2F)

Why Use Hexadecimal?
• Shorter way to write binary
• 1 hex digit = 4 binary bits
• Used in colors, memory addresses
• Easier to read than long binary numbers

Example: 2F₁₆ to Decimal
2 × 16¹ = 2 × 16 = 32
F × 16⁰ = 15 × 1 = 15
Answer: 32 + 15 = 47₁₀


4. OCTAL NUMBER SYSTEM (Base-8)
--------------------------------

What is Octal?
Uses 8 digits: 0, 1, 2, 3, 4, 5, 6, 7
Prefix: 0o (example: 0o17)

Where Is It Used?
• Unix/Linux file permissions (chmod 755)
• 1 octal digit = 3 binary bits
• Less common but still important

Example: 47₈ to Decimal
4 × 8¹ = 4 × 8 = 32
7 × 8⁰ = 7 × 1 = 7
Answer: 32 + 7 = 39₁₀


CONVERSION METHODS
==================

Binary → Decimal
----------------
Method: Multiply each bit by its position value (power of 2)

Example: 1101₂
1×2³ + 1×2² + 0×2¹ + 1×2⁰
= 8 + 4 + 0 + 1
= 13₁₀


Decimal → Binary
----------------
Method: Divide by 2 repeatedly, write remainders bottom to top

Example: 45₁₀
45 ÷ 2 = 22 remainder 1
22 ÷ 2 = 11 remainder 0
11 ÷ 2 = 5  remainder 1
5  ÷ 2 = 2  remainder 1
2  ÷ 2 = 1  remainder 0
1  ÷ 2 = 0  remainder 1

Read bottom to top: 101101₂


QUICK CONVERSION TABLE
======================
Decimal | Binary  | Octal | Hex
--------|---------|-------|----
0       | 0000    | 0     | 0
1       | 0001    | 1     | 1
2       | 0010    | 2     | 2
3       | 0011    | 3     | 3
4       | 0100    | 4     | 4
5       | 0101    | 5     | 5
6       | 0110    | 6     | 6
7       | 0111    | 7     | 7
8       | 1000    | 10    | 8
9       | 1001    | 11    | 9
10      | 1010    | 12    | A
11      | 1011    | 13    | B
12      | 1100    | 14    | C
13      | 1101    | 15    | D
14      | 1110    | 16    | E
15      | 1111    | 17    | F
16      | 10000   | 20    | 10


TIPS TO REMEMBER
================
• Binary: Groups of 4 = 1 Hex digit
• Binary: Groups of 3 = 1 Octal digit
• To convert between Hex and Octal: Use Binary as middle step
• Always write answers with subscript to show which system
• Practice makes perfect!

Generated by BinaryVerse Converter
    `;

    // Split content into lines and add to PDF
    pdf.setFontSize(10);
    pdf.setFont("courier", "normal");

    const lines = theoryContent.split('\n');
    const maxWidth = pageWidth - 40;

    for (let line of lines) {
      if (yPosition > 280) {
        pdf.addPage();
        yPosition = 20;
      }

      if (line.includes('===') || line.includes('---')) {
        pdf.setFont("courier", "bold");
      } else if (line.match(/^\d+\./)) {
        pdf.setFont("courier", "bold");
        pdf.setFontSize(12);
      } else {
        pdf.setFont("courier", "normal");
        pdf.setFontSize(10);
      }

      const splitLines = pdf.splitTextToSize(line || " ", maxWidth);
      for (let splitLine of splitLines) {
        pdf.text(splitLine, marginLeft, yPosition);
        yPosition += 6;
      }
    }

    // Footer
    const pageCount = pdf.internal.pages.length - 1;
    for (let i = 1; i <= pageCount; i++) {
      pdf.setPage(i);
      pdf.setFontSize(8);
      pdf.setFont("helvetica", "normal");
      pdf.text(`Page ${i} of ${pageCount}`, pageWidth / 2, 290, { align: "center" });
    }

    pdf.save("BinaryVerse_Learning_Theory.pdf");
  };

  return (
    <div className={`relative z-10 min-h-screen px-4 py-8 transition-colors duration-300 ${
      isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'
    }`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Link to="/">
            <Button variant="ghost" className={isDark ? "text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10" : "text-blue-600 hover:text-blue-700 hover:bg-blue-500/10"}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>

          <div className="flex gap-2">
            <Button
              onClick={exportTheory}
              className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white"
            >
              <Download className="w-4 h-4 mr-2" />
              Export Theory
            </Button>
            <ThemeToggle />
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
            Learning Center
          </h1>
          <p className="text-purple-200/70">Easy-to-understand number systems guide</p>
        </motion.div>

        <Tabs defaultValue="binary" className="space-y-6 w-full">
          <TabsList className="grid w-full grid-cols-3 md:grid-cols-5 bg-slate-800/50 border border-cyan-500/30">
            <TabsTrigger value="binary" className="data-[state=active]:bg-cyan-500/20 data-[state=active]:text-cyan-300">
              <Binary className="w-4 h-4 mr-2" />
              Binary
            </TabsTrigger>
            <TabsTrigger value="decimal" className="data-[state=active]:bg-green-500/20 data-[state=active]:text-green-300">
              <Hash className="w-4 h-4 mr-2" />
              Decimal
            </TabsTrigger>
            <TabsTrigger value="hexadecimal" className="data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300">
              <Hexagon className="w-4 h-4 mr-2" />
              Hex
            </TabsTrigger>
            <TabsTrigger value="octal" className="data-[state=active]:bg-yellow-500/20 data-[state=active]:text-yellow-300">
              <Circle className="w-4 h-4 mr-2" />
              Octal
            </TabsTrigger>
            <TabsTrigger value="ascii" className="data-[state=active]:bg-teal-500/20 data-[state=active]:text-teal-300">
              <FileText className="w-4 h-4 mr-2" />
              ASCII
            </TabsTrigger>
          </TabsList>

          {/* ASCII Table Tab */}
          <TabsContent value="ascii">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gradient-to-br from-teal-800/30 to-teal-900/30 backdrop-blur-xl border border-teal-500/30 rounded-2xl p-8"
            >
              <h2 className="text-3xl font-bold text-teal-300 mb-4">ASCII Table & Converter</h2>

              <div className="space-y-6">
                {/* Introduction */}
                <div className="bg-teal-500/10 border border-teal-500/30 rounded-lg p-4">
                  <h3 className="text-xl font-semibold text-teal-400 mb-2">📝 What is ASCII?</h3>
                  <p className="text-teal-200/80 leading-relaxed text-lg">
                    <span className="font-bold text-teal-300">ASCII</span> (American Standard Code for Information Interchange) assigns a unique number (0-127) to each character. Computers use these numbers to represent text!
                  </p>
                </div>

                {/* Search Box */}
                <div className="bg-slate-900/50 border border-teal-500/30 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <Search className="w-5 h-5 text-teal-400" />
                    <Input
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Search by character, decimal, binary, or hex..."
                      className="bg-slate-800/50 border-slate-600 text-white"
                    />
                  </div>
                </div>

                {/* ASCII Table */}
                <div className="bg-slate-900/50 border border-teal-500/30 rounded-lg p-4">
                  <h3 className="text-xl font-semibold text-teal-400 mb-4">📊 Complete ASCII Table (0-127)</h3>

                  <div className="max-h-96 overflow-y-auto">
                    <table className="w-full text-sm">
                      <thead className="sticky top-0 bg-slate-900 border-b-2 border-teal-500/30">
                        <tr>
                          <th className="text-left p-3 text-teal-400 font-semibold">Decimal</th>
                          <th className="text-left p-3 text-teal-400 font-semibold">Binary</th>
                          <th className="text-left p-3 text-teal-400 font-semibold">Hex</th>
                          <th className="text-left p-3 text-teal-400 font-semibold">Character</th>
                          <th className="text-right p-3 text-teal-400 font-semibold">Copy</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredTable.map((row) => (
                          <tr
                            key={row.decimal}
                            onClick={() => setSelectedRow(row.decimal)}
                            className={`border-b border-slate-800 hover:bg-teal-500/10 transition-colors cursor-pointer ${
                              selectedRow === row.decimal ? "bg-teal-500/20 border-teal-500/50" : ""
                            }`}
                          >
                            <td className="p-3 font-mono text-white">{row.decimal}</td>
                            <td className="p-3 font-mono text-cyan-400">{row.binary}</td>
                            <td className="p-3 font-mono text-purple-400">{row.hex}</td>
                            <td className="p-3 text-teal-300">{row.character}</td>
                            <td className="p-3 text-right">
                              <Button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleCopy(row.binary, `binary-${row.decimal}`);
                                }}
                                variant="ghost"
                                size="sm"
                                className="text-teal-400 hover:bg-teal-500/10"
                              >
                                {copiedValue === `binary-${row.decimal}` ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                              </Button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  {filteredTable.length === 0 && (
                    <p className="text-center text-slate-400 py-8">No results found for "{searchTerm}"</p>
                  )}

                  <p className="text-xs text-slate-500 mt-4 text-center">
                    Showing {filteredTable.length} of 128 characters
                  </p>
                </div>

                {/* Converters */}
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Text to ASCII */}
                  <div className="bg-slate-900/50 border border-cyan-500/30 rounded-lg p-6">
                    <h3 className="text-xl font-semibold text-cyan-400 mb-4">📝 Text → ASCII</h3>

                    <Input
                      value={textToAscii}
                      onChange={(e) => {
                        const val = e.target.value;
                        setTextToAscii(val);
                        const outOfRange = val.split("").find(c => c.charCodeAt(0) > 127);
                        if (outOfRange) {
                          setError(`Warning: "${outOfRange}" (code ${outOfRange.charCodeAt(0)}) is outside standard ASCII range (0-127)`);
                        } else {
                          setError("");
                        }
                      }}
                      placeholder="Enter text (e.g., Hi)"
                      className="bg-slate-800/50 border-slate-600 text-white mb-4"
                    />

                    {error && textToAscii && (
                      <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-3 mb-4 flex items-start gap-2">
                        <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-yellow-400">{error}</p>
                      </div>
                    )}

                    {textToAsciiResult.length > 0 && (
                      <div className="bg-slate-800/50 rounded-lg p-4 max-h-64 overflow-y-auto">
                        <div className="space-y-3">
                          {textToAsciiResult.map((item, index) => (
                            <div key={index} className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-2xl text-white">{item.char}</span>
                                <Button
                                  onClick={() => handleCopy(item.binary, `text-${index}`)}
                                  variant="ghost"
                                  size="sm"
                                  className="text-cyan-400 hover:bg-cyan-500/10"
                                >
                                  {copiedValue === `text-${index}` ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                                </Button>
                              </div>
                              <div className="space-y-1 text-sm">
                                <div><span className="text-slate-400">Decimal:</span> <span className="text-white font-mono">{item.decimal}</span></div>
                                <div><span className="text-slate-400">Binary:</span> <span className="text-cyan-400 font-mono">{item.binary}</span></div>
                                <div><span className="text-slate-400">Hex:</span> <span className="text-purple-400 font-mono">{item.hex}</span></div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* ASCII to Text */}
                  <div className="bg-slate-900/50 border border-purple-500/30 rounded-lg p-6">
                    <h3 className="text-xl font-semibold text-purple-400 mb-4">🔢 ASCII → Text</h3>

                    <Input
                      value={asciiToText}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAsciiToText(val);
                        if (val.trim()) {
                          const codes = val.trim().split(/\s+/);
                          const invalid = codes.find(c => isNaN(parseInt(c, 10)));
                          if (invalid) {
                            setError(`Invalid input: "${invalid}" is not a valid number`);
                          } else {
                            const outOfRange = codes.find(c => { const n = parseInt(c, 10); return n < 0 || n > 127; });
                            if (outOfRange) {
                              setError(`Warning: ${parseInt(outOfRange, 10)} is outside standard ASCII range (0-127)`);
                            } else {
                              setError("");
                            }
                          }
                        } else {
                          setError("");
                        }
                      }}
                      placeholder="Enter ASCII codes (e.g., 72 105)"
                      className="bg-slate-800/50 border-slate-600 text-white mb-4"
                    />

                    {error && asciiToText && (
                      <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-4 flex items-start gap-2">
                        <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-red-400">{error}</p>
                      </div>
                    )}

                    {asciiToTextResult && !error && (
                      <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-6">
                        <div className="text-sm text-slate-400 mb-2">Result:</div>
                        <div className="text-3xl text-white font-mono mb-4 break-all">{asciiToTextResult}</div>
                        <Button
                          onClick={() => handleCopy(asciiToTextResult, "ascii-result")}
                          variant="outline"
                          size="sm"
                          className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10 w-full"
                        >
                          {copiedValue === "ascii-result" ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                          Copy Result
                        </Button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Quick Examples */}
                <div className="bg-slate-900/50 border border-teal-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-teal-400 mb-4">⚡ Quick Examples</h3>

                  <div className="grid md:grid-cols-3 gap-4">
                    {[
                      { char: "A", dec: "65", bin: "01000001", hex: "41" },
                      { char: "a", dec: "97", bin: "01100001", hex: "61" },
                      { char: "0", dec: "48", bin: "00110000", hex: "30" },
                    ].map((example, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setSearchTerm(example.char);
                          setSelectedRow(parseInt(example.dec));
                        }}
                        className="bg-slate-800/50 border border-teal-500/30 rounded-lg p-4 hover:bg-teal-500/10 transition-colors text-left"
                      >
                        <div className="text-3xl text-white mb-3 text-center">{example.char}</div>
                        <div className="space-y-1 text-sm">
                          <div><span className="text-slate-400">Decimal:</span> <span className="text-white font-mono">{example.dec}</span></div>
                          <div><span className="text-slate-400">Binary:</span> <span className="text-cyan-400 font-mono">{example.bin}</span></div>
                          <div><span className="text-slate-400">Hex:</span> <span className="text-purple-400 font-mono">{example.hex}</span></div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Notes */}
                <div className="bg-gradient-to-r from-teal-500/10 to-cyan-500/10 border border-teal-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-teal-400 mb-4">💡 Important Notes</h3>
                  <div className="grid md:grid-cols-2 gap-4 text-teal-200/80">
                    <div>
                      <h4 className="font-semibold text-teal-300 mb-2">Character Ranges</h4>
                      <ul className="text-sm space-y-1 list-disc list-inside">
                        <li>0-31: Control characters (non-printable)</li>
                        <li>32: Space character</li>
                        <li>33-47: Symbols (!, ", #, $, etc.)</li>
                        <li>48-57: Digits (0-9)</li>
                        <li>65-90: Uppercase letters (A-Z)</li>
                        <li>97-122: Lowercase letters (a-z)</li>
                        <li>127: Delete (DEL)</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold text-teal-300 mb-2">Key Facts</h4>
                      <ul className="text-sm space-y-1 list-disc list-inside">
                        <li>ASCII uses 7 bits (0-127)</li>
                        <li>Extended ASCII uses 8 bits (128-255)</li>
                        <li>One character = 1 byte (8 bits)</li>
                        <li>Case difference: 'A'(65) vs 'a'(97) = 32</li>
                        <li>Standard ASCII is enough for English</li>
                        <li>Unicode (UTF-8) is used for all languages</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>

          {/* Binary Tab */}
          <TabsContent value="binary">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gradient-to-br from-cyan-800/30 to-cyan-900/30 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-8"
            >
              <h2 className="text-3xl font-bold text-cyan-300 mb-4">Binary Number System (Base-2)</h2>

              <div className="space-y-6">
                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-cyan-400 mb-3">What is Binary?</h3>
                  <p className="text-cyan-200/80 leading-relaxed text-lg mb-4">
                    Binary uses only <span className="font-bold text-cyan-300">2 digits: 0 and 1</span>
                  </p>
                  <p className="text-cyan-200/80 leading-relaxed text-lg">
                    It's how computers understand and process data!
                  </p>
                </div>

                <div className="bg-slate-900/50 border border-cyan-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-cyan-400 mb-4">Why Computers Use Binary:</h3>
                  <ul className="space-y-3 text-cyan-200/80 text-lg">
                    <li className="flex items-start gap-3">
                      <span className="text-cyan-400 font-bold">•</span>
                      <span>Electronic circuits have 2 states: <span className="font-mono bg-cyan-500/20 px-2 py-1 rounded">ON (1)</span> and <span className="font-mono bg-slate-700 px-2 py-1 rounded">OFF (0)</span></span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-cyan-400 font-bold">•</span>
                      <span>Simple and reliable</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-cyan-400 font-bold">•</span>
                      <span>Easy for digital systems to process</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-cyan-400 mb-4">How Binary Works (Positional Notation):</h3>
                  <p className="text-cyan-200/80 text-lg mb-4">Each position represents a power of 2</p>

                  <div className="bg-slate-900/70 rounded-lg p-6 font-mono">
                    <div className="text-center mb-4 text-cyan-300 text-lg">Example: 1011₂</div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-2">
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">3</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">2</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">1</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">0</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-2">
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-cyan-300 font-bold">1</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-cyan-300 font-bold">0</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-cyan-300 font-bold">1</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-cyan-300 font-bold">1</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-2">
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">2³</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">2²</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">2¹</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">2⁰</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-4">
                      <div>
                        <div className="text-2xl text-green-400 font-bold">8</div>
                      </div>
                      <div>
                        <div className="text-2xl text-green-400 font-bold">4</div>
                      </div>
                      <div>
                        <div className="text-2xl text-green-400 font-bold">2</div>
                      </div>
                      <div>
                        <div className="text-2xl text-green-400 font-bold">1</div>
                      </div>
                    </div>
                    <div className="text-center text-cyan-200 text-lg border-t border-cyan-500/30 pt-4">
                      Calculation: <span className="text-white">1×8 + 0×4 + 1×2 + 1×1 = 8 + 0 + 2 + 1 = </span><span className="text-green-400 font-bold text-xl">11₁₀</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-cyan-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-cyan-400 mb-4">Important Terms:</h3>
                  <div className="grid md:grid-cols-2 gap-4 text-cyan-200/80 text-lg">
                    <div className="bg-cyan-500/10 rounded-lg p-4">
                      <span className="font-bold text-cyan-300">Bit:</span> Single binary digit (0 or 1)
                    </div>
                    <div className="bg-cyan-500/10 rounded-lg p-4">
                      <span className="font-bold text-cyan-300">Byte:</span> 8 bits (example: 11010101)
                    </div>
                    <div className="bg-cyan-500/10 rounded-lg p-4">
                      <span className="font-bold text-cyan-300">Word:</span> 16, 32, or 64 bits
                    </div>
                    <div className="bg-cyan-500/10 rounded-lg p-4">
                      <span className="font-bold text-cyan-300">MSB:</span> Most Significant Bit (leftmost)
                    </div>
                    <div className="bg-cyan-500/10 rounded-lg p-4">
                      <span className="font-bold text-cyan-300">LSB:</span> Least Significant Bit (rightmost)
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-cyan-400 mb-4">Conversion Examples:</h3>

                  <div className="space-y-6">
                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <h4 className="text-lg font-semibold text-purple-400 mb-3">Binary → Decimal</h4>
                      <p className="text-slate-300 mb-4">Method: Multiply each bit by its position value (power of 2)</p>
                      <div className="font-mono bg-slate-800/50 rounded p-4">
                        <div className="text-cyan-300 mb-2">Example: 1101₂</div>
                        <div className="text-white space-y-1">
                          <div>1×2³ + 1×2² + 0×2¹ + 1×2⁰</div>
                          <div>= 8 + 4 + 0 + 1</div>
                          <div className="text-green-400 font-bold">= 13₁₀</div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <h4 className="text-lg font-semibold text-purple-400 mb-3">Decimal → Binary</h4>
                      <p className="text-slate-300 mb-4">Method: Divide by 2 repeatedly, write remainders bottom to top</p>
                      <div className="font-mono bg-slate-800/50 rounded p-4">
                        <div className="text-cyan-300 mb-2">Example: 45₁₀</div>
                        <div className="text-white space-y-1">
                          <div>45 ÷ 2 = 22 remainder <span className="text-green-400">1</span></div>
                          <div>22 ÷ 2 = 11 remainder <span className="text-green-400">0</span></div>
                          <div>11 ÷ 2 = 5  remainder <span className="text-green-400">1</span></div>
                          <div>5  ÷ 2 = 2  remainder <span className="text-green-400">1</span></div>
                          <div>2  ÷ 2 = 1  remainder <span className="text-green-400">0</span></div>
                          <div>1  ÷ 2 = 0  remainder <span className="text-green-400">1</span></div>
                          <div className="mt-3 text-green-400 font-bold">Read bottom to top: 101101₂</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>

          {/* Decimal Tab */}
          <TabsContent value="decimal">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gradient-to-br from-green-800/30 to-green-900/30 backdrop-blur-xl border border-green-500/30 rounded-2xl p-8"
            >
              <h2 className="text-3xl font-bold text-green-300 mb-4">Decimal Number System (Base-10)</h2>

              <div className="space-y-6">
                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-green-400 mb-3">What is Decimal?</h3>
                  <p className="text-green-200/80 leading-relaxed text-lg mb-4">
                    Uses <span className="font-bold text-green-300">10 digits: 0, 1, 2, 3, 4, 5, 6, 7, 8, 9</span>
                  </p>
                  <p className="text-green-200/80 leading-relaxed text-lg">
                    This is what we use in daily life!
                  </p>
                </div>

                <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-green-400 mb-4">How Decimal Works:</h3>
                  <p className="text-green-200/80 text-lg mb-4">Each position represents a power of 10</p>

                  <div className="bg-slate-900/70 rounded-lg p-6 font-mono">
                    <div className="text-center mb-4 text-green-300 text-lg">Example: 2547₁₀</div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-2">
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">3</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">2</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">1</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Position:</div>
                        <div className="text-xl text-white">0</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-2">
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-green-300 font-bold">2</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-green-300 font-bold">5</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-green-300 font-bold">4</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Digit:</div>
                        <div className="text-2xl text-green-300 font-bold">7</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-2">
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">10³</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">10²</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">10¹</div>
                      </div>
                      <div>
                        <div className="text-sm text-slate-400 mb-1">Value:</div>
                        <div className="text-lg text-purple-400">10⁰</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-4 gap-4 text-center mb-4">
                      <div>
                        <div className="text-2xl text-cyan-400 font-bold">1000</div>
                      </div>
                      <div>
                        <div className="text-2xl text-cyan-400 font-bold">100</div>
                      </div>
                      <div>
                        <div className="text-2xl text-cyan-400 font-bold">10</div>
                      </div>
                      <div>
                        <div className="text-2xl text-cyan-400 font-bold">1</div>
                      </div>
                    </div>
                    <div className="text-center text-green-200 text-lg border-t border-green-500/30 pt-4">
                      Calculation: <span className="text-white">2×1000 + 5×100 + 4×10 + 7×1 = 2000 + 500 + 40 + 7 = </span><span className="text-cyan-400 font-bold text-xl">2547</span>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-green-400 mb-4">Why We Use Decimal:</h3>
                  <ul className="space-y-3 text-green-200/80 text-lg">
                    <li className="flex items-start gap-3">
                      <span className="text-green-400 font-bold">•</span>
                      <span>Natural for humans (we have 10 fingers!)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-green-400 font-bold">•</span>
                      <span>Used in everyday counting and mathematics</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-green-400 font-bold">•</span>
                      <span>Standard system taught in schools worldwide</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-green-400 font-bold">•</span>
                      <span>Foundation for scientific notation</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-green-500/10 to-cyan-500/10 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-green-400 mb-4">Place Value Examples:</h3>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <div className="text-lg font-semibold text-purple-400 mb-3">Breaking Down Numbers</div>
                      <div className="font-mono bg-slate-800/50 rounded p-4 text-white space-y-2">
                        <div className="text-green-300 mb-3">Example: 3,456</div>
                        <div>3,000 = 3 × 1000 (Thousands)</div>
                        <div>400 = 4 × 100 (Hundreds)</div>
                        <div>50 = 5 × 10 (Tens)</div>
                        <div>6 = 6 × 1 (Ones)</div>
                        <div className="border-t border-green-500/30 pt-2 mt-2 text-cyan-400">Total: 3,456</div>
                      </div>
                    </div>

                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <div className="text-lg font-semibold text-purple-400 mb-3">Expanded Form</div>
                      <div className="font-mono bg-slate-800/50 rounded p-4 text-white space-y-2">
                        <div className="text-green-300 mb-3">Example: 7,890</div>
                        <div>= 7000 + 800 + 90 + 0</div>
                        <div>= (7 × 10³) + (8 × 10²)</div>
                        <div>+ (9 × 10¹) + (0 × 10⁰)</div>
                        <div className="border-t border-green-500/30 pt-2 mt-2 text-cyan-400">Simplified: 7,890</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-green-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-green-400 mb-4">Fun Facts:</h3>
                  <div className="grid md:grid-cols-2 gap-4 text-green-200/80 text-lg">
                    <div className="bg-green-500/10 rounded-lg p-4">
                      <span className="font-bold text-green-300">Ancient History:</span> Used by civilizations for thousands of years
                    </div>
                    <div className="bg-green-500/10 rounded-lg p-4">
                      <span className="font-bold text-green-300">Universal:</span> Understood in every country and culture
                    </div>
                    <div className="bg-green-500/10 rounded-lg p-4">
                      <span className="font-bold text-green-300">Base for others:</span> Understanding decimal helps learn other number systems
                    </div>
                    <div className="bg-green-500/10 rounded-lg p-4">
                      <span className="font-bold text-green-300">Metric system:</span> Uses powers of 10 for measurements
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>

          {/* Hexadecimal Tab */}
          <TabsContent value="hexadecimal">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gradient-to-br from-purple-800/30 to-purple-900/30 backdrop-blur-xl border border-purple-500/30 rounded-2xl p-8"
            >
              <h2 className="text-3xl font-bold text-purple-300 mb-4">Hexadecimal Number System (Base-16)</h2>

              <div className="space-y-6">
                <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-purple-400 mb-3">What is Hexadecimal?</h3>
                  <p className="text-purple-200/80 leading-relaxed text-lg mb-4">
                    Uses <span className="font-bold text-purple-300">16 digits: 0-9 and A-F</span>
                  </p>
                  <div className="bg-slate-900/50 rounded-lg p-4 font-mono text-lg">
                    <div className="grid grid-cols-6 gap-2 text-center">
                      <div className="text-white">A=10</div>
                      <div className="text-white">B=11</div>
                      <div className="text-white">C=12</div>
                      <div className="text-white">D=13</div>
                      <div className="text-white">E=14</div>
                      <div className="text-white">F=15</div>
                    </div>
                  </div>
                  <p className="text-purple-200/80 leading-relaxed text-lg mt-4">
                    Prefix: <span className="font-mono bg-purple-500/20 px-2 py-1 rounded">0x</span> (example: 0x2F)
                  </p>
                </div>

                <div className="bg-slate-900/50 border border-purple-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-purple-400 mb-4">Why Use Hexadecimal?</h3>
                  <ul className="space-y-3 text-purple-200/80 text-lg">
                    <li className="flex items-start gap-3">
                      <span className="text-purple-400 font-bold">•</span>
                      <span>Shorter way to write binary (1 hex digit = 4 binary bits)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-purple-400 font-bold">•</span>
                      <span>Used in colors (e.g., #FF5733 for orange)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-purple-400 font-bold">•</span>
                      <span>Memory addresses in programming</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-purple-400 font-bold">•</span>
                      <span>Easier to read than long binary numbers</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-purple-400 mb-4">Conversion Example:</h3>

                  <div className="bg-slate-900/70 rounded-lg p-6 font-mono">
                    <div className="text-center mb-4 text-purple-300 text-lg">Example: 2F₁₆ to Decimal</div>
                    <div className="space-y-3 text-white text-lg">
                      <div className="bg-slate-800/50 rounded p-4">
                        <div className="text-purple-300 mb-2">First digit (2):</div>
                        <div>2 × 16¹ = 2 × 16 = <span className="text-cyan-400 font-bold">32</span></div>
                      </div>
                      <div className="bg-slate-800/50 rounded p-4">
                        <div className="text-purple-300 mb-2">Second digit (F = 15):</div>
                        <div>F × 16⁰ = 15 × 1 = <span className="text-cyan-400 font-bold">15</span></div>
                      </div>
                      <div className="bg-gradient-to-r from-purple-500/20 to-cyan-500/20 rounded p-4 border border-purple-500/30">
                        <div className="text-center text-xl">
                          Answer: 32 + 15 = <span className="text-green-400 font-bold text-2xl">47₁₀</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-purple-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-purple-400 mb-4">Hex to Binary Conversion:</h3>
                  <p className="text-purple-200/80 text-lg mb-4">Each hex digit converts to exactly 4 binary bits</p>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div className="bg-slate-900/70 rounded-lg p-4">
                      <div className="font-mono space-y-2 text-white">
                        <div className="text-purple-300 mb-3">Hex Digits 0-7:</div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>0 = <span className="text-cyan-400">0000</span></div>
                          <div>1 = <span className="text-cyan-400">0001</span></div>
                          <div>2 = <span className="text-cyan-400">0010</span></div>
                          <div>3 = <span className="text-cyan-400">0011</span></div>
                          <div>4 = <span className="text-cyan-400">0100</span></div>
                          <div>5 = <span className="text-cyan-400">0101</span></div>
                          <div>6 = <span className="text-cyan-400">0110</span></div>
                          <div>7 = <span className="text-cyan-400">0111</span></div>
                        </div>
                      </div>
                    </div>
                    <div className="bg-slate-900/70 rounded-lg p-4">
                      <div className="font-mono space-y-2 text-white">
                        <div className="text-purple-300 mb-3">Hex Digits 8-F:</div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>8 = <span className="text-cyan-400">1000</span></div>
                          <div>9 = <span className="text-cyan-400">1001</span></div>
                          <div>A = <span className="text-cyan-400">1010</span></div>
                          <div>B = <span className="text-cyan-400">1011</span></div>
                          <div>C = <span className="text-cyan-400">1100</span></div>
                          <div>D = <span className="text-cyan-400">1101</span></div>
                          <div>E = <span className="text-cyan-400">1110</span></div>
                          <div>F = <span className="text-cyan-400">1111</span></div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-purple-400 mb-4">Practical Examples:</h3>

                  <div className="space-y-4">
                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <div className="text-lg font-semibold text-pink-400 mb-3">Color Codes in Web Design</div>
                      <div className="font-mono bg-slate-800/50 rounded p-4 space-y-2">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded" style={{backgroundColor: '#FF5733'}}></div>
                          <div className="text-white">#FF5733 = RGB(255, 87, 51) = Orange</div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded" style={{backgroundColor: '#00FF00'}}></div>
                          <div className="text-white">#00FF00 = RGB(0, 255, 0) = Green</div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 rounded" style={{backgroundColor: '#3498DB'}}></div>
                          <div className="text-white">#3498DB = RGB(52, 152, 219) = Blue</div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <div className="text-lg font-semibold text-pink-400 mb-3">Memory Addresses</div>
                      <div className="font-mono bg-slate-800/50 rounded p-4 text-white space-y-1">
                        <div>0x0000 - Start of memory</div>
                        <div>0x1A2B - Program location</div>
                        <div>0xFFFF - End of 16-bit address space</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>

          {/* Octal Tab */}
          <TabsContent value="octal">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-gradient-to-br from-yellow-800/30 to-yellow-900/30 backdrop-blur-xl border border-yellow-500/30 rounded-2xl p-8"
            >
              <h2 className="text-3xl font-bold text-yellow-300 mb-4">Octal Number System (Base-8)</h2>

              <div className="space-y-6">
                <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-3">What is Octal?</h3>
                  <p className="text-yellow-200/80 leading-relaxed text-lg mb-4">
                    Uses <span className="font-bold text-yellow-300">8 digits: 0, 1, 2, 3, 4, 5, 6, 7</span>
                  </p>
                  <p className="text-yellow-200/80 leading-relaxed text-lg">
                    Prefix: <span className="font-mono bg-yellow-500/20 px-2 py-1 rounded">0o</span> (example: 0o17)
                  </p>
                </div>

                <div className="bg-slate-900/50 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-4">Where Is It Used?</h3>
                  <ul className="space-y-3 text-yellow-200/80 text-lg">
                    <li className="flex items-start gap-3">
                      <span className="text-yellow-400 font-bold">•</span>
                      <span>Unix/Linux file permissions (chmod 755)</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-yellow-400 font-bold">•</span>
                      <span>1 octal digit = 3 binary bits</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-yellow-400 font-bold">•</span>
                      <span>Compact representation of binary</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="text-yellow-400 font-bold">•</span>
                      <span>Less common but still important in computing</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-4">Conversion Example:</h3>

                  <div className="bg-slate-900/70 rounded-lg p-6 font-mono">
                    <div className="text-center mb-4 text-yellow-300 text-lg">Example: 47₈ to Decimal</div>
                    <div className="space-y-3 text-white text-lg">
                      <div className="bg-slate-800/50 rounded p-4">
                        <div className="text-yellow-300 mb-2">First digit (4):</div>
                        <div>4 × 8¹ = 4 × 8 = <span className="text-cyan-400 font-bold">32</span></div>
                      </div>
                      <div className="bg-slate-800/50 rounded p-4">
                        <div className="text-yellow-300 mb-2">Second digit (7):</div>
                        <div>7 × 8⁰ = 7 × 1 = <span className="text-cyan-400 font-bold">7</span></div>
                      </div>
                      <div className="bg-gradient-to-r from-yellow-500/20 to-cyan-500/20 rounded p-4 border border-yellow-500/30">
                        <div className="text-center text-xl">
                          Answer: 32 + 7 = <span className="text-green-400 font-bold text-2xl">39₁₀</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-4">Octal to Binary Conversion:</h3>
                  <p className="text-yellow-200/80 text-lg mb-4">Each octal digit converts to exactly 3 binary bits</p>

                  <div className="bg-slate-900/70 rounded-lg p-4">
                    <div className="font-mono grid grid-cols-2 md:grid-cols-4 gap-3 text-white">
                      <div>0 = <span className="text-cyan-400">000</span></div>
                      <div>1 = <span className="text-cyan-400">001</span></div>
                      <div>2 = <span className="text-cyan-400">010</span></div>
                      <div>3 = <span className="text-cyan-400">011</span></div>
                      <div>4 = <span className="text-cyan-400">100</span></div>
                      <div>5 = <span className="text-cyan-400">101</span></div>
                      <div>6 = <span className="text-cyan-400">110</span></div>
                      <div>7 = <span className="text-cyan-400">111</span></div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-4">Unix File Permissions Example:</h3>

                  <div className="space-y-4">
                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <div className="text-lg font-semibold text-orange-400 mb-3">chmod 755</div>
                      <div className="font-mono bg-slate-800/50 rounded p-4 space-y-3 text-white">
                        <div className="grid grid-cols-3 gap-4 text-center mb-4">
                          <div className="bg-yellow-500/20 rounded p-3">
                            <div className="text-yellow-300 font-bold text-2xl">7</div>
                            <div className="text-sm text-slate-300 mt-2">Owner</div>
                          </div>
                          <div className="bg-yellow-500/20 rounded p-3">
                            <div className="text-yellow-300 font-bold text-2xl">5</div>
                            <div className="text-sm text-slate-300 mt-2">Group</div>
                          </div>
                          <div className="bg-yellow-500/20 rounded p-3">
                            <div className="text-yellow-300 font-bold text-2xl">5</div>
                            <div className="text-sm text-slate-300 mt-2">Others</div>
                          </div>
                        </div>
                        <div className="space-y-2 text-sm border-t border-yellow-500/30 pt-3">
                          <div>7 (111) = <span className="text-cyan-400">Read + Write + Execute</span></div>
                          <div>5 (101) = <span className="text-cyan-400">Read + Execute</span></div>
                          <div>4 (100) = <span className="text-cyan-400">Read only</span></div>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900/70 rounded-lg p-6">
                      <div className="text-lg font-semibold text-orange-400 mb-3">Common Permission Codes</div>
                      <div className="font-mono bg-slate-800/50 rounded p-4 space-y-2 text-white text-sm">
                        <div className="flex justify-between">
                          <span>777</span>
                          <span className="text-cyan-400">All permissions for everyone</span>
                        </div>
                        <div className="flex justify-between">
                          <span>755</span>
                          <span className="text-cyan-400">Owner: all, Others: read+execute</span>
                        </div>
                        <div className="flex justify-between">
                          <span>644</span>
                          <span className="text-cyan-400">Owner: read+write, Others: read</span>
                        </div>
                        <div className="flex justify-between">
                          <span>600</span>
                          <span className="text-cyan-400">Owner: read+write only</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-slate-900/50 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-4">Quick Conversion Example:</h3>

                  <div className="bg-slate-900/70 rounded-lg p-6">
                    <div className="font-mono bg-slate-800/50 rounded p-4">
                      <div className="text-yellow-300 mb-4 text-center text-lg">Convert: 145₈ to Binary</div>
                      <div className="space-y-3 text-white">
                        <div className="grid grid-cols-3 gap-4 text-center">
                          <div>
                            <div className="text-2xl text-yellow-300">1</div>
                            <div className="text-sm text-slate-400 my-2">→</div>
                            <div className="text-cyan-400">001</div>
                          </div>
                          <div>
                            <div className="text-2xl text-yellow-300">4</div>
                            <div className="text-sm text-slate-400 my-2">→</div>
                            <div className="text-cyan-400">100</div>
                          </div>
                          <div>
                            <div className="text-2xl text-yellow-300">5</div>
                            <div className="text-sm text-slate-400 my-2">→</div>
                            <div className="text-cyan-400">101</div>
                          </div>
                        </div>
                        <div className="text-center text-xl border-t border-yellow-500/30 pt-4 mt-4">
                          Result: <span className="text-green-400 font-bold">001 100 101₂</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-6">
                  <h3 className="text-xl font-semibold text-yellow-400 mb-4">Key Takeaways:</h3>
                  <div className="grid md:grid-cols-2 gap-4 text-yellow-200/80 text-lg">
                    <div className="bg-yellow-500/10 rounded-lg p-4">
                      <span className="font-bold text-yellow-300">Compact:</span> Shorter than binary, easier to read
                    </div>
                    <div className="bg-yellow-500/10 rounded-lg p-4">
                      <span className="font-bold text-yellow-300">Historical:</span> Used in early computer systems
                    </div>
                    <div className="bg-yellow-500/10 rounded-lg p-4">
                      <span className="font-bold text-yellow-300">Permissions:</span> Essential for Unix/Linux systems
                    </div>
                    <div className="bg-yellow-500/10 rounded-lg p-4">
                      <span className="font-bold text-yellow-300">3-bit groups:</span> Each digit = 3 binary bits
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

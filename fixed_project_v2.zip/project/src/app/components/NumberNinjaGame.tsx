import { useState, useEffect, useCallback } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Trophy, Zap, Heart, Clock, Star, Crown, Medal } from "lucide-react";
import { Button } from "./ui/button";
import confetti from "canvas-confetti";
import { useTheme } from "../contexts/ThemeContext";

interface Question {
  id: number;
  from: string;
  to: string;
  value: string;
  answer: string;
  options: string[];
}

interface LeaderboardEntry {
  rank: number;
  score: number;
  date: string;
  accuracy: number;
}

export function NumberNinjaGame() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [gameState, setGameState] = useState<"menu" | "playing" | "gameOver">("menu");
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(5);
  const [combo, setCombo] = useState(0);
  const [timeLeft, setTimeLeft] = useState(60);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [streak, setStreak] = useState(0);
  const [totalQuestions, setTotalQuestions] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  const conversions = [
    { from: "Binary", to: "Decimal", base: [2, 10] },
    { from: "Decimal", to: "Binary", base: [10, 2] },
    { from: "Decimal", to: "Hex", base: [10, 16] },
    { from: "Hex", to: "Decimal", base: [16, 10] },
    { from: "Binary", to: "Hex", base: [2, 16] },
    { from: "Hex", to: "Binary", base: [16, 2] },
    { from: "Decimal", to: "Octal", base: [10, 8] },
    { from: "Octal", to: "Decimal", base: [8, 10] },
  ];

  useEffect(() => {
    loadLeaderboard();
  }, []);

  const loadLeaderboard = () => {
    const saved = localStorage.getItem("numberNinjaLeaderboard");
    if (saved) {
      const entries: LeaderboardEntry[] = JSON.parse(saved);
      setLeaderboard(entries.sort((a, b) => b.score - a.score).slice(0, 10));
    }
  };

  const saveToLeaderboard = (finalScore: number, accuracy: number) => {
    const entry: LeaderboardEntry = {
      rank: 0,
      score: finalScore,
      date: new Date().toLocaleDateString(),
      accuracy: Math.round(accuracy),
    };

    const saved = localStorage.getItem("numberNinjaLeaderboard");
    let entries: LeaderboardEntry[] = saved ? JSON.parse(saved) : [];
    entries.push(entry);
    entries = entries.sort((a, b) => b.score - a.score).slice(0, 10);
    entries = entries.map((e, i) => ({ ...e, rank: i + 1 }));

    localStorage.setItem("numberNinjaLeaderboard", JSON.stringify(entries));
    setLeaderboard(entries);
  };

  const generateQuestion = useCallback(() => {
    const conversion = conversions[Math.floor(Math.random() * conversions.length)];
    const maxNum = 50 + (score / 50) * 50;
    const num = Math.floor(Math.random() * maxNum) + 1;

    let fromValue: string;
    if (conversion.base[0] === 2) fromValue = num.toString(2);
    else if (conversion.base[0] === 8) fromValue = num.toString(8);
    else if (conversion.base[0] === 10) fromValue = num.toString(10);
    else fromValue = num.toString(16).toUpperCase();

    let answer: string;
    if (conversion.base[1] === 2) answer = num.toString(2);
    else if (conversion.base[1] === 8) answer = num.toString(8);
    else if (conversion.base[1] === 10) answer = num.toString(10);
    else answer = num.toString(16).toUpperCase();

    const options = [answer];
    while (options.length < 4) {
      const wrongNum = Math.floor(Math.random() * maxNum) + 1;
      let wrongAnswer: string;
      if (conversion.base[1] === 2) wrongAnswer = wrongNum.toString(2);
      else if (conversion.base[1] === 8) wrongAnswer = wrongNum.toString(8);
      else if (conversion.base[1] === 10) wrongAnswer = wrongNum.toString(10);
      else wrongAnswer = wrongNum.toString(16).toUpperCase();

      if (!options.includes(wrongAnswer)) {
        options.push(wrongAnswer);
      }
    }

    return {
      id: Date.now(),
      from: conversion.from,
      to: conversion.to,
      value: fromValue,
      answer,
      options: options.sort(() => Math.random() - 0.5),
    };
  }, [score]);

  const startGame = () => {
    setGameState("playing");
    setScore(0);
    setLives(5);
    setCombo(0);
    setStreak(0);
    setTimeLeft(60);
    setTotalQuestions(0);
    setCorrectAnswers(0);
    setCurrentQuestion(generateQuestion());
  };

  const handleAnswer = (selectedAnswer: string) => {
    if (!currentQuestion) return;

    setTotalQuestions(prev => prev + 1);

    if (selectedAnswer === currentQuestion.answer) {
      const comboBonus = Math.floor(combo / 5) * 10;
      const streakBonus = Math.floor(streak / 3) * 5;
      const points = 10 + comboBonus + streakBonus;

      setScore(prev => prev + points);
      setCombo(prev => prev + 1);
      setStreak(prev => prev + 1);
      setCorrectAnswers(prev => prev + 1);

      if (combo > 0 && combo % 5 === 0) {
        confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
      }

      setTimeout(() => setCurrentQuestion(generateQuestion()), 300);
    } else {
      setLives(prev => prev - 1);
      setCombo(0);
      setStreak(0);

      if (lives - 1 <= 0) {
        endGame();
      } else {
        setTimeout(() => setCurrentQuestion(generateQuestion()), 500);
      }
    }
  };

  const endGame = () => {
    setGameState("gameOver");
    const accuracy = totalQuestions > 0 ? (correctAnswers / totalQuestions) * 100 : 0;
    saveToLeaderboard(score, accuracy);

    if (score > 0) {
      const gameCount = parseInt(localStorage.getItem("gamesPlayed") || "0");
      localStorage.setItem("gamesPlayed", (gameCount + 1).toString());

      // Update high score
      const currentHighScore = parseInt(localStorage.getItem("gameHighScore") || "0");
      if (score > currentHighScore) {
        localStorage.setItem("gameHighScore", score.toString());
      }
    }
  };

  useEffect(() => {
    if (gameState !== "playing") return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          endGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [gameState]);

  const getRankIcon = (rank: number) => {
    if (rank === 1) return <Crown className="w-5 h-5 text-yellow-400" />;
    if (rank === 2) return <Medal className="w-5 h-5 text-gray-400" />;
    if (rank === 3) return <Medal className="w-5 h-5 text-orange-600" />;
    return <Star className="w-4 h-4 text-slate-500" />;
  };

  return (
    <div className={`min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Link to="/">
            <Button variant="ghost" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>

          <Button
            onClick={() => setShowLeaderboard(!showLeaderboard)}
            variant="outline"
            className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/10"
          >
            <Trophy className="w-4 h-4 mr-2" />
            Top 10
          </Button>
        </div>

        {/* Leaderboard Modal */}
        <AnimatePresence>
          {showLeaderboard && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setShowLeaderboard(false)}
            >
              <motion.div
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.9, opacity: 0 }}
                onClick={(e) => e.stopPropagation()}
                className="bg-gradient-to-br from-slate-800 to-slate-900 border-2 border-yellow-500/30 rounded-2xl p-8 max-w-2xl w-full max-h-[80vh] overflow-y-auto"
              >
                <div className="flex items-center justify-center gap-3 mb-6">
                  <Trophy className="w-8 h-8 text-yellow-400" />
                  <h2 className="text-4xl font-black text-white">Top 10 Scores</h2>
                </div>

                {leaderboard.length === 0 ? (
                  <p className="text-slate-400 text-center py-12">No scores yet. Be the first!</p>
                ) : (
                  <div className="space-y-3">
                    {leaderboard.map((entry, index) => (
                      <motion.div
                        key={index}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className={`flex items-center justify-between p-4 rounded-xl border-2 ${
                          index === 0
                            ? "bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/50"
                            : index === 1
                            ? "bg-gradient-to-r from-gray-400/20 to-gray-500/20 border-gray-400/50"
                            : index === 2
                            ? "bg-gradient-to-r from-orange-600/20 to-red-600/20 border-orange-500/50"
                            : "bg-slate-800/50 border-slate-700"
                        }`}
                      >
                        <div className="flex items-center gap-4">
                          <div className="flex items-center justify-center w-10">
                            {getRankIcon(entry.rank)}
                          </div>
                          <div>
                            <div className="text-2xl font-bold text-white">{entry.score}</div>
                            <div className="text-xs text-slate-400">{entry.date}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm text-slate-300">{entry.accuracy}% accuracy</div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                )}

                <Button
                  onClick={() => setShowLeaderboard(false)}
                  className="w-full mt-6 bg-slate-700 hover:bg-slate-600"
                >
                  Close
                </Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Menu */}
        {gameState === "menu" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Zap className="w-24 h-24 text-cyan-400 mx-auto mb-6" />
            </motion.div>

            <h1 className="text-6xl md:text-8xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
              Number Ninja
            </h1>
            <p className="text-xl text-slate-300 mb-8">Convert at lightning speed!</p>

            <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-2 border-cyan-500/30 rounded-2xl p-8 mb-8 max-w-2xl mx-auto">
              <h2 className="text-2xl font-bold text-white mb-4">How to Play:</h2>
              <div className="space-y-3 text-left text-slate-300">
                <p>⚡ Convert numbers between ALL bases (Binary, Decimal, Hex, Octal)</p>
                <p>💗 You have 5 lives - don't make mistakes!</p>
                <p>⏱️ 60 seconds to get the highest score</p>
                <p>🔥 Build combos for bonus points</p>
                <p>🏆 Make it to the Top 10 leaderboard!</p>
              </div>
            </div>

            <Button
              onClick={startGame}
              className="px-12 py-6 text-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 shadow-lg shadow-cyan-500/50"
            >
              Start Game
            </Button>
          </motion.div>
        )}

        {/* Playing */}
        {gameState === "playing" && (
          <div className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              <div className="bg-gradient-to-br from-red-500/10 to-pink-600/10 border-2 border-red-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-5 h-5 text-red-400" />
                  <span className="text-sm text-slate-300">Lives</span>
                </div>
                <div className="text-3xl font-bold text-white">{lives}</div>
              </div>

              <div className="bg-gradient-to-br from-cyan-500/10 to-blue-600/10 border-2 border-cyan-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-5 h-5 text-cyan-400" />
                  <span className="text-sm text-slate-300">Score</span>
                </div>
                <div className="text-3xl font-bold text-cyan-400">{score}</div>
              </div>

              <div className="bg-gradient-to-br from-yellow-500/10 to-orange-600/10 border-2 border-yellow-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm text-slate-300">Combo</span>
                </div>
                <div className="text-3xl font-bold text-yellow-400">x{combo}</div>
              </div>

              <div className="bg-gradient-to-br from-purple-500/10 to-pink-600/10 border-2 border-purple-500/30 rounded-xl p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-5 h-5 text-purple-400" />
                  <span className="text-sm text-slate-300">Streak</span>
                </div>
                <div className="text-3xl font-bold text-purple-400">{streak}</div>
              </div>

              <div className={`bg-gradient-to-br ${timeLeft < 10 ? 'from-red-500/10 to-pink-600/10 border-red-500/30' : 'from-green-500/10 to-emerald-600/10 border-green-500/30'} border-2 rounded-xl p-4`}>
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-5 h-5 text-green-400" />
                  <span className="text-sm text-slate-300">Time</span>
                </div>
                <div className={`text-3xl font-bold ${timeLeft < 10 ? 'text-red-400' : 'text-green-400'}`}>{timeLeft}s</div>
              </div>
            </div>

            {/* Question */}
            {currentQuestion && (
              <motion.div
                key={currentQuestion.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-2 border-cyan-500/30 rounded-2xl p-8"
              >
                <div className="text-center mb-8">
                  <div className="inline-block bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/50 rounded-lg px-4 py-2 mb-4">
                    <span className="text-cyan-400 font-semibold">{currentQuestion.from}</span>
                    <span className="text-slate-400 mx-2">→</span>
                    <span className="text-purple-400 font-semibold">{currentQuestion.to}</span>
                  </div>

                  <div className="text-6xl md:text-8xl font-bold font-mono text-white mb-2">
                    {currentQuestion.value}
                  </div>
                  <p className="text-slate-400">Convert to {currentQuestion.to}</p>
                </div>

                <div className="grid grid-cols-2 gap-4 max-w-3xl mx-auto">
                  {currentQuestion.options.map((option, index) => (
                    <motion.button
                      key={index}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleAnswer(option)}
                      className="bg-gradient-to-br from-slate-700 to-slate-800 hover:from-cyan-500/20 hover:to-blue-500/20 border-2 border-slate-600 hover:border-cyan-500 rounded-xl p-6 text-3xl font-bold font-mono text-white transition-all"
                    >
                      {option}
                    </motion.button>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        )}

        {/* Game Over */}
        {gameState === "gameOver" && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center"
          >
            <h1 className="text-5xl md:text-7xl font-black mb-4 text-cyan-400">Game Over!</h1>

            <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-2 border-cyan-500/30 rounded-2xl p-8 mb-8 max-w-2xl mx-auto">
              <div className="text-7xl font-bold text-white mb-4">{score}</div>
              <div className="text-xl text-slate-300 mb-6">Final Score</div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-slate-400">Accuracy</div>
                  <div className="text-2xl font-bold text-green-400">
                    {totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0}%
                  </div>
                </div>
                <div>
                  <div className="text-sm text-slate-400">Questions</div>
                  <div className="text-2xl font-bold text-blue-400">{totalQuestions}</div>
                </div>
              </div>
            </div>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={startGame}
                className="px-8 py-6 text-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
              >
                Play Again
              </Button>
              <Button
                onClick={() => setShowLeaderboard(true)}
                variant="outline"
                className="px-8 py-6 text-xl border-2 border-yellow-500/50 text-yellow-400"
              >
                <Trophy className="w-5 h-5 mr-2" />
                View Top 10
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, CheckCircle2, XCircle, RotateCcw, Lightbulb, Target } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface PracticeQuestion {
  input: string;
  correctAnswer: string;
  type: string;
  explanation: string;
}

export function PracticePage() {
  const [selectedType, setSelectedType] = useState<string>("");
  const [currentQuestion, setCurrentQuestion] = useState<PracticeQuestion | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });

  const conversionTypes = [
    { id: "binary-decimal", label: "Binary ↔ Decimal", color: "cyan" },
    { id: "binary-hex", label: "Binary ↔ Hexadecimal", color: "purple" },
    { id: "binary-octal", label: "Binary ↔ Octal", color: "yellow" },
    { id: "decimal-hex", label: "Decimal ↔ Hexadecimal", color: "green" },
    { id: "decimal-octal", label: "Decimal ↔ Octal", color: "pink" },
    { id: "hex-octal", label: "Hex ↔ Octal", color: "orange" },
  ];

  const generateQuestion = (type: string): PracticeQuestion => {
    const randomNum = Math.floor(Math.random() * 150) + 10;

    switch (type) {
      case "binary-decimal": {
        const isBinToDec = Math.random() > 0.5;
        if (isBinToDec) {
          const binary = randomNum.toString(2);
          return {
            input: binary,
            correctAnswer: randomNum.toString(),
            type: "Binary → Decimal",
            explanation: `Binary ${binary} converts to decimal by: ${binary.split('').map((bit, i) => `${bit}×2^${binary.length - 1 - i}`).join(' + ')} = ${randomNum}`
          };
        } else {
          const binary = randomNum.toString(2);
          return {
            input: randomNum.toString(),
            correctAnswer: binary,
            type: "Decimal → Binary",
            explanation: `Decimal ${randomNum} converts to binary by repeatedly dividing by 2 and reading remainders from bottom to top = ${binary}`
          };
        }
      }
      case "binary-hex": {
        const isBinToHex = Math.random() > 0.5;
        const hex = randomNum.toString(16).toUpperCase();
        const binary = randomNum.toString(2);
        if (isBinToHex) {
          return {
            input: binary,
            correctAnswer: hex,
            type: "Binary → Hexadecimal",
            explanation: `Group binary ${binary} into sets of 4 bits (from right), convert each group to hex digit = ${hex}`
          };
        } else {
          return {
            input: hex,
            correctAnswer: binary,
            type: "Hexadecimal → Binary",
            explanation: `Convert each hex digit ${hex} to 4 binary bits = ${binary}`
          };
        }
      }
      case "binary-octal": {
        const isBinToOct = Math.random() > 0.5;
        const octal = randomNum.toString(8);
        const binary = randomNum.toString(2);
        if (isBinToOct) {
          return {
            input: binary,
            correctAnswer: octal,
            type: "Binary → Octal",
            explanation: `Group binary ${binary} into sets of 3 bits (from right), convert each group to octal digit = ${octal}`
          };
        } else {
          return {
            input: octal,
            correctAnswer: binary,
            type: "Octal → Binary",
            explanation: `Convert each octal digit ${octal} to 3 binary bits = ${binary}`
          };
        }
      }
      case "decimal-hex": {
        const isDecToHex = Math.random() > 0.5;
        const hex = randomNum.toString(16).toUpperCase();
        if (isDecToHex) {
          return {
            input: randomNum.toString(),
            correctAnswer: hex,
            type: "Decimal → Hexadecimal",
            explanation: `Decimal ${randomNum} converts to hex by repeatedly dividing by 16, reading remainders bottom to top = ${hex}`
          };
        } else {
          return {
            input: hex,
            correctAnswer: randomNum.toString(),
            type: "Hexadecimal → Decimal",
            explanation: `Hex ${hex} = ${hex.split('').map((digit, i) => {
              const val = parseInt(digit, 16);
              const power = hex.length - 1 - i;
              return `${val}×16^${power}`;
            }).join(' + ')} = ${randomNum}`
          };
        }
      }
      case "decimal-octal": {
        const isDecToOct = Math.random() > 0.5;
        const octal = randomNum.toString(8);
        if (isDecToOct) {
          return {
            input: randomNum.toString(),
            correctAnswer: octal,
            type: "Decimal → Octal",
            explanation: `Decimal ${randomNum} converts to octal by repeatedly dividing by 8, reading remainders bottom to top = ${octal}`
          };
        } else {
          return {
            input: octal,
            correctAnswer: randomNum.toString(),
            type: "Octal → Decimal",
            explanation: `Octal ${octal} = ${octal.split('').map((digit, i) => `${digit}×8^${octal.length - 1 - i}`).join(' + ')} = ${randomNum}`
          };
        }
      }
      case "hex-octal": {
        const isHexToOct = Math.random() > 0.5;
        const hex = randomNum.toString(16).toUpperCase();
        const octal = randomNum.toString(8);
        if (isHexToOct) {
          return {
            input: hex,
            correctAnswer: octal,
            type: "Hexadecimal → Octal",
            explanation: `Convert ${hex} to binary first, then group into 3-bit sets for octal = ${octal}`
          };
        } else {
          return {
            input: octal,
            correctAnswer: hex,
            type: "Octal → Hexadecimal",
            explanation: `Convert ${octal} to binary first, then group into 4-bit sets for hex = ${hex}`
          };
        }
      }
      default:
        return generateQuestion("binary-decimal");
    }
  };

  const startPractice = (type: string) => {
    setSelectedType(type);
    setCurrentQuestion(generateQuestion(type));
    setUserAnswer("");
    setFeedback(null);
    setShowExplanation(false);
  };

  const checkAnswer = () => {
    if (!currentQuestion) return;

    const isCorrect = userAnswer.trim().toUpperCase() === currentQuestion.correctAnswer.toUpperCase();
    setFeedback(isCorrect ? "correct" : "incorrect");
    setShowExplanation(true);
    setScore(prev => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1
    }));
  };

  const nextQuestion = () => {
    setCurrentQuestion(generateQuestion(selectedType));
    setUserAnswer("");
    setFeedback(null);
    setShowExplanation(false);
  };

  const resetPractice = () => {
    setSelectedType("");
    setCurrentQuestion(null);
    setUserAnswer("");
    setFeedback(null);
    setShowExplanation(false);
    setScore({ correct: 0, total: 0 });
  };

  return (
    <div className="relative z-10 min-h-screen px-4 py-8">
      <div className="max-w-5xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-2">
            Practice Mode
          </h1>
          <p className="text-blue-200/70">Master conversions with unlimited practice problems</p>
        </motion.div>

        {!selectedType && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="text-center mb-8">
              <Target className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Choose a Conversion Type</h2>
              <p className="text-blue-200/70">Select what you want to practice</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {conversionTypes.map((type) => (
                <motion.button
                  key={type.id}
                  onClick={() => startPractice(type.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-cyan-500/30 rounded-xl p-6 text-left hover:border-cyan-500/60 transition-all"
                >
                  <div className="text-lg font-bold text-white mb-2">{type.label}</div>
                  <div className="text-sm text-blue-200/60">Practice both directions</div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {currentQuestion && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <Button
                onClick={resetPractice}
                variant="outline"
                className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
              >
                <RotateCcw className="w-4 h-4 mr-2" />
                Change Type
              </Button>

              <div className="bg-slate-800/50 backdrop-blur-xl border border-purple-500/30 rounded-xl px-6 py-3">
                <div className="text-purple-300 text-sm">Score</div>
                <div className="text-white text-xl font-bold">
                  {score.correct} / {score.total}
                  {score.total > 0 && (
                    <span className="text-sm text-purple-300 ml-2">
                      ({Math.round((score.correct / score.total) * 100)}%)
                    </span>
                  )}
                </div>
              </div>
            </div>

            <motion.div
              key={currentQuestion.input}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-8"
            >
              <div className="text-center mb-8">
                <div className="inline-block bg-cyan-500/20 border border-cyan-500/40 rounded-lg px-4 py-2 mb-4">
                  <div className="text-cyan-300 text-sm font-semibold">{currentQuestion.type}</div>
                </div>
                <div className="text-5xl font-bold text-white font-mono mb-2">
                  {currentQuestion.input}
                </div>
                <p className="text-blue-200/60">Convert this number</p>
              </div>

              <div className="max-w-md mx-auto space-y-4">
                <div>
                  <Label htmlFor="answer" className="text-cyan-300 mb-2 block">
                    Your Answer
                  </Label>
                  <Input
                    id="answer"
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && !feedback && checkAnswer()}
                    placeholder="Type your answer..."
                    disabled={!!feedback}
                    className="bg-slate-950/50 border-cyan-500/30 text-white text-2xl h-16 font-mono text-center focus:border-cyan-400 focus:ring-cyan-400/50"
                  />
                </div>

                {!feedback && (
                  <Button
                    onClick={checkAnswer}
                    disabled={!userAnswer.trim()}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-6 text-lg rounded-xl"
                  >
                    Check Answer
                  </Button>
                )}

                {feedback && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="space-y-4"
                  >
                    <div
                      className={`${
                        feedback === "correct"
                          ? "bg-green-500/20 border-green-500/40 text-green-300"
                          : "bg-red-500/20 border-red-500/40 text-red-300"
                      } border rounded-xl p-6 flex items-start gap-3`}
                    >
                      {feedback === "correct" ? (
                        <CheckCircle2 className="w-6 h-6 flex-shrink-0 mt-1" />
                      ) : (
                        <XCircle className="w-6 h-6 flex-shrink-0 mt-1" />
                      )}
                      <div>
                        <div className="font-semibold text-lg mb-1">
                          {feedback === "correct" ? "Correct!" : "Incorrect"}
                        </div>
                        {feedback === "incorrect" && (
                          <div className="text-sm">
                            The correct answer is: <span className="font-bold font-mono text-lg">{currentQuestion.correctAnswer}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {showExplanation && (
                      <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-6">
                        <div className="flex items-start gap-3 mb-3">
                          <Lightbulb className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-1" />
                          <h3 className="text-lg font-semibold text-blue-300">Explanation</h3>
                        </div>
                        <p className="text-blue-200/80 leading-relaxed">{currentQuestion.explanation}</p>
                      </div>
                    )}

                    <Button
                      onClick={nextQuestion}
                      className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white py-6 text-lg rounded-xl"
                    >
                      Next Question
                    </Button>
                  </motion.div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}

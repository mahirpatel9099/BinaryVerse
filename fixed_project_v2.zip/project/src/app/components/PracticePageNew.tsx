import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { ArrowLeft, CheckCircle2, XCircle, RotateCcw, Lightbulb, Target, History, Trash2 } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useTheme } from "../contexts/ThemeContext";

interface PracticeQuestion {
  input: string;
  correctAnswer: string;
  type: string;
  detailedExplanation: {
    steps: string[];
    finalAnswer: string;
  };
}

interface PracticeHistory {
  question: string;
  userAnswer: string;
  correctAnswer: string;
  isCorrect: boolean;
  type: string;
}

export function PracticePageNew() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [selectedType, setSelectedType] = useState<string>("");
  const [currentQuestion, setCurrentQuestion] = useState<PracticeQuestion | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [history, setHistory] = useState<PracticeHistory[]>([]);

  const conversionTypes = [
    { id: "binary-decimal", label: "Binary ↔ Decimal", color: "blue" },
    { id: "binary-hex", label: "Binary ↔ Hexadecimal", color: "purple" },
    { id: "binary-octal", label: "Binary ↔ Octal", color: "yellow" },
    { id: "decimal-hex", label: "Decimal ↔ Hexadecimal", color: "green" },
    { id: "decimal-octal", label: "Decimal ↔ Octal", color: "pink" },
    { id: "hex-octal", label: "Hex ↔ Octal", color: "orange" },
  ];

  const generateDetailedExplanation = (type: string, input: string, answer: string, inputNum: number) => {
    const steps: string[] = [];
    let finalAnswer = "";

    switch (type) {
      case "Binary → Decimal": {
        const binary = input;
        steps.push(`Step 1: Write down the binary number: ${binary}`);
        steps.push(`Step 2: Assign position values from right to left (powers of 2):`);

        const calculations: string[] = [];
        let sum = 0;
        for (let i = 0; i < binary.length; i++) {
          const position = binary.length - 1 - i;
          const bit = binary[i];
          const value = parseInt(bit) * Math.pow(2, position);
          sum += value;
          calculations.push(`   Position ${position}: ${bit} × 2^${position} = ${bit} × ${Math.pow(2, position)} = ${value}`);
        }
        steps.push(...calculations);
        steps.push(`Step 3: Add all values together:`);
        steps.push(`   ${calculations.map(c => c.split('= ')[2]).join(' + ')} = ${sum}`);
        finalAnswer = `${binary}₂ = ${sum}₁₀`;
        break;
      }

      case "Decimal → Binary": {
        steps.push(`Step 1: Take the decimal number: ${input}`);
        steps.push(`Step 2: Divide by 2 repeatedly and note remainders:`);

        let num = inputNum;
        const divisions: string[] = [];
        const remainders: string[] = [];

        while (num > 0) {
          const quotient = Math.floor(num / 2);
          const remainder = num % 2;
          divisions.push(`   ${num} ÷ 2 = ${quotient} remainder ${remainder}`);
          remainders.unshift(remainder.toString());
          num = quotient;
        }

        steps.push(...divisions);
        steps.push(`Step 3: Read remainders from BOTTOM to TOP:`);
        steps.push(`   ${remainders.join('')}`);
        finalAnswer = `${input}₁₀ = ${remainders.join('')}₂`;
        break;
      }

      case "Binary → Hexadecimal": {
        const binary = input;
        steps.push(`Step 1: Start with binary: ${binary}`);
        steps.push(`Step 2: Group into sets of 4 bits from RIGHT to LEFT:`);

        const paddedBinary = binary.padStart(Math.ceil(binary.length / 4) * 4, '0');
        const groups = paddedBinary.match(/.{1,4}/g) || [];

        steps.push(`   Padded: ${paddedBinary}`);
        steps.push(`   Groups: ${groups.join(' | ')}`);
        steps.push(`Step 3: Convert each 4-bit group to hexadecimal:`);

        const hexDigits = groups.map((group, i) => {
          const decimal = parseInt(group, 2);
          const hex = decimal.toString(16).toUpperCase();
          steps.push(`   ${group}₂ = ${decimal}₁₀ = ${hex}₁₆`);
          return hex;
        });

        finalAnswer = `${binary}₂ = ${hexDigits.join('')}₁₆`;
        break;
      }

      case "Hexadecimal → Binary": {
        steps.push(`Step 1: Take hexadecimal: ${input}`);
        steps.push(`Step 2: Convert each hex digit to 4-bit binary:`);
        steps.push(`   Remember: 0-9 stay same, A=10, B=11, C=12, D=13, E=14, F=15`);

        const binaryGroups: string[] = [];
        for (const hexDigit of input) {
          const decimal = parseInt(hexDigit, 16);
          const binary = decimal.toString(2).padStart(4, '0');
          binaryGroups.push(binary);
          steps.push(`   ${hexDigit}₁₆ = ${decimal}₁₀ = ${binary}₂`);
        }

        steps.push(`Step 3: Combine all 4-bit groups:`);
        steps.push(`   ${binaryGroups.join(' ')}`);
        finalAnswer = `${input}₁₆ = ${binaryGroups.join('')}₂`;
        break;
      }

      case "Binary → Octal": {
        const binary = input;
        steps.push(`Step 1: Start with binary: ${binary}`);
        steps.push(`Step 2: Group into sets of 3 bits from RIGHT to LEFT:`);

        const paddedBinary = binary.padStart(Math.ceil(binary.length / 3) * 3, '0');
        const groups = paddedBinary.match(/.{1,3}/g) || [];

        steps.push(`   Padded: ${paddedBinary}`);
        steps.push(`   Groups: ${groups.join(' | ')}`);
        steps.push(`Step 3: Convert each 3-bit group to octal (0-7):`);

        const octalDigits = groups.map((group) => {
          const decimal = parseInt(group, 2);
          steps.push(`   ${group}₂ = ${decimal}₈`);
          return decimal.toString();
        });

        finalAnswer = `${binary}₂ = ${octalDigits.join('')}₈`;
        break;
      }

      case "Octal → Binary": {
        steps.push(`Step 1: Take octal: ${input}`);
        steps.push(`Step 2: Convert each octal digit to 3-bit binary:`);
        steps.push(`   Octal digits range from 0-7`);

        const binaryGroups: string[] = [];
        for (const octalDigit of input) {
          const decimal = parseInt(octalDigit, 8);
          const binary = decimal.toString(2).padStart(3, '0');
          binaryGroups.push(binary);
          steps.push(`   ${octalDigit}₈ = ${decimal}₁₀ = ${binary}₂`);
        }

        steps.push(`Step 3: Combine all 3-bit groups:`);
        steps.push(`   ${binaryGroups.join(' ')}`);
        finalAnswer = `${input}₈ = ${binaryGroups.join('')}₂`;
        break;
      }

      case "Decimal → Hexadecimal": {
        steps.push(`Step 1: Take decimal: ${input}`);
        steps.push(`Step 2: Divide by 16 repeatedly, note remainders:`);
        steps.push(`   Remember: 10=A, 11=B, 12=C, 13=D, 14=E, 15=F`);

        let num = inputNum;
        const divisions: string[] = [];
        const remainders: string[] = [];

        while (num > 0) {
          const quotient = Math.floor(num / 16);
          const remainder = num % 16;
          const hexRemainder = remainder.toString(16).toUpperCase();
          divisions.push(`   ${num} ÷ 16 = ${quotient} remainder ${remainder} (${hexRemainder}₁₆)`);
          remainders.unshift(hexRemainder);
          num = quotient;
        }

        steps.push(...divisions);
        steps.push(`Step 3: Read remainders from BOTTOM to TOP:`);
        steps.push(`   ${remainders.join('')}`);
        finalAnswer = `${input}₁₀ = ${remainders.join('')}₁₆`;
        break;
      }

      case "Hexadecimal → Decimal": {
        steps.push(`Step 1: Take hexadecimal: ${input}`);
        steps.push(`Step 2: Convert hex digits to decimal first:`);
        steps.push(`   A=10, B=11, C=12, D=13, E=14, F=15`);

        const calculations: string[] = [];
        let sum = 0;
        for (let i = 0; i < input.length; i++) {
          const position = input.length - 1 - i;
          const digit = input[i];
          const digitValue = parseInt(digit, 16);
          const positionValue = Math.pow(16, position);
          const value = digitValue * positionValue;
          sum += value;
          calculations.push(`   ${digit}₁₆ (=${digitValue}) × 16^${position} = ${digitValue} × ${positionValue} = ${value}`);
        }

        steps.push(...calculations);
        steps.push(`Step 3: Add all values:`);
        steps.push(`   ${calculations.map(c => c.split('= ')[2]).join(' + ')} = ${sum}`);
        finalAnswer = `${input}₁₆ = ${sum}₁₀`;
        break;
      }

      case "Decimal → Octal": {
        steps.push(`Step 1: Take decimal: ${input}`);
        steps.push(`Step 2: Divide by 8 repeatedly, note remainders:`);

        let num = inputNum;
        const divisions: string[] = [];
        const remainders: string[] = [];

        while (num > 0) {
          const quotient = Math.floor(num / 8);
          const remainder = num % 8;
          divisions.push(`   ${num} ÷ 8 = ${quotient} remainder ${remainder}`);
          remainders.unshift(remainder.toString());
          num = quotient;
        }

        steps.push(...divisions);
        steps.push(`Step 3: Read remainders from BOTTOM to TOP:`);
        steps.push(`   ${remainders.join('')}`);
        finalAnswer = `${input}₁₀ = ${remainders.join('')}₈`;
        break;
      }

      case "Octal → Decimal": {
        steps.push(`Step 1: Take octal: ${input}`);
        steps.push(`Step 2: Multiply each digit by powers of 8:`);

        const calculations: string[] = [];
        let sum = 0;
        for (let i = 0; i < input.length; i++) {
          const position = input.length - 1 - i;
          const digit = input[i];
          const digitValue = parseInt(digit, 8);
          const positionValue = Math.pow(8, position);
          const value = digitValue * positionValue;
          sum += value;
          calculations.push(`   ${digit}₈ × 8^${position} = ${digit} × ${positionValue} = ${value}`);
        }

        steps.push(...calculations);
        steps.push(`Step 3: Add all values:`);
        steps.push(`   ${calculations.map(c => c.split('= ')[2]).join(' + ')} = ${sum}`);
        finalAnswer = `${input}₈ = ${sum}₁₀`;
        break;
      }

      case "Hexadecimal → Octal": {
        steps.push(`Step 1: Convert Hex to Binary first, then Binary to Octal`);
        steps.push(`Step 2: Hex → Binary (each hex digit = 4 bits):`);

        const binaryGroups: string[] = [];
        for (const hexDigit of input) {
          const decimal = parseInt(hexDigit, 16);
          const binary = decimal.toString(2).padStart(4, '0');
          binaryGroups.push(binary);
          steps.push(`   ${hexDigit}₁₆ = ${binary}₂`);
        }

        const fullBinary = binaryGroups.join('');
        steps.push(`   Combined binary: ${fullBinary}`);

        steps.push(`Step 3: Binary → Octal (group by 3 bits from right):`);
        const paddedBinary = fullBinary.padStart(Math.ceil(fullBinary.length / 3) * 3, '0');
        const octalGroups = paddedBinary.match(/.{1,3}/g) || [];

        const octalDigits = octalGroups.map((group) => {
          const decimal = parseInt(group, 2);
          steps.push(`   ${group}₂ = ${decimal}₈`);
          return decimal.toString();
        });

        finalAnswer = `${input}₁₆ = ${fullBinary}₂ = ${octalDigits.join('')}₈`;
        break;
      }

      case "Octal → Hexadecimal": {
        steps.push(`Step 1: Convert Octal to Binary first, then Binary to Hex`);
        steps.push(`Step 2: Octal → Binary (each octal digit = 3 bits):`);

        const binaryGroups: string[] = [];
        for (const octalDigit of input) {
          const decimal = parseInt(octalDigit, 8);
          const binary = decimal.toString(2).padStart(3, '0');
          binaryGroups.push(binary);
          steps.push(`   ${octalDigit}₈ = ${binary}₂`);
        }

        const fullBinary = binaryGroups.join('');
        steps.push(`   Combined binary: ${fullBinary}`);

        steps.push(`Step 3: Binary → Hex (group by 4 bits from right):`);
        const paddedBinary = fullBinary.padStart(Math.ceil(fullBinary.length / 4) * 4, '0');
        const hexGroups = paddedBinary.match(/.{1,4}/g) || [];

        const hexDigits = hexGroups.map((group) => {
          const decimal = parseInt(group, 2);
          const hex = decimal.toString(16).toUpperCase();
          steps.push(`   ${group}₂ = ${decimal}₁₀ = ${hex}₁₆`);
          return hex;
        });

        finalAnswer = `${input}₈ = ${fullBinary}₂ = ${hexDigits.join('')}₁₆`;
        break;
      }
    }

    return { steps, finalAnswer };
  };

  const generateQuestion = (type: string): PracticeQuestion => {
    const randomNum = Math.floor(Math.random() * 200) + 10;

    let questionType = "";
    let inputValue = "";
    let correctAnswer = "";

    switch (type) {
      case "binary-decimal": {
        const isBinToDec = Math.random() > 0.5;
        if (isBinToDec) {
          questionType = "Binary → Decimal";
          inputValue = randomNum.toString(2);
          correctAnswer = randomNum.toString();
        } else {
          questionType = "Decimal → Binary";
          inputValue = randomNum.toString();
          correctAnswer = randomNum.toString(2);
        }
        break;
      }
      case "binary-hex": {
        const isBinToHex = Math.random() > 0.5;
        if (isBinToHex) {
          questionType = "Binary → Hexadecimal";
          inputValue = randomNum.toString(2);
          correctAnswer = randomNum.toString(16).toUpperCase();
        } else {
          questionType = "Hexadecimal → Binary";
          inputValue = randomNum.toString(16).toUpperCase();
          correctAnswer = randomNum.toString(2);
        }
        break;
      }
      case "binary-octal": {
        const isBinToOct = Math.random() > 0.5;
        if (isBinToOct) {
          questionType = "Binary → Octal";
          inputValue = randomNum.toString(2);
          correctAnswer = randomNum.toString(8);
        } else {
          questionType = "Octal → Binary";
          inputValue = randomNum.toString(8);
          correctAnswer = randomNum.toString(2);
        }
        break;
      }
      case "decimal-hex": {
        const isDecToHex = Math.random() > 0.5;
        if (isDecToHex) {
          questionType = "Decimal → Hexadecimal";
          inputValue = randomNum.toString();
          correctAnswer = randomNum.toString(16).toUpperCase();
        } else {
          questionType = "Hexadecimal → Decimal";
          inputValue = randomNum.toString(16).toUpperCase();
          correctAnswer = randomNum.toString();
        }
        break;
      }
      case "decimal-octal": {
        const isDecToOct = Math.random() > 0.5;
        if (isDecToOct) {
          questionType = "Decimal → Octal";
          inputValue = randomNum.toString();
          correctAnswer = randomNum.toString(8);
        } else {
          questionType = "Octal → Decimal";
          inputValue = randomNum.toString(8);
          correctAnswer = randomNum.toString();
        }
        break;
      }
      case "hex-octal": {
        const isHexToOct = Math.random() > 0.5;
        if (isHexToOct) {
          questionType = "Hexadecimal → Octal";
          inputValue = randomNum.toString(16).toUpperCase();
          correctAnswer = randomNum.toString(8);
        } else {
          questionType = "Octal → Hexadecimal";
          inputValue = randomNum.toString(8);
          correctAnswer = randomNum.toString(16).toUpperCase();
        }
        break;
      }
    }

    const detailedExplanation = generateDetailedExplanation(questionType, inputValue, correctAnswer, randomNum);

    return {
      input: inputValue,
      correctAnswer,
      type: questionType,
      detailedExplanation
    };
  };

  const startPractice = (type: string) => {
    setSelectedType(type);
    setCurrentQuestion(generateQuestion(type));
    setUserAnswer("");
    setFeedback(null);
    setShowExplanation(false);
  };

  const checkAnswer = () => {
    if (!currentQuestion) return;

    const isCorrect = userAnswer.trim().toUpperCase() === currentQuestion.correctAnswer.toUpperCase();
    setFeedback(isCorrect ? "correct" : "incorrect");
    setShowExplanation(true);
    setScore(prev => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1
    }));

    // Save to localStorage for progress tracking
    const practiceTotal = parseInt(localStorage.getItem("practiceTotal") || "0");
    localStorage.setItem("practiceTotal", (practiceTotal + 1).toString());

    if (isCorrect) {
      const practiceCorrect = parseInt(localStorage.getItem("practiceCorrect") || "0");
      localStorage.setItem("practiceCorrect", (practiceCorrect + 1).toString());
    }

    const practiceCompleted = parseInt(localStorage.getItem("practiceCompleted") || "0");
    localStorage.setItem("practiceCompleted", (practiceCompleted + 1).toString());

    // Save to practice history
    const historyItem = {
      id: Date.now().toString(),
      question: currentQuestion.input,
      userAnswer: userAnswer.trim(),
      correctAnswer: currentQuestion.correctAnswer,
      isCorrect,
      type: currentQuestion.type,
      timestamp: Date.now(),
    };

    const savedHistory = localStorage.getItem("practiceHistory");
    const practiceHistory = savedHistory ? JSON.parse(savedHistory) : [];
    practiceHistory.unshift(historyItem);
    localStorage.setItem("practiceHistory", JSON.stringify(practiceHistory.slice(0, 100)));

    setHistory(prev => [{
      question: currentQuestion.input,
      userAnswer: userAnswer.trim(),
      correctAnswer: currentQuestion.correctAnswer,
      isCorrect,
      type: currentQuestion.type
    }, ...prev.slice(0, 9)]);
  };

  const nextQuestion = () => {
    setCurrentQuestion(generateQuestion(selectedType));
    setUserAnswer("");
    setFeedback(null);
    setShowExplanation(false);
  };

  const resetPractice = () => {
    setSelectedType("");
    setCurrentQuestion(null);
    setUserAnswer("");
    setFeedback(null);
    setShowExplanation(false);
    setScore({ correct: 0, total: 0 });
  };

  const clearHistory = () => {
    setHistory([]);
  };

  return (
    <div className={`relative min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-7xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl md:text-7xl font-black bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent mb-4">
            Practice Mode
          </h1>
          <p className="text-xl text-slate-400">Master conversions with detailed step-by-step solutions</p>
        </motion.div>

        {!selectedType && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
          >
            <div className="text-center mb-8">
              <Target className="w-16 h-16 text-cyan-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Choose a Conversion Type</h2>
              <p className="text-slate-400">Select what you want to practice</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-5xl mx-auto">
              {conversionTypes.map((type) => (
                <motion.button
                  key={type.id}
                  onClick={() => startPractice(type.id)}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={`bg-gradient-to-br from-${type.color}-500/10 to-${type.color}-600/10 border-2 border-${type.color}-500/30 hover:border-${type.color}-400 rounded-xl p-6 text-left hover:shadow-lg transition-all`}
                >
                  <div className="text-lg font-bold text-white mb-2">{type.label}</div>
                  <div className="text-sm text-slate-400">Practice both directions</div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {currentQuestion && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <Button
                  onClick={resetPractice}
                  variant="outline"
                  className="border-2 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Change Type
                </Button>

                <div className="bg-gradient-to-br from-purple-500/10 to-pink-600/10 border-2 border-purple-500/30 rounded-xl px-6 py-3">
                  <div className="text-purple-400 text-sm font-semibold">Score</div>
                  <div className="text-white text-xl font-bold">
                    {score.correct} / {score.total}
                    {score.total > 0 && (
                      <span className="text-sm text-purple-400 ml-2">
                        ({Math.round((score.correct / score.total) * 100)}%)
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <motion.div
                key={currentQuestion.input}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-2 border-cyan-500/30 rounded-2xl p-8"
              >
                <div className="text-center mb-8">
                  <div className="inline-block bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border-2 border-cyan-500/50 rounded-lg px-4 py-2 mb-4">
                    <div className="text-cyan-400 text-sm font-semibold">{currentQuestion.type}</div>
                  </div>
                  <div className="text-6xl font-bold text-white font-mono mb-2">
                    {currentQuestion.input}
                  </div>
                  <p className="text-slate-400">Convert this number</p>
                </div>

                <div className="max-w-md mx-auto space-y-4">
                  <div>
                    <Label htmlFor="answer" className="text-slate-300 mb-2 block font-semibold">
                      Your Answer
                    </Label>
                    <Input
                      id="answer"
                      value={userAnswer}
                      onChange={(e) => setUserAnswer(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && !feedback && checkAnswer()}
                      placeholder="Type your answer..."
                      disabled={!!feedback}
                      className="bg-slate-800 border-slate-600 text-white text-2xl h-16 font-mono text-center focus:border-cyan-500"
                    />
                  </div>

                  {!feedback && (
                    <Button
                      onClick={checkAnswer}
                      disabled={!userAnswer.trim()}
                      className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-6 text-lg rounded-xl"
                    >
                      Check Answer
                    </Button>
                  )}

                  {feedback && (
                    <motion.div
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-4"
                    >
                      <div
                        className={`${
                          feedback === "correct"
                            ? "bg-green-500/10 border-green-500/30 text-green-400"
                            : "bg-red-500/10 border-red-500/30 text-red-400"
                        } border-2 rounded-xl p-6 flex items-start gap-3`}
                      >
                        {feedback === "correct" ? (
                          <CheckCircle2 className="w-6 h-6 flex-shrink-0 mt-1" />
                        ) : (
                          <XCircle className="w-6 h-6 flex-shrink-0 mt-1" />
                        )}
                        <div>
                          <div className="font-semibold text-lg mb-1">
                            {feedback === "correct" ? "Correct! Well done!" : "Incorrect"}
                          </div>
                          {feedback === "incorrect" && (
                            <div className="text-sm">
                              The correct answer is: <span className="font-bold font-mono text-lg text-white">{currentQuestion.correctAnswer}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {showExplanation && (
                        <div className={`border-2 rounded-xl p-6 ${
                          feedback === "correct"
                            ? "bg-green-500/10 border-green-500/30"
                            : "bg-blue-500/10 border-blue-500/30"
                        }`}>
                          <div className="flex items-start gap-3 mb-4">
                            <Lightbulb className={`w-6 h-6 flex-shrink-0 mt-1 ${
                              feedback === "correct" ? "text-green-400" : "text-blue-400"
                            }`} />
                            <h3 className="text-xl font-bold text-white">
                              {feedback === "correct" ? "Here's How You Got It Right!" : "Here's How to Solve It:"}
                            </h3>
                          </div>
                          <div className="space-y-1 bg-slate-900 rounded-lg p-4 border-2 border-slate-700 max-h-96 overflow-y-auto">
                            {currentQuestion.detailedExplanation.steps.map((step, index) => (
                              <div
                                key={index}
                                className={`leading-relaxed font-mono text-sm ${
                                  step.startsWith('Step') || step.startsWith('━━━')
                                    ? 'text-cyan-400 font-bold mt-3'
                                    : 'text-slate-300'
                                } ${
                                  step.includes('✓') || step.includes('Result:')
                                    ? 'text-green-400 font-semibold bg-green-500/10 p-2 rounded border border-green-500/30'
                                    : ''
                                }`}
                              >
                                {step}
                              </div>
                            ))}
                            <div className="mt-4 pt-4 border-t-2 border-green-500/30 bg-green-500/10 rounded-lg p-3">
                              <div className="font-bold text-green-400 text-lg">
                                ✓ Final Answer: {currentQuestion.detailedExplanation.finalAnswer}
                              </div>
                            </div>
                          </div>
                          {feedback === "incorrect" && (
                            <div className="mt-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                              <p className="text-sm text-yellow-400">
                                <strong>💡 Tip:</strong> Review each step carefully to understand where you went wrong. Practice makes perfect!
                              </p>
                            </div>
                          )}
                        </div>
                      )}

                      <Button
                        onClick={nextQuestion}
                        className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white py-6 text-lg rounded-xl"
                      >
                        Next Question
                      </Button>
                    </motion.div>
                  )}
                </div>
              </motion.div>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 border-2 border-purple-500/30 rounded-2xl p-6 sticky top-8">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <History className="w-5 h-5 text-purple-400" />
                    <h3 className="text-lg font-bold text-white">History</h3>
                  </div>
                  {history.length > 0 && (
                    <Button
                      onClick={clearHistory}
                      variant="ghost"
                      size="sm"
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {history.length === 0 ? (
                    <p className="text-slate-400 text-sm text-center py-8">
                      No practice history yet
                    </p>
                  ) : (
                    history.map((item, idx) => (
                      <motion.div
                        key={idx}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className={`${
                          item.isCorrect
                            ? "bg-green-500/10 border-green-500/30"
                            : "bg-red-500/10 border-red-500/30"
                        } border rounded-lg p-3`}
                      >
                        <div className="text-xs text-slate-400 mb-1">{item.type}</div>
                        <div className="text-sm font-mono">
                          <div className="text-white font-semibold">{item.question}</div>
                          <div className={`text-xs mt-1 ${item.isCorrect ? "text-green-400" : "text-red-400"}`}>
                            {item.isCorrect ? "✓ Correct" : `✗ Wrong: ${item.userAnswer}`}
                          </div>
                        </div>
                      </motion.div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

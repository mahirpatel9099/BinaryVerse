import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import {
  ArrowLeft,
  Trophy,
  Target,
  Zap,
  TrendingUp,
  Award,
  Calendar,
  BarChart3,
} from "lucide-react";
import { Button } from "./ui/button";

interface Stats {
  totalConversions: number;
  gameHighScore: number;
  accuracy: number;
  dailyStreak: number;
  level: number;
  achievements: Achievement[];
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress?: number;
  target?: number;
}

export function ProgressDashboard() {
  const [stats, setStats] = useState<Stats>({
    totalConversions: 0,
    gameHighScore: 0,
    accuracy: 0,
    dailyStreak: 0,
    level: 1,
    achievements: [],
  });

  useEffect(() => {
    // Load stats from localStorage
    const conversions = parseInt(localStorage.getItem("totalConversions") || "0");
    const gameScore = parseInt(localStorage.getItem("binaryRushHighScore") || "0");
    const streak = parseInt(localStorage.getItem("dailyStreak") || "0");

    const allAchievements: Achievement[] = [
      {
        id: "beginner",
        title: "Binary Beginner",
        description: "Complete your first conversion",
        icon: "🎯",
        unlocked: conversions > 0,
      },
      {
        id: "fast",
        title: "Fast Converter",
        description: "Complete 10 conversions",
        icon: "⚡",
        unlocked: conversions >= 10,
        progress: Math.min(conversions, 10),
        target: 10,
      },
      {
        id: "master",
        title: "Conversion Master",
        description: "Complete 50 conversions",
        icon: "🏆",
        unlocked: conversions >= 50,
        progress: Math.min(conversions, 50),
        target: 50,
      },
      {
        id: "gamer",
        title: "Game Champion",
        description: "Score 100+ in Binary Rush",
        icon: "🎮",
        unlocked: gameScore >= 100,
        progress: Math.min(gameScore, 100),
        target: 100,
      },
      {
        id: "streak",
        title: "Dedicated Learner",
        description: "Maintain a 7-day streak",
        icon: "🔥",
        unlocked: streak >= 7,
        progress: Math.min(streak, 7),
        target: 7,
      },
      {
        id: "expert",
        title: "Binary Expert",
        description: "Complete 100 conversions",
        icon: "💎",
        unlocked: conversions >= 100,
        progress: Math.min(conversions, 100),
        target: 100,
      },
    ];

    const accuracy = conversions > 0 ? Math.min(85 + Math.random() * 10, 100) : 0;
    const level = Math.floor(conversions / 10) + 1;

    setStats({
      totalConversions: conversions,
      gameHighScore: gameScore,
      accuracy: Math.round(accuracy),
      dailyStreak: streak,
      level,
      achievements: allAchievements,
    });
  }, []);

  const unlockedCount = stats.achievements.filter((a) => a.unlocked).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 px-4 py-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/">
            <Button
              variant="ghost"
              className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </Link>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            Your Progress
          </h1>
          <p className="text-xl text-slate-300">Track your learning journey</p>
        </motion.div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1 }}
            className="relative bg-gradient-to-br from-cyan-500/10 to-blue-600/10 backdrop-blur-md border-2 border-cyan-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Target className="w-8 h-8 text-cyan-400" />
              <div className="text-4xl font-bold text-white">{stats.totalConversions}</div>
            </div>
            <div className="text-sm text-slate-300 font-medium">Total Conversions</div>
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-transparent rounded-2xl" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 }}
            className="relative bg-gradient-to-br from-purple-500/10 to-pink-600/10 backdrop-blur-md border-2 border-purple-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Trophy className="w-8 h-8 text-purple-400" />
              <div className="text-4xl font-bold text-white">{stats.gameHighScore}</div>
            </div>
            <div className="text-sm text-slate-300 font-medium">Game High Score</div>
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-transparent rounded-2xl" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="relative bg-gradient-to-br from-green-500/10 to-emerald-600/10 backdrop-blur-md border-2 border-green-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8 text-green-400" />
              <div className="text-4xl font-bold text-white">{stats.accuracy}%</div>
            </div>
            <div className="text-sm text-slate-300 font-medium">Accuracy</div>
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent rounded-2xl" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4 }}
            className="relative bg-gradient-to-br from-orange-500/10 to-yellow-600/10 backdrop-blur-md border-2 border-orange-500/30 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <Calendar className="w-8 h-8 text-orange-400" />
              <div className="text-4xl font-bold text-white">{stats.dailyStreak}</div>
            </div>
            <div className="text-sm text-slate-300 font-medium">Day Streak 🔥</div>
            <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent rounded-2xl" />
          </motion.div>
        </div>

        {/* Level Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-gradient-to-br from-blue-500/10 to-purple-600/10 backdrop-blur-md border-2 border-blue-500/30 rounded-2xl p-8 mb-12"
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-3xl font-bold text-white mb-2">Level {stats.level}</h2>
              <p className="text-slate-300">
                {stats.totalConversions % 10}/10 conversions to next level
              </p>
            </div>
            <Zap className="w-12 h-12 text-yellow-400" />
          </div>
          <div className="w-full bg-slate-700/50 rounded-full h-4 overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(stats.totalConversions % 10) * 10}%` }}
              transition={{ duration: 1, delay: 0.7 }}
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
            />
          </div>
        </motion.div>

        {/* Achievements */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-3xl font-bold text-white flex items-center gap-3">
              <Award className="w-8 h-8 text-yellow-400" />
              Achievements
            </h2>
            <div className="text-slate-300">
              {unlockedCount}/{stats.achievements.length} Unlocked
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {stats.achievements.map((achievement, index) => (
              <motion.div
                key={achievement.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 + index * 0.1 }}
                className={`relative backdrop-blur-md border-2 rounded-2xl p-6 transition-all ${
                  achievement.unlocked
                    ? "bg-gradient-to-br from-yellow-500/10 to-orange-600/10 border-yellow-500/50"
                    : "bg-slate-800/30 border-slate-700/30 opacity-60"
                }`}
              >
                <div className="text-5xl mb-3">{achievement.icon}</div>
                <h3 className="text-xl font-bold text-white mb-2">
                  {achievement.title}
                </h3>
                <p className="text-sm text-slate-300 mb-4">
                  {achievement.description}
                </p>

                {achievement.target && !achievement.unlocked && (
                  <div>
                    <div className="flex justify-between text-xs text-slate-400 mb-2">
                      <span>Progress</span>
                      <span>
                        {achievement.progress}/{achievement.target}
                      </span>
                    </div>
                    <div className="w-full bg-slate-700/50 rounded-full h-2 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full"
                        style={{
                          width: `${
                            ((achievement.progress || 0) / achievement.target) * 100
                          }%`,
                        }}
                      />
                    </div>
                  </div>
                )}

                {achievement.unlocked && (
                  <div className="flex items-center gap-2 text-yellow-400 text-sm font-semibold">
                    <Trophy className="w-4 h-4" />
                    Unlocked!
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="mt-12 text-center"
        >
          <Link to="/converter">
            <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg shadow-cyan-500/50">
              Continue Learning
            </Button>
          </Link>
        </motion.div>
      </div>
    </div>
  );
}

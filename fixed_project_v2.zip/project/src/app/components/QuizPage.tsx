import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Trophy, Timer, CheckCircle2, XCircle, RotateCcw } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import confetti from "canvas-confetti";

interface Question {
  input: string;
  correctAnswer: string;
  type: string;
}

export function QuizPage() {
  const [score, setScore] = useState(0);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [timeLeft, setTimeLeft] = useState(60);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);
  const [totalQuestions] = useState(10);

  const generateQuestion = (): Question => {
    const types = [
      "binary-to-decimal",
      "decimal-to-binary",
      "binary-to-hex",
      "hex-to-binary",
      "decimal-to-hex",
      "hex-to-decimal",
      "binary-to-octal",
      "octal-to-binary",
      "decimal-to-octal",
      "octal-to-decimal"
    ];
    const type = types[Math.floor(Math.random() * types.length)];
    const randomNum = Math.floor(Math.random() * 200) + 1;

    switch (type) {
      case "binary-to-decimal": {
        const binary = randomNum.toString(2);
        return {
          input: binary,
          correctAnswer: randomNum.toString(),
          type: "Binary → Decimal"
        };
      }
      case "decimal-to-binary": {
        const binary = randomNum.toString(2);
        return {
          input: randomNum.toString(),
          correctAnswer: binary,
          type: "Decimal → Binary"
        };
      }
      case "binary-to-hex": {
        const binary = randomNum.toString(2);
        const hex = randomNum.toString(16).toUpperCase();
        return {
          input: binary,
          correctAnswer: hex,
          type: "Binary → Hexadecimal"
        };
      }
      case "hex-to-binary": {
        const hex = randomNum.toString(16).toUpperCase();
        const binary = randomNum.toString(2);
        return {
          input: hex,
          correctAnswer: binary,
          type: "Hexadecimal → Binary"
        };
      }
      case "decimal-to-hex": {
        const hex = randomNum.toString(16).toUpperCase();
        return {
          input: randomNum.toString(),
          correctAnswer: hex,
          type: "Decimal → Hexadecimal"
        };
      }
      case "hex-to-decimal": {
        const hex = randomNum.toString(16).toUpperCase();
        return {
          input: hex,
          correctAnswer: randomNum.toString(),
          type: "Hexadecimal → Decimal"
        };
      }
      case "binary-to-octal": {
        const binary = randomNum.toString(2);
        const octal = randomNum.toString(8);
        return {
          input: binary,
          correctAnswer: octal,
          type: "Binary → Octal"
        };
      }
      case "octal-to-binary": {
        const octal = randomNum.toString(8);
        const binary = randomNum.toString(2);
        return {
          input: octal,
          correctAnswer: binary,
          type: "Octal → Binary"
        };
      }
      case "decimal-to-octal": {
        const octal = randomNum.toString(8);
        return {
          input: randomNum.toString(),
          correctAnswer: octal,
          type: "Decimal → Octal"
        };
      }
      case "octal-to-decimal": {
        const octal = randomNum.toString(8);
        return {
          input: octal,
          correctAnswer: randomNum.toString(),
          type: "Octal → Decimal"
        };
      }
      default:
        return {
          input: randomNum.toString(2),
          correctAnswer: randomNum.toString(),
          type: "Binary → Decimal"
        };
    }
  };

  const startQuiz = () => {
    setScore(0);
    setQuestionNumber(1);
    setQuizComplete(false);
    setCurrentQuestion(generateQuestion());
    setIsTimerActive(true);
    setTimeLeft(60);
    setFeedback(null);
    setUserAnswer("");
  };

  const nextQuestion = () => {
    if (questionNumber >= totalQuestions) {
      setQuizComplete(true);
      setIsTimerActive(false);
      if (score >= totalQuestions * 0.7) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
      return;
    }

    setQuestionNumber(questionNumber + 1);
    setCurrentQuestion(generateQuestion());
    setUserAnswer("");
    setFeedback(null);
    setTimeLeft(60);
  };

  const checkAnswer = () => {
    if (!currentQuestion) return;

    const isCorrect = userAnswer.trim() === currentQuestion.correctAnswer;
    setFeedback(isCorrect ? "correct" : "incorrect");

    if (isCorrect) {
      setScore(score + 1);
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 }
      });
    }

    setIsTimerActive(false);

    setTimeout(() => {
      nextQuestion();
      setIsTimerActive(true);
    }, 2000);
  };

  useEffect(() => {
    if (!isTimerActive) return;

    if (timeLeft === 0) {
      setFeedback("incorrect");
      setIsTimerActive(false);
      setTimeout(() => {
        nextQuestion();
        setIsTimerActive(true);
      }, 2000);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isTimerActive]);

  return (
    <div className="relative z-10 min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-6xl font-black bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-2">
            Practice Quiz
          </h1>
          <p className="text-green-200/70">Test your conversion skills!</p>
        </motion.div>

        {!currentQuestion && !quizComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-green-500/30 rounded-2xl p-12 text-center"
          >
            <Trophy className="w-24 h-24 text-green-400 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-white mb-4">Ready to Start?</h2>
            <p className="text-blue-200/70 mb-8 max-w-md mx-auto">
              You'll have 1 minute for each question. Answer {totalQuestions} questions covering Binary, Decimal, Hexadecimal, and Octal conversions!
            </p>
            <Button
              onClick={startQuiz}
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg shadow-green-500/50"
            >
              Start Quiz
            </Button>
          </motion.div>
        )}

        {currentQuestion && !quizComplete && (
          <div className="space-y-6 w-full">
            <div className="flex flex-wrap items-center justify-center gap-4 md:justify-between">
              <div className="bg-slate-800/50 backdrop-blur-xl border border-cyan-500/30 rounded-xl px-6 py-3">
                <div className="text-cyan-300 text-sm">Question</div>
                <div className="text-white text-2xl font-bold">{questionNumber}/{totalQuestions}</div>
              </div>

              <div className="bg-slate-800/50 backdrop-blur-xl border border-purple-500/30 rounded-xl px-6 py-3">
                <div className="text-purple-300 text-sm">Score</div>
                <div className="text-white text-2xl font-bold">{score}</div>
              </div>

              <motion.div
                animate={{ scale: timeLeft < 10 ? [1, 1.1, 1] : 1 }}
                transition={{ repeat: timeLeft < 10 ? Infinity : 0, duration: 0.5 }}
                className={`bg-slate-800/50 backdrop-blur-xl border ${
                  timeLeft < 10 ? "border-red-500/30" : "border-green-500/30"
                } rounded-xl px-6 py-3`}
              >
                <div className={`${timeLeft < 10 ? "text-red-300" : "text-green-300"} text-sm flex items-center gap-2`}>
                  <Timer className="w-4 h-4" />
                  Time
                </div>
                <div className={`${timeLeft < 10 ? "text-red-400" : "text-white"} text-2xl font-bold`}>
                  {timeLeft}s
                </div>
              </motion.div>
            </div>

            <motion.div
              key={questionNumber}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-cyan-500/30 rounded-2xl p-6 md:p-8 w-full"
            >
              <div className="text-center mb-8">
                <div className="text-cyan-300 text-sm mb-2">{currentQuestion.type}</div>
                <div className="text-5xl font-bold text-white font-mono mb-2">
                  {currentQuestion.input}
                </div>
              </div>

              <div className="max-w-md mx-auto">
                <Input
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && !feedback && checkAnswer()}
                  placeholder="Enter your answer..."
                  disabled={!!feedback}
                  className="bg-slate-950/50 border-cyan-500/30 text-white text-2xl h-16 font-mono text-center focus:border-cyan-400 focus:ring-cyan-400/50 mb-4"
                />

                <AnimatePresence>
                  {feedback && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`${
                        feedback === "correct"
                          ? "bg-green-500/20 border-green-500/40 text-green-300"
                          : "bg-red-500/20 border-red-500/40 text-red-300"
                      } border rounded-lg p-4 mb-4 flex items-center justify-center gap-2`}
                    >
                      {feedback === "correct" ? (
                        <>
                          <CheckCircle2 className="w-5 h-5" />
                          <span className="font-semibold">Correct!</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-5 h-5" />
                          <span className="font-semibold">
                            Incorrect. Answer: {currentQuestion.correctAnswer}
                          </span>
                        </>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>

                {!feedback && (
                  <Button
                    onClick={checkAnswer}
                    disabled={!userAnswer.trim()}
                    className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white py-6 text-lg rounded-xl"
                  >
                    Submit Answer
                  </Button>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {quizComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-xl border border-green-500/30 rounded-2xl p-12 text-center"
          >
            <Trophy className="w-24 h-24 text-green-400 mx-auto mb-6" />
            <h2 className="text-4xl font-bold text-white mb-4">Quiz Complete!</h2>

            <div className="text-6xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-2">
              {score}/{totalQuestions}
            </div>

            <p className="text-xl text-blue-200/70 mb-8">
              {score >= totalQuestions * 0.9
                ? "Outstanding! You're a number system master!"
                : score >= totalQuestions * 0.7
                ? "Great job! Keep practicing!"
                : score >= totalQuestions * 0.5
                ? "Good effort! Review the learning section."
                : "Keep learning! Practice makes perfect."}
            </p>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={startQuiz}
                className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white px-8 py-6 text-lg rounded-xl shadow-lg shadow-green-500/50"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Try Again
              </Button>

              <Link to="/learn">
                <Button
                  variant="outline"
                  className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10 px-8 py-6 text-lg rounded-xl"
                >
                  Review Theory
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Trophy, Timer, CheckCircle2, XCircle, RotateCcw } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import confetti from "canvas-confetti";

interface Question {
  input: string;
  correctAnswer: string;
  type: string;
}

type Difficulty = "easy" | "medium" | "hard" | null;

export function QuizPageNew() {
  const [difficulty, setDifficulty] = useState<Difficulty>(null);
  const [score, setScore] = useState(0);
  const [questionNumber, setQuestionNumber] = useState(1);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);
  const [timeLeft, setTimeLeft] = useState(60);
  const [isTimerActive, setIsTimerActive] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);
  const [totalQuestions] = useState(10);

  const generateQuestion = (diff: Difficulty): Question => {
    let maxNum = 50;
    if (diff === "medium") maxNum = 150;
    if (diff === "hard") maxNum = 500;

    const randomNum = Math.floor(Math.random() * maxNum) + 10;

    let types: string[] = [];
    if (diff === "easy") {
      types = ["binary-to-decimal", "decimal-to-binary"];
    } else if (diff === "medium") {
      types = ["binary-to-decimal", "decimal-to-binary", "decimal-to-hex", "hex-to-decimal"];
    } else {
      types = [
        "binary-to-decimal", "decimal-to-binary",
        "binary-to-hex", "hex-to-binary",
        "decimal-to-hex", "hex-to-decimal",
        "decimal-to-octal", "octal-to-decimal"
      ];
    }

    const type = types[Math.floor(Math.random() * types.length)];

    switch (type) {
      case "binary-to-decimal":
        return {
          input: randomNum.toString(2),
          correctAnswer: randomNum.toString(),
          type: "Binary → Decimal"
        };
      case "decimal-to-binary":
        return {
          input: randomNum.toString(),
          correctAnswer: randomNum.toString(2),
          type: "Decimal → Binary"
        };
      case "binary-to-hex":
        return {
          input: randomNum.toString(2),
          correctAnswer: randomNum.toString(16).toUpperCase(),
          type: "Binary → Hexadecimal"
        };
      case "hex-to-binary":
        return {
          input: randomNum.toString(16).toUpperCase(),
          correctAnswer: randomNum.toString(2),
          type: "Hexadecimal → Binary"
        };
      case "decimal-to-hex":
        return {
          input: randomNum.toString(),
          correctAnswer: randomNum.toString(16).toUpperCase(),
          type: "Decimal → Hexadecimal"
        };
      case "hex-to-decimal":
        return {
          input: randomNum.toString(16).toUpperCase(),
          correctAnswer: randomNum.toString(),
          type: "Hexadecimal → Decimal"
        };
      case "decimal-to-octal":
        return {
          input: randomNum.toString(),
          correctAnswer: randomNum.toString(8),
          type: "Decimal → Octal"
        };
      case "octal-to-decimal":
        return {
          input: randomNum.toString(8),
          correctAnswer: randomNum.toString(),
          type: "Octal → Decimal"
        };
      default:
        return generateQuestion("easy");
    }
  };

  const startQuiz = (selectedDifficulty: Difficulty) => {
    setDifficulty(selectedDifficulty);
    setScore(0);
    setQuestionNumber(1);
    setQuizComplete(false);
    setCurrentQuestion(generateQuestion(selectedDifficulty));
    setIsTimerActive(true);
    setTimeLeft(60);
    setFeedback(null);
    setUserAnswer("");
  };

  const nextQuestion = () => {
    if (questionNumber >= totalQuestions) {
      setQuizComplete(true);
      setIsTimerActive(false);
      if (score >= totalQuestions * 0.7) {
        confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      }
      return;
    }

    setQuestionNumber(questionNumber + 1);
    setCurrentQuestion(generateQuestion(difficulty));
    setUserAnswer("");
    setFeedback(null);
    setTimeLeft(60);
  };

  const checkAnswer = () => {
    if (!currentQuestion) return;

    const isCorrect = userAnswer.trim().toUpperCase() === currentQuestion.correctAnswer.toUpperCase();
    setFeedback(isCorrect ? "correct" : "incorrect");

    if (isCorrect) {
      setScore(score + 1);
      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
    }

    setIsTimerActive(false);

    setTimeout(() => {
      nextQuestion();
      setIsTimerActive(true);
    }, 2000);
  };

  useEffect(() => {
    if (!isTimerActive) return;

    if (timeLeft === 0) {
      setFeedback("incorrect");
      setIsTimerActive(false);
      setTimeout(() => {
        nextQuestion();
        setIsTimerActive(true);
      }, 2000);
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(timeLeft - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isTimerActive]);

  const resetQuiz = () => {
    setDifficulty(null);
    setCurrentQuestion(null);
    setUserAnswer("");
    setFeedback(null);
    setQuizComplete(false);
    setScore(0);
    setQuestionNumber(1);
  };

  return (
    <div className="relative min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Link to="/">
          <Button variant="ghost" className="mb-6 text-blue-700 hover:text-blue-900 hover:bg-blue-50">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-2">
            Timed Quiz
          </h1>
          <p className="text-gray-600 text-lg">Test your skills with different difficulty levels</p>
        </motion.div>

        {!difficulty && !quizComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-200 p-12 text-center"
          >
            <Trophy className="w-24 h-24 text-blue-600 mx-auto mb-6" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Select Difficulty Level</h2>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">
              Choose your challenge level and answer {totalQuestions} questions (1 minute each)
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-3xl mx-auto">
              <button
                onClick={() => startQuiz("easy")}
                className="bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-300 hover:border-green-500 rounded-xl p-6 transition-all hover:shadow-lg"
              >
                <div className="text-2xl font-bold text-green-700 mb-2">Easy</div>
                <div className="text-sm text-gray-600">Binary ↔ Decimal</div>
                <div className="text-sm text-gray-600">Small numbers (10-50)</div>
              </button>

              <button
                onClick={() => startQuiz("medium")}
                className="bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-300 hover:border-orange-500 rounded-xl p-6 transition-all hover:shadow-lg"
              >
                <div className="text-2xl font-bold text-orange-700 mb-2">Medium</div>
                <div className="text-sm text-gray-600">+ Hexadecimal</div>
                <div className="text-sm text-gray-600">Medium numbers (10-150)</div>
              </button>

              <button
                onClick={() => startQuiz("hard")}
                className="bg-gradient-to-br from-red-50 to-red-100 border-2 border-red-300 hover:border-red-500 rounded-xl p-6 transition-all hover:shadow-lg"
              >
                <div className="text-2xl font-bold text-red-700 mb-2">Hard</div>
                <div className="text-sm text-gray-600">All conversions + Octal</div>
                <div className="text-sm text-gray-600">Large numbers (10-500)</div>
              </button>
            </div>
          </motion.div>
        )}

        {currentQuestion && !quizComplete && (
          <div className="space-y-6 w-full">
            <div className="flex flex-wrap items-center justify-center gap-4 md:justify-between">
              <div className="bg-white border-2 border-blue-200 rounded-xl px-6 py-3 shadow-md">
                <div className="text-blue-600 text-sm font-semibold">Question</div>
                <div className="text-gray-900 text-2xl font-bold">{questionNumber}/{totalQuestions}</div>
              </div>

              <div className="bg-white border-2 border-purple-200 rounded-xl px-6 py-3 shadow-md">
                <div className="text-purple-600 text-sm font-semibold">Score</div>
                <div className="text-gray-900 text-2xl font-bold">{score}</div>
              </div>

              <motion.div
                animate={{ scale: timeLeft < 10 ? [1, 1.1, 1] : 1 }}
                transition={{ repeat: timeLeft < 10 ? Infinity : 0, duration: 0.5 }}
                className={`bg-white border-2 ${
                  timeLeft < 10 ? "border-red-300" : "border-green-200"
                } rounded-xl px-6 py-3 shadow-md`}
              >
                <div className={`${timeLeft < 10 ? "text-red-600" : "text-green-600"} text-sm font-semibold flex items-center gap-2`}>
                  <Timer className="w-4 h-4" />
                  Time
                </div>
                <div className={`${timeLeft < 10 ? "text-red-700" : "text-gray-900"} text-2xl font-bold`}>
                  {timeLeft}s
                </div>
              </motion.div>
            </div>

            <motion.div
              key={questionNumber}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-white rounded-2xl shadow-lg border border-gray-200 p-6 md:p-8 w-full"
            >
              <div className="text-center mb-8">
                <div className="inline-block bg-blue-100 border border-blue-300 rounded-lg px-4 py-2 mb-4">
                  <div className="text-blue-700 text-sm font-semibold">{currentQuestion.type}</div>
                </div>
                <div className="text-5xl font-bold text-gray-900 font-mono mb-2">
                  {currentQuestion.input}
                </div>
                <p className="text-gray-600">Convert this number</p>
              </div>

              <div className="max-w-md mx-auto">
                <Input
                  value={userAnswer}
                  onChange={(e) => setUserAnswer(e.target.value)}
                  onKeyPress={(e) => e.key === "Enter" && !feedback && checkAnswer()}
                  placeholder="Enter your answer..."
                  disabled={!!feedback}
                  className="bg-gray-50 border-gray-300 text-gray-900 text-2xl h-16 font-mono text-center focus:border-blue-500 focus:ring-blue-500 mb-4"
                />

                <AnimatePresence>
                  {feedback && (
                    <motion.div
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      className={`${
                        feedback === "correct"
                          ? "bg-green-50 border-green-300 text-green-700"
                          : "bg-red-50 border-red-300 text-red-700"
                      } border-2 rounded-lg p-4 mb-4 flex items-center justify-center gap-2`}
                    >
                      {feedback === "correct" ? (
                        <>
                          <CheckCircle2 className="w-5 h-5" />
                          <span className="font-semibold">Correct!</span>
                        </>
                      ) : (
                        <>
                          <XCircle className="w-5 h-5" />
                          <span className="font-semibold">
                            Incorrect. Answer: {currentQuestion.correctAnswer}
                          </span>
                        </>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>

                {!feedback && (
                  <Button
                    onClick={checkAnswer}
                    disabled={!userAnswer.trim()}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 text-lg rounded-xl shadow-md"
                  >
                    Submit Answer
                  </Button>
                )}
              </div>
            </motion.div>
          </div>
        )}

        {quizComplete && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl shadow-lg border border-gray-200 p-12 text-center"
          >
            <Trophy className="w-24 h-24 text-blue-600 mx-auto mb-6" />
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Quiz Complete!</h2>

            <div className="text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">
              {score}/{totalQuestions}
            </div>

            <p className="text-xl text-gray-700 mb-2">
              Difficulty: <span className="font-bold capitalize">{difficulty}</span>
            </p>

            <p className="text-xl text-gray-600 mb-8">
              {score >= totalQuestions * 0.9
                ? "Outstanding! You're a master!"
                : score >= totalQuestions * 0.7
                ? "Great job! Keep practicing!"
                : score >= totalQuestions * 0.5
                ? "Good effort! Review theory."
                : "Keep learning! Practice more."}
            </p>

            <div className="flex gap-4 justify-center">
              <Button
                onClick={resetQuiz}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 text-lg rounded-xl shadow-md"
              >
                <RotateCcw className="w-5 h-5 mr-2" />
                Try Again
              </Button>

              <Link to="/learn">
                <Button
                  variant="outline"
                  className="border-2 border-purple-300 text-purple-700 hover:bg-purple-50 px-8 py-6 text-lg rounded-xl"
                >
                  Review Theory
                </Button>
              </Link>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

import { Moon, Sun } from "lucide-react";
import { Button } from "./ui/button";
import { useTheme } from "../contexts/ThemeContext";

interface ThemeToggleProps {
  className?: string;
}

export function ThemeToggle({ className = "" }: ThemeToggleProps) {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === "dark";

  return (
    <Button
      onClick={toggleTheme}
      variant="outline"
      className={`rounded-full p-3 ${
        isDark
          ? "bg-slate-800/50 border-cyan-500/50 text-cyan-400 hover:bg-slate-700/50"
          : "bg-white/50 border-blue-500/50 text-blue-600 hover:bg-white/70"
      } backdrop-blur-md ${className}`}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
    >
      {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
    </Button>
  );
}

import { useState, useEffect } from "react";
import { Link } from "react-router";
import { motion, AnimatePresence } from "motion/react";
import { ArrowLeft, Volume2, VolumeX, Copy, RotateCcw, History, Trash2, Sparkles, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { ThemeToggle } from "./ThemeToggle";
import { useTheme } from "../contexts/ThemeContext";

interface ConversionResult {
  binary: string;
  decimal: string;
  hexadecimal: string;
  octal: string;
  isApproximate?: boolean;
}

interface HistoryItem {
  id: string;
  input: string;
  inputBase: string;
  results: ConversionResult;
  timestamp: number;
}

export function UniversalConverter() {
  const { theme } = useTheme();
  const isDark = theme === "dark";
  const [input, setInput] = useState("");
  const [inputBase, setInputBase] = useState<"binary" | "decimal" | "hex" | "octal">("decimal");
  const [result, setResult] = useState<ConversionResult | null>(null);
  const [steps, setSteps] = useState<string[]>([]);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const savedHistory = localStorage.getItem("conversionHistory");
    if (savedHistory) {
      setHistory(JSON.parse(savedHistory));
    }
  }, []);

  const playSound = () => {
    if (!soundEnabled) return;
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = 800;
    oscillator.type = 'sine';

    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  };

  const validateDecimalFormat = (value: string): boolean => {
    const dotCount = (value.match(/\./g) || []).length;
    return dotCount <= 1;
  };

  const detectBase = (value: string): string => {
    const absValue = value.replace(/^-/, "");

    if (/^0x[0-9A-Fa-f.]+$/i.test(absValue)) return "hex";
    if (/^0o[0-7.]+$/i.test(absValue)) return "octal";
    if (/^[01.]+$/.test(absValue) && absValue.length > 1) return "binary";
    if (/^[0-9.]+$/.test(absValue)) return "decimal";
    if (/^[0-9A-Fa-f.]+$/i.test(absValue)) return "hex";
    return "unknown";
  };

  const convertIntegerToBinary = (num: number): string => {
    if (num === 0) return "0";
    let result = "";
    let n = num;
    while (n > 0) {
      result = (n % 2) + result;
      n = Math.floor(n / 2);
    }
    return result;
  };

  const convertFractionalToBinary = (fraction: number, precision: number = 16): { binary: string; isApproximate: boolean } => {
    if (fraction === 0) return { binary: "", isApproximate: false };

    let result = "";
    let f = fraction;
    let iterations = 0;
    const seen = new Set<number>();
    let isApproximate = false;

    while (f > 0 && iterations < precision) {
      if (seen.has(f)) {
        isApproximate = true;
        break;
      }
      seen.add(f);

      f *= 2;
      if (f >= 1) {
        result += "1";
        f -= 1;
      } else {
        result += "0";
      }
      iterations++;
    }

    if (f > 0 && iterations >= precision) {
      isApproximate = true;
    }

    return { binary: result, isApproximate };
  };

  const convertDecimalToBinary = (decimalStr: string): { binary: string; isApproximate: boolean } => {
    const isNegative = decimalStr.startsWith("-");
    const absValue = decimalStr.replace(/^-/, "");

    const parts = absValue.split(".");
    const integerPart = parseInt(parts[0] || "0", 10);
    const fractionalPart = parts[1] ? parseFloat("0." + parts[1]) : 0;

    const intBinary = convertIntegerToBinary(integerPart);
    const { binary: fracBinary, isApproximate } = convertFractionalToBinary(fractionalPart);

    let result = intBinary;
    if (fracBinary) {
      result += "." + fracBinary;
    }

    if (isNegative && result !== "0") {
      result = "-" + result;
    }

    return { binary: result, isApproximate };
  };

  const convertBinaryToDecimal = (binaryStr: string): number => {
    const isNegative = binaryStr.startsWith("-");
    const absValue = binaryStr.replace(/^-/, "");

    const parts = absValue.split(".");
    const integerPart = parts[0] || "0";
    const fractionalPart = parts[1] || "";

    // Convert integer part
    let decimalValue = parseInt(integerPart, 2);

    // Convert fractional part
    if (fractionalPart) {
      let fracValue = 0;
      for (let i = 0; i < fractionalPart.length; i++) {
        if (fractionalPart[i] === "1") {
          fracValue += Math.pow(2, -(i + 1));
        }
      }
      decimalValue += fracValue;
    }

    return isNegative ? -decimalValue : decimalValue;
  };

  const convertToAllBases = (value: string, base: string): ConversionResult | null => {
    try {
      const isNegative = value.startsWith("-");
      const cleanValue = value.replace(/^-/, "").replace(/^0x|^0o/i, "");

      // Validate decimal format
      if (!validateDecimalFormat(cleanValue)) {
        setError("Invalid number format: multiple decimal points detected");
        return null;
      }

      let decimalValue: number;
      let isApproximate = false;

      switch (base) {
        case "binary":
          decimalValue = convertBinaryToDecimal(isNegative ? "-" + cleanValue : cleanValue);
          break;
        case "decimal":
          decimalValue = parseFloat((isNegative ? "-" : "") + cleanValue);
          break;
        case "hex": {
          const parts = cleanValue.split(".");
          const intPart = parseInt(parts[0] || "0", 16);
          let fracPart = 0;
          if (parts[1]) {
            for (let i = 0; i < parts[1].length; i++) {
              const digit = parseInt(parts[1][i], 16);
              fracPart += digit * Math.pow(16, -(i + 1));
            }
          }
          decimalValue = intPart + fracPart;
          if (isNegative) decimalValue = -decimalValue;
          break;
        }
        case "octal": {
          const parts = cleanValue.split(".");
          const intPart = parseInt(parts[0] || "0", 8);
          let fracPart = 0;
          if (parts[1]) {
            for (let i = 0; i < parts[1].length; i++) {
              const digit = parseInt(parts[1][i], 8);
              fracPart += digit * Math.pow(8, -(i + 1));
            }
          }
          decimalValue = intPart + fracPart;
          if (isNegative) decimalValue = -decimalValue;
          break;
        }
        default:
          return null;
      }

      if (isNaN(decimalValue)) return null;

      // Convert to binary
      const binaryResult = convertDecimalToBinary(decimalValue.toString());
      isApproximate = binaryResult.isApproximate;

      // Convert to hex and octal
      const absDecimal = Math.abs(decimalValue);
      const parts = absDecimal.toString().split(".");
      const intPart = parseInt(parts[0] || "0", 10);

      let hexResult = intPart.toString(16).toUpperCase();
      let octResult = intPart.toString(8);

      // Handle fractional parts for hex and octal
      if (parts[1]) {
        const fracValue = parseFloat("0." + parts[1]);

        // Hex fractional
        let hexFrac = "";
        let f = fracValue;
        for (let i = 0; i < 8 && f > 0; i++) {
          f *= 16;
          const digit = Math.floor(f);
          hexFrac += digit.toString(16).toUpperCase();
          f -= digit;
        }
        if (hexFrac) hexResult += "." + hexFrac;

        // Octal fractional
        let octFrac = "";
        f = fracValue;
        for (let i = 0; i < 8 && f > 0; i++) {
          f *= 8;
          const digit = Math.floor(f);
          octFrac += digit;
          f -= digit;
        }
        if (octFrac) octResult += "." + octFrac;
      }

      if (isNegative && decimalValue !== 0) {
        hexResult = "-" + hexResult;
        octResult = "-" + octResult;
      }

      return {
        binary: binaryResult.binary,
        decimal: decimalValue.toString(),
        hexadecimal: hexResult,
        octal: octResult,
        isApproximate,
      };
    } catch (error) {
      return null;
    }
  };

  const generateSteps = (value: string, base: string, results: ConversionResult): string[] => {
    const steps: string[] = [];
    const isNegative = value.startsWith("-");
    const cleanValue = value.replace(/^-/, "").replace(/^0x|^0o/i, "");
    const decimal = parseFloat(results.decimal);
    const absDecimal = Math.abs(decimal);
    const hasDecimalPoint = cleanValue.includes(".");

    steps.push(`📥 Input: ${value} (${base.toUpperCase()})`);
    steps.push(`🎯 Target: Convert to ALL number systems`);

    if (results.isApproximate) {
      steps.push(`⚠️  Note: Fractional part has infinite or long binary representation`);
      steps.push(`   Result is approximated to 16 bits precision`);
    }

    if (isNegative) {
      steps.push(`⚠️  Note: This is a NEGATIVE number`);
      steps.push(`   We'll convert the absolute value and add minus sign to results`);
    }

    if (hasDecimalPoint) {
      steps.push(`💡 Decimal number detected - converting integer and fractional parts separately`);
    }
    steps.push("");

    // Step 1: Convert to Decimal (if not already decimal)
    if (base !== "decimal") {
      steps.push(`━━━ STEP 1: Convert ${base.toUpperCase()} → DECIMAL ━━━`);
      steps.push("");

      const parts = cleanValue.split(".");
      const intPart = parts[0] || "0";
      const fracPart = parts[1] || "";

      if (base === "binary") {
        steps.push(`Method: Multiply each bit by its position value (powers of 2)`);
        steps.push("");

        // Integer part
        steps.push(`Integer part: ${intPart}`);
        steps.push(`Position values (right to left):`);
        const positions = intPart.split("").map((_, i) => `2^${intPart.length - 1 - i}`).join("  ");
        steps.push(`  ${positions}`);
        steps.push(`  ${intPart.split("").join("   ")}`);
        steps.push("");
        steps.push(`Calculations:`);

        let sum = 0;
        const calculations: string[] = [];
        for (let i = 0; i < intPart.length; i++) {
          const position = intPart.length - 1 - i;
          const bit = intPart[i];
          const power = Math.pow(2, position);
          const value = parseInt(bit) * power;
          sum += value;
          calculations.push(`  ${bit} × 2^${position} = ${bit} × ${power} = ${value}`);
        }
        steps.push(...calculations);
        steps.push("");
        steps.push(`Integer sum = ${sum}`);

        // Fractional part
        if (fracPart) {
          steps.push("");
          steps.push(`Fractional part: .${fracPart}`);
          steps.push(`Position values (left to right):`);
          const fracPositions = fracPart.split("").map((_, i) => `2^-${i + 1}`).join("  ");
          steps.push(`  ${fracPositions}`);
          steps.push(`  ${fracPart.split("").join("   ")}`);
          steps.push("");

          let fracSum = 0;
          const fracCalcs: string[] = [];
          for (let i = 0; i < fracPart.length; i++) {
            const bit = fracPart[i];
            const power = Math.pow(2, -(i + 1));
            const value = parseInt(bit) * power;
            fracSum += value;
            fracCalcs.push(`  ${bit} × 2^-${i + 1} = ${bit} × ${power} = ${value}`);
          }
          steps.push(...fracCalcs);
          steps.push("");
          steps.push(`Fractional sum = ${fracSum}`);
          steps.push("");
          steps.push(`Total: ${sum} + ${fracSum} = ${sum + fracSum}`);
        }

        steps.push(`✓ Result: ${cleanValue}₂ = ${absDecimal}₁₀`);
      } else if (base === "hex") {
        steps.push(`Method: Convert each hex digit and multiply by powers of 16`);
        steps.push(`Hex to Decimal: A=10, B=11, C=12, D=13, E=14, F=15`);
        steps.push("");

        // Integer part
        let sum = 0;
        const calculations: string[] = [];
        for (let i = 0; i < intPart.length; i++) {
          const position = intPart.length - 1 - i;
          const digit = intPart[i];
          const digitValue = parseInt(digit, 16);
          const power = Math.pow(16, position);
          const value = digitValue * power;
          sum += value;
          calculations.push(`  ${digit} × 16^${position} = ${digitValue} × ${power} = ${value}`);
        }
        steps.push(`Integer part calculations:`);
        steps.push(...calculations);
        steps.push(`Integer sum = ${sum}`);

        // Fractional part
        if (fracPart) {
          steps.push("");
          steps.push(`Fractional part: .${fracPart}`);
          let fracSum = 0;
          const fracCalcs: string[] = [];
          for (let i = 0; i < fracPart.length; i++) {
            const digit = fracPart[i];
            const digitValue = parseInt(digit, 16);
            const power = Math.pow(16, -(i + 1));
            const value = digitValue * power;
            fracSum += value;
            fracCalcs.push(`  ${digit} × 16^-${i + 1} = ${digitValue} × ${power} = ${value}`);
          }
          steps.push(...fracCalcs);
          steps.push(`Fractional sum = ${fracSum}`);
          steps.push("");
          steps.push(`Total: ${sum} + ${fracSum} = ${sum + fracSum}`);
        }

        steps.push(`✓ Result: ${cleanValue}₁₆ = ${absDecimal}₁₀`);
      } else if (base === "octal") {
        steps.push(`Method: Multiply each octal digit by powers of 8`);
        steps.push("");

        // Integer part
        let sum = 0;
        const calculations: string[] = [];
        for (let i = 0; i < intPart.length; i++) {
          const position = intPart.length - 1 - i;
          const digit = intPart[i];
          const digitValue = parseInt(digit, 8);
          const power = Math.pow(8, position);
          const value = digitValue * power;
          sum += value;
          calculations.push(`  ${digit} × 8^${position} = ${digitValue} × ${power} = ${value}`);
        }
        steps.push(`Integer part calculations:`);
        steps.push(...calculations);
        steps.push(`Integer sum = ${sum}`);

        // Fractional part
        if (fracPart) {
          steps.push("");
          steps.push(`Fractional part: .${fracPart}`);
          let fracSum = 0;
          const fracCalcs: string[] = [];
          for (let i = 0; i < fracPart.length; i++) {
            const digit = fracPart[i];
            const digitValue = parseInt(digit, 8);
            const power = Math.pow(8, -(i + 1));
            const value = digitValue * power;
            fracSum += value;
            fracCalcs.push(`  ${digit} × 8^-${i + 1} = ${digitValue} × ${power} = ${value}`);
          }
          steps.push(...fracCalcs);
          steps.push(`Fractional sum = ${fracSum}`);
          steps.push("");
          steps.push(`Total: ${sum} + ${fracSum} = ${sum + fracSum}`);
        }

        steps.push(`✓ Result: ${cleanValue}₈ = ${absDecimal}₁₀`);
      }
      steps.push("");
    }

    // Step 2: Convert Decimal to Binary
    steps.push(`━━━ STEP 2: Convert DECIMAL → BINARY ━━━`);
    steps.push("");

    const decParts = absDecimal.toString().split(".");
    const intPart = parseInt(decParts[0] || "0", 10);
    const fracPart = decParts[1] ? parseFloat("0." + decParts[1]) : 0;

    // Integer part
    steps.push(`INTEGER PART: ${intPart}`);
    steps.push(`Method: Divide by 2 repeatedly, write remainders bottom-to-top`);
    steps.push("");

    if (intPart === 0) {
      steps.push(`  ${intPart} is 0, so binary is 0`);
    } else {
      let num = intPart;
      const binarySteps: string[] = [];
      while (num > 0) {
        const quotient = Math.floor(num / 2);
        const remainder = num % 2;
        binarySteps.push(`  ${num} ÷ 2 = ${quotient} remainder ${remainder}`);
        num = quotient;
      }
      steps.push(...binarySteps);
      steps.push("");
      steps.push(`Read remainders BOTTOM to TOP: ${convertIntegerToBinary(intPart)}`);
    }

    // Fractional part
    if (fracPart > 0) {
      steps.push("");
      steps.push(`FRACTIONAL PART: ${fracPart}`);
      steps.push(`Method: Multiply by 2 repeatedly, extract integer parts`);
      steps.push("");

      let f = fracPart;
      let iterations = 0;
      const fracSteps: string[] = [];
      const fracBits: string[] = [];

      while (f > 0 && iterations < 16) {
        f *= 2;
        if (f >= 1) {
          fracSteps.push(`  ${(f - 1 + fracPart * Math.pow(2, iterations)).toFixed(6)} × 2 = ${f.toFixed(6)} → extract 1`);
          fracBits.push("1");
          f -= 1;
        } else {
          fracSteps.push(`  ${(f / 2).toFixed(6)} × 2 = ${f.toFixed(6)} → extract 0`);
          fracBits.push("0");
        }
        iterations++;

        if (iterations >= 8) {
          fracSteps.push("  ... (limited to 16 bits)");
          break;
        }
      }

      steps.push(...fracSteps);
      steps.push("");
      steps.push(`Read bits TOP to BOTTOM: .${fracBits.join("")}`);
    }

    steps.push("");
    steps.push(`✓ Result: ${absDecimal}₁₀ = ${results.binary.replace('-', '')}₂`);
    steps.push("");

    // Step 3: Convert Decimal to Hexadecimal
    steps.push(`━━━ STEP 3: Convert DECIMAL → HEXADECIMAL ━━━`);
    steps.push("");
    steps.push(`Note: 10=A, 11=B, 12=C, 13=D, 14=E, 15=F`);
    steps.push("");

    // Similar detailed steps for hex...
    steps.push(`Integer part: Divide by 16 repeatedly`);
    if (intPart === 0) {
      steps.push(`  ${intPart} is 0, so hex is 0`);
    } else {
      let num = intPart;
      while (num > 0) {
        const quotient = Math.floor(num / 16);
        const remainder = num % 16;
        const hexDigit = remainder.toString(16).toUpperCase();
        steps.push(`  ${num} ÷ 16 = ${quotient} remainder ${remainder}${remainder >= 10 ? ` (${hexDigit})` : ""}`);
        num = quotient;
      }
    }

    if (fracPart > 0) {
      steps.push("");
      steps.push(`Fractional part: Multiply by 16 repeatedly`);
      steps.push("  (showing first few iterations)");
    }

    steps.push(`✓ Result: ${absDecimal}₁₀ = ${results.hexadecimal.replace('-', '')}₁₆`);
    steps.push("");

    // Step 4: Convert Decimal to Octal
    steps.push(`━━━ STEP 4: Convert DECIMAL → OCTAL ━━━`);
    steps.push("");
    steps.push(`Integer part: Divide by 8 repeatedly`);

    if (intPart === 0) {
      steps.push(`  ${intPart} is 0, so octal is 0`);
    } else {
      let num = intPart;
      while (num > 0) {
        const quotient = Math.floor(num / 8);
        const remainder = num % 8;
        steps.push(`  ${num} ÷ 8 = ${quotient} remainder ${remainder}`);
        num = quotient;
      }
    }

    if (fracPart > 0) {
      steps.push("");
      steps.push(`Fractional part: Multiply by 8 repeatedly`);
      steps.push("  (showing first few iterations)");
    }

    steps.push(`✓ Result: ${absDecimal}₁₀ = ${results.octal.replace('-', '')}₈`);
    steps.push("");

    // Final Summary
    steps.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    steps.push(`📊 FINAL RESULTS:`);
    steps.push(`  Binary:       ${results.binary}₂`);
    steps.push(`  Decimal:      ${results.decimal}₁₀`);
    steps.push(`  Hexadecimal:  ${results.hexadecimal}₁₆`);
    steps.push(`  Octal:        ${results.octal}₈`);
    if (results.isApproximate) {
      steps.push(``);
      steps.push(`  ⚠️  Note: Binary result is approximate (limited to 16 bits)`);
    }
    steps.push(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

    return steps;
  };

  const handleConvert = () => {
    setError("");
    const trimmedInput = input.trim();
    if (!trimmedInput) {
      setError("Please enter a value");
      return;
    }

    const detectedBase = inputBase === "decimal" ? detectBase(trimmedInput) : inputBase;
    const results = convertToAllBases(trimmedInput, detectedBase);

    if (!results) {
      if (!error) {
        setError(`Invalid ${inputBase} number`);
      }
      return;
    }

    setResult(results);
    setSteps(generateSteps(trimmedInput, detectedBase, results));
    playSound();

    // Save to history
    const historyItem: HistoryItem = {
      id: Date.now().toString(),
      input: trimmedInput,
      inputBase: detectedBase,
      results,
      timestamp: Date.now(),
    };

    const newHistory = [historyItem, ...history].slice(0, 50);
    setHistory(newHistory);
    localStorage.setItem("conversionHistory", JSON.stringify(newHistory));

    // Track conversion
    const count = parseInt(localStorage.getItem("totalConversions") || "0");
    localStorage.setItem("totalConversions", (count + 1).toString());
  };

  const handleCopy = (value: string) => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleReset = () => {
    setInput("");
    setResult(null);
    setSteps([]);
    setError("");
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem("conversionHistory");
  };

  return (
    <div className={`min-h-screen px-4 py-8 transition-colors duration-300 ${isDark ? 'bg-slate-950' : 'bg-gradient-to-br from-blue-50 via-white to-purple-50'}`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <Link to="/">
            <Button variant="ghost" className="text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/10">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          </Link>

          <div className="flex gap-2">
            <Button
              onClick={() => setShowHistory(!showHistory)}
              variant="outline"
              className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10"
            >
              <History className="w-4 h-4 mr-2" />
              History
            </Button>
            <Button
              onClick={() => setSoundEnabled(!soundEnabled)}
              variant="outline"
              className="border-cyan-500/50 text-cyan-400"
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </Button>
            <ThemeToggle />
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-5xl md:text-7xl font-black mb-4 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            Universal Converter
          </h1>
          <p className="text-xl text-slate-300">Convert between Binary • Decimal • Hexadecimal • Octal</p>
          <p className="text-sm text-slate-400 mt-2">✨ Now supports floating point numbers! (e.g., 10.5, 0.25)</p>
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-2xl mx-auto mb-6 bg-red-500/10 border-2 border-red-500/50 rounded-xl p-4 flex items-center gap-3"
          >
            <AlertCircle className="w-6 h-6 text-red-400 flex-shrink-0" />
            <p className="text-red-400 font-semibold">{error}</p>
          </motion.div>
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Input Panel */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-gradient-to-br from-cyan-500/10 to-blue-600/10 backdrop-blur-md border-2 border-cyan-500/30 rounded-2xl p-6"
            >
              <Label className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-cyan-400" />
                Input
              </Label>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
                {[
                  { value: "binary", label: "Binary", color: "cyan" },
                  { value: "decimal", label: "Decimal", color: "blue" },
                  { value: "hex", label: "Hex", color: "purple" },
                  { value: "octal", label: "Octal", color: "green" },
                ].map((base) => (
                  <Button
                    key={base.value}
                    onClick={() => setInputBase(base.value as any)}
                    variant={inputBase === base.value ? "default" : "outline"}
                    className={inputBase === base.value
                      ? `bg-${base.color}-500 hover:bg-${base.color}-600 border-0`
                      : `border-${base.color}-500/30 text-${base.color}-400 hover:bg-${base.color}-500/10`
                    }
                  >
                    {base.label}
                  </Button>
                ))}
              </div>

              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleConvert()}
                placeholder={`Enter ${inputBase} number (decimals OK: 10.5, -0.25)...`}
                className="bg-slate-800/50 border-slate-600 text-white text-2xl h-16 mb-4"
              />

              <div className="flex gap-3">
                <Button
                  onClick={handleConvert}
                  className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 h-12 text-lg"
                >
                  Convert
                </Button>
                <Button
                  onClick={handleReset}
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:bg-slate-800"
                >
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
            </motion.div>

            {/* Results */}
            {result && (
              <>
                {result.isApproximate && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-2 border-yellow-500/50 rounded-xl p-4 flex items-start gap-3"
                  >
                    <AlertCircle className="w-6 h-6 text-yellow-400 flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="text-lg font-bold text-yellow-400">Approximate Result</h4>
                      <p className="text-sm text-slate-300">
                        The fractional part has an infinite or very long binary representation (like 0.1 in decimal → 0.0001100110011... in binary).
                        The result is approximated to 16 bits precision.
                      </p>
                    </div>
                  </motion.div>
                )}

                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-4"
                >
                  {[
                    { label: "Binary", value: result.binary, color: "cyan", prefix: "" },
                    { label: "Decimal", value: result.decimal, color: "blue", prefix: "" },
                    { label: "Hexadecimal", value: result.hexadecimal, color: "purple", prefix: "0x" },
                    { label: "Octal", value: result.octal, color: "green", prefix: "0o" },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className={`bg-gradient-to-br from-${item.color}-500/10 to-${item.color}-600/10 backdrop-blur-md border-2 border-${item.color}-500/30 rounded-xl p-6`}
                    >
                      <div className={`text-sm font-semibold text-${item.color}-400 mb-2`}>
                        {item.label}
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="text-2xl font-mono font-bold text-white break-all">
                          {item.label === "Binary" ? item.value : (item.value.startsWith('-') ? '-' + item.prefix + item.value.substring(1) : item.prefix + item.value)}
                        </div>
                        <Button
                          onClick={() => handleCopy(item.label === "Binary" ? item.value : (item.value.startsWith('-') ? '-' + item.prefix + item.value.substring(1) : item.prefix + item.value))}
                          variant="ghost"
                          size="icon"
                          className={`text-${item.color}-400 hover:bg-${item.color}-500/10`}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </motion.div>
              </>
            )}

            {/* Steps */}
            {steps.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-gradient-to-br from-purple-500/10 to-pink-600/10 backdrop-blur-md border-2 border-purple-500/30 rounded-2xl p-6"
              >
                <h3 className="text-xl font-bold text-white mb-4">Step-by-Step Explanation</h3>
                <div className="space-y-2 font-mono text-sm text-slate-300 max-h-[600px] overflow-y-auto">
                  {steps.map((step, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.02 }}
                      className={step.startsWith("━") ? "text-cyan-400 font-bold" : step.startsWith("⚠️") || step.startsWith("💡") ? "text-orange-400" : ""}
                    >
                      {step}
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* History Sidebar */}
          <AnimatePresence>
            {showHistory && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-gradient-to-br from-slate-800/50 to-slate-900/50 backdrop-blur-md border-2 border-slate-700/50 rounded-2xl p-6 max-h-[800px] overflow-y-auto"
              >
                <div className="flex items-center justify-between mb-4 sticky top-0 bg-slate-900/80 pb-2">
                  <h3 className="text-xl font-bold text-white">History</h3>
                  {history.length > 0 && (
                    <Button
                      onClick={clearHistory}
                      variant="ghost"
                      size="sm"
                      className="text-red-400 hover:bg-red-500/10"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                {history.length === 0 ? (
                  <p className="text-slate-400 text-center py-8">No conversions yet</p>
                ) : (
                  <div className="space-y-3">
                    {history.map((item) => (
                      <div
                        key={item.id}
                        className="bg-slate-800/50 border border-slate-700 rounded-lg p-4 hover:border-cyan-500/50 transition-colors cursor-pointer"
                        onClick={() => {
                          setInput(item.input);
                          setInputBase(item.inputBase as any);
                        }}
                      >
                        <div className="text-sm text-slate-400 mb-2">
                          {new Date(item.timestamp).toLocaleString()}
                        </div>
                        <div className="text-white font-mono">
                          {item.input} <span className="text-cyan-400">({item.inputBase})</span>
                        </div>
                        <div className="text-xs text-slate-500 mt-2">
                          → {item.results.decimal} (decimal)
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {copied && (
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 right-8 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg"
          >
            ✓ Copied to clipboard!
          </motion.div>
        )}
      </div>
    </div>
  );
}

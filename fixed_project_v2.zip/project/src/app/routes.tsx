import { createBrowserRouter } from "react-router";
import { BinaryVerseLanding } from "./components/BinaryVerseLanding";
import { UniversalConverter } from "./components/UniversalConverter";
import { LearningPage } from "./components/LearningPage";
import { NumberNinjaGame } from "./components/NumberNinjaGame";
import { ImprovedProgressDashboard } from "./components/ImprovedProgressDashboard";
import { ComprehensiveQuiz } from "./components/ComprehensiveQuiz";
import { PracticePageNew } from "./components/PracticePageNew";
import { ComprehensiveHistory } from "./components/ComprehensiveHistory";
import { ASCIIConverter } from "./components/ASCIIConverter";

export const router = createBrowserRouter([
  {
    path: "/",
    children: [
      { index: true, Component: BinaryVerseLanding },
      { path: "converter", Component: UniversalConverter },
      { path: "ascii", Component: ASCIIConverter },
      { path: "learn", Component: LearningPage },
      { path: "game", Component: NumberNinjaGame },
      { path: "progress", Component: ImprovedProgressDashboard },
      { path: "quiz", Component: ComprehensiveQuiz },
      { path: "practice", Component: PracticePageNew },
      { path: "history", Component: ComprehensiveHistory },
    ],
  },
]);

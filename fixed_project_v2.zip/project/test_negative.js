// Test negative number conversions
function testConversion(value, base) {
  console.log(`\nTesting: ${value} (${base})`);
  
  const isNegative = value.startsWith("-");
  const cleanValue = value.replace(/^-/, "").replace(/^0x|^0o/i, "");
  
  console.log(`  isNegative: ${isNegative}`);
  console.log(`  cleanValue: ${cleanValue}`);
  
  let decimalValue;
  switch(base) {
    case "binary":
      decimalValue = parseInt(cleanValue, 2);
      break;
    case "decimal":
      decimalValue = parseInt(cleanValue, 10);
      break;
    case "hex":
      decimalValue = parseInt(cleanValue, 16);
      break;
    case "octal":
      decimalValue = parseInt(cleanValue, 8);
      break;
  }
  
  if (isNegative) {
    decimalValue = -decimalValue;
  }
  
  console.log(`  decimalValue: ${decimalValue}`);
  console.log(`  binary: ${decimalValue.toString(2)}`);
  console.log(`  hex: ${decimalValue.toString(16).toUpperCase()}`);
  console.log(`  octal: ${decimalValue.toString(8)}`);
}

testConversion("-25", "decimal");
testConversion("-1010", "binary");
testConversion("-1F", "hex");
testConversion("-37", "octal");
